# aki_repair

最后更新：2026-11-06

人急性肾损伤（AKI）肾小管适应/修复状态与 KDIGO 严重度的干实验工作区。全部数据来自公开资源，无湿实验。

## 数据

- KPMP 开放临床表与单细胞/单核图谱（GSE183276、GSE183277）
- KPMP 仓库表达矩阵：**sc 42 个 AKI 文库**（38 名参与者）、**19 个 Reference 文库**（18 名）、**20 个 CKD 文库**（12 DKD + 3 H-CKD），以及 **sn 43 个矩阵**（29 名，用作第二个 RCTD 参考与第三个 PT 队列）
- GSE210622 人 AKI/对照单核 RNA-seq（独立验证，含 PT 内部 pseudobulk；亦为 RCTD 参考 A）
- GSE199321 尿液单细胞队列的公开临床与纵向尿量/肌酐数据
- GSE139061 人肾活检 bulk RNA-seq（验证）
- GSE67401 SIRS 血液转录组（组织特异性检验）
- KPMP 开放 Visium 空间转录组：16 例（Stage 1×5、Stage 2×5、Stage 3×6）
- **GSE199321 尿液单细胞队列**（485 MB 全量矩阵）：37 套样本（43 例患者样本 + 6 个池化样本，池化按 4 个 hashing 标签去卷积）
- **中间聚合数据**：`data/state_pseudobulk/`（PT 状态特异患者级 counts）、`data/celltype_pseudobulk/`（PT/IMM/FIB/EC 患者级 counts）

## 主要结论

**所有对外数字以 `results/FINAL_manuscript_numbers.csv`（29 层 / 770 行）为准，口径说明见 `reports/FINAL_NUMBERS.md`。**

1. **PT 细胞内部三队列一致**：AKI 患者 PT 的 injury/stress、repair-progenitor、cycling 症状升高、reference-state 下降（KPMP sc 12 vs 18：injury p=0.019、repair p=0.0056、cycling p=2.1e-05、reference p=8e-06；GSE210622 sn 8 vs 6：injury/repair FDR=0.001332；KPMP sn 4 vs 12 方向一致但功效不足）。见 `reports/PT_LEVEL_VALIDATION.md`。
2. 组织层面：adaptive/repair PT 与 cycling 状态扩张、reference 减少、免疫浸润增加。sn 图谱**组织层**在族内 FDR 下同样显著（adaptive/reference FDR=0.021；cycling/免疫不显著），但 **sn PT 层不显著**（族内 FDR≥0.73）。见 `reports/AKI_REPAIR_REPORT.md`。
3. **CKD 对照（新）**：adaptive 扩张与 reference 丢失为 AKI/CKD 共有，**cycling 扩张为 AKI 特有**（PT 层 p=0.0067、PT pseudobulk p=0.0104）。
4. 空间层面：16 例 Visium 中 injury/repair 与免疫/PT/成纤维共定位、深度校正邻域富集显著；**两套独立 RCTD 参考（GSE210622 与 KPMP sn）结论一致**（免疫 rho=0.95、PT 0.93）。见 `reports/SPATIAL_PILOT_REPORT.md`、`reports/RCTD_REFERENCE_COMPARISON.md`。
5. KDIGO 严重度梯度弱（PT injury rho=+0.56，p=0.059；跨队列 meta 无签名 p<0.05），仅作探索性。见 `reports/SEVERITY_META_REPORT.md`。
6. **状态内部差异（新）**：adaptive 状态内 AKI vs CKD 仅 3 个 DE 基因（**年龄校正后 1 个**），而同两组相对 Reference 各 1,500+/1,390 ——急慢差别在"哪些细胞进入该状态"，不在胞内程序；残余差异集中在 reference 状态（57 个基因中 36 个在年龄校正后保留）。见 `reports/STATE_DE_REPORT.md`。
7. **尿液桥梁（新，探索性）**：同一套程序可在尿液脱落细胞中量化（72,063 细胞 / 30 患者），reference 分值随 KDIGO 升高而下降（rho=−0.568，p=0.027，方向与组织一致；未过 FDR）。见 `reports/URINE_BRIDGE_REPORT.md`。
8. **细胞互作（新，阴性为主）**：10 对预设 PT→免疫配体-受体在 AKI vs CKD 上均无差异；仅 ANXA1/MIF 轴与免疫浸润同步（n=42，p≈0.04，探索性）。见 `reports/CELLCOMM_REPORT.md`。

## 运行顺序

```bash
python3 -I scripts/00_kpmp_query.py          # 队列检索
python3 -I scripts/01_kpmp_manifest.py       # 文件清单
python3 -I scripts/03_kpmp_analysis.py       # 图谱组成/状态分析
python3 -I scripts/04_adjusted_models_clinical.py
python3 -I scripts/05_PT_state_analysis.py
python3 -I scripts/07_signature_validation.py
python3 -I scripts/08_key_findings_figures.py
python3 -I scripts/09_kpmp_pseudobulk.py     # 全细胞 pseudobulk
python3 -I scripts/22_PT_pseudobulk.py       # PT 内部 pseudobulk（AKI vs Reference）
python3 -I scripts/26_GSE210622_PT_pseudobulk.py   # 独立 sn 队列复制
python3 -I scripts/20_spatial_pilot_analysis.py    # 16 例 Visium 签名与共定位
python3 -I scripts/21b_export_rctd_inputs.py       # RCTD 输入
Rscript scripts/21c_rctd_visium.R                  # RCTD 解卷积（参考 A: GSE210622）
python3 -I scripts/49_build_rctd_reference_kpmp.py # 参考 B: KPMP sn 参考构建
Rscript scripts/50_rctd_visium_kpmp_reference.R    # RCTD 解卷积（参考 B）
python3 -I scripts/52_compare_rctd_references.py   # 双参考一致性对比
python3 -I scripts/53_sn_PT_pseudobulk.py          # 第三队列：KPMP sn PT pseudobulk
python3 -I scripts/39_reviewer_patient_level.py    # 患者水平/三组比较/FDR 敏感性
python3 -I scripts/40_reviewer_baseline_adjusted.py# 基线表与校正模型
python3 -I scripts/47_final_numbers.py             # 生成权威数字总表
python3 -I scripts/60_export_state_pseudobulk.py   # ① 状态特异患者级 pseudobulk
Rscript scripts/61_state_DE.R                      # ① edgeR 状态内 DE
python3 -I scripts/62_state_DE_gene_sets.py        # ① 签名/通路竞争检验
python3 -I scripts/63_export_celltype_pseudobulk.py# ③ PT/IMM/FIB/EC pseudobulk
bash  scripts/64_parallel_fetch.sh <URL> <OUT> <BYTES>   # 通用 8 路并行下载器
python3 -I scripts/65b_urine_bridge_v2.py          # ② 尿液桥梁
python3 -I scripts/66_focused_ligand_receptor.py   # ③ 配体-受体
python3 -I scripts/29_update_key_findings.py       # 汇总关键结果表
```

`PT_PSEUDO=0.5 python3 -I scripts/22_PT_pseudobulk.py` 可重跑伪计数敏感性（默认 1；结果见 `results/PT_pseudocount_sensitivity.csv`，三档结论一致）。
`scripts/02_robust_download.py` 与 `scripts/19e_parallel_download_spatial.py` 用于限速环境下的断点续传与并行下载；`scripts/21a_build_rctd_reference.py` 构建含 AKI 状态的 RCTD 参考；`scripts/24_match_ref_sc.py`、`scripts/27_map_GSE210622_AKI.py` 解决样本名映射。

所有结果表在 `results/`，图在 `figures/`，报告在 `reports/`；文件校验和见 `reports/file_checksums.sha256`。

## 局限

横断面再分析；分期样本不均衡（Stage 3 偏多），跨队列 meta 后严重度仍不显著；空间样本病理类型混合、spot 存在伪重复；无实验验证；不能声称脓毒症共病或因果机制。
