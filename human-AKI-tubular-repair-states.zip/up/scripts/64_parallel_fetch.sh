#!/bin/bash
# 通用 8 路并行 Range 下载器（用于本机限速但服务端支持 Range 的场景）
# 用法: bash 64_parallel_fetch.sh <URL> <输出文件> [期望字节数] [并行数]
set -u
URL="$1"; OUT="$2"; EXPECTED="${3:-0}"; N="${4:-8}"
DIR="$(dirname "$OUT")"; mkdir -p "$DIR"; cd "$DIR"
BASE="$(basename "$OUT")"
rm -rf ".parts_$BASE" && mkdir -p ".parts_$BASE"
if [ "$EXPECTED" = "0" ]; then
  EXPECTED=$(curl -sI --max-time 30 "$URL" | awk 'tolower($1)=="content-length:"{print $2}' | tr -d '\r')
fi
echo "目标: $OUT  服务器报告: ${EXPECTED} 字节  并行: $N"
CHUNK=$(( (EXPECTED + N - 1) / N ))
pids=()
for i in $(seq 0 $((N-1))); do
  start=$((i*CHUNK)); end=$((start+CHUNK-1)); [ "$end" -ge "$EXPECTED" ] && end=$((EXPECTED-1))
  (
    for a in $(seq 1 15); do
      curl -s --fail -r "$start-$end" --connect-timeout 20 --max-time 7200 \
           --speed-time 30 --speed-limit 10000 --retry 2 --retry-delay 2 \
           -o ".parts_$BASE/part.$i" "$URL" && break
      echo "  分片 $i 第 $a 次中断，重试"; sleep 2
    done
  ) &
  pids+=($!)
done
while :; do
  sleep 20
  done_b=$(du -sb ".parts_$BASE" 2>/dev/null | cut -f1)
  alive=0; for p in "${pids[@]}"; do kill -0 "$p" 2>/dev/null && alive=$((alive+1)); done
  python3 -c "print(f'  进度 {$done_b/1048576:.0f}/{$EXPECTED/1048576:.0f} MB ({$done_b/$EXPECTED*100:.1f}%)  活动分片 $alive', flush=True)"
  [ "$alive" -eq 0 ] && break
done
cat ".parts_$BASE"/part.* > "$BASE"
actual=$(stat -c%s "$BASE")
if [ "$actual" = "$EXPECTED" ]; then
  echo "✓ 完成: $actual 字节"; rm -rf ".parts_$BASE"; sha256sum "$BASE" | tee "$BASE.sha256"
else
  echo "✗ 大小不符: $actual / $EXPECTED"; exit 1
fi
