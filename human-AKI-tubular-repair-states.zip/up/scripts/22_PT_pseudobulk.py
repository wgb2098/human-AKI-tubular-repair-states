#!/usr/bin/env python3
"""PT-only pseudobulk from KPMP sc matrices, AKI vs Reference patients.

Cell-type labels come from the GSE183276 sc atlas metadata, which annotates
PT cells (and their l2 states) for both AKI and Reference participants. Each
matrix ships its own barcode list, so the barcode index is rebuilt per file.
"""

from __future__ import annotations

import gzip
import os
import re
import io
import zipfile
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
META = ROOT / "metadata"
CELL_META = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"
SIGS = RES / "Klocke_signature_genes.csv"

CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]

# Independent gene sets used to cross-check the Klocke-derived signatures.
# aPT surface markers: injured/adaptive PT markers repeatedly reported in human
# AKI single-cell studies (specified independently of the Klocke clustering).
APT_MARKERS = ["VCAM1", "SPP1", "LTF", "MMP7", "HAVCR1", "CD24", "PROM1", "SOX9", "KRT7", "KRT19"]
# Hypoxia/HIF target module: an orthogonal stress axis (oxygen sensing/glycolysis).
HYPOXIA_TARGETS = ["VEGFA", "SLC2A1", "LDHA", "PGK1", "ENO1", "HK2", "BNIP3", "NDRG1",
                   "ANKRD37", "P4HA1", "ADM", "HILPDA", "MIF", "DDIT4"]

SIGNATURES = ["injury_stress", "repair_progenitor", "cycling", "reference_PT",
              "aPT_markers", "hypoxia_targets"]
# log2(CPM + PSEUDO) 的伪计数；默认 1，可用 PT_PSEUDO 覆盖以做敏感性分析
PSEUDO = float(os.environ.get("PT_PSEUDO", "1"))
SUFFIX = "" if PSEUDO == 1 else "_pseudo" + str(PSEUDO).replace(".", "")
G = {}


def worker(job: tuple[str, str, str, str]) -> dict | None:
    file_id, participant, directory, group = job
    matches = sorted(ROOT.glob(f"{directory}/{file_id}*.zip"))
    if not matches:
        return None
    path = matches[0]
    pt_barcodes = G["pt_barcodes"].get(participant)
    if not pt_barcodes:
        return None
    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()

            def read(name: str) -> bytes:
                with zf.open(name) as handle:
                    data = handle.read()
                return gzip.decompress(data) if name.endswith(".gz") else data

            matrix_name = next(n for n in names if "matrix" in n.lower() and ".mtx" in n.lower())
            feature_name = next(n for n in names if "features" in n.lower() or "genes" in n.lower())
            barcode_name = next(n for n in names if "barcode" in n.lower())
            whitelist = read(barcode_name).decode(errors="replace").split()
            body = read(matrix_name).split(b"\n", 3)[3]
            features = pd.read_csv(io.BytesIO(read(feature_name)), sep="\t", header=None)
        genes = (features.iloc[:, 1].astype(str).tolist() if features.shape[1] > 1
                 else features.iloc[:, 0].astype(str).tolist())
        # some KPMP builds prefix symbols, e.g. "hg38____SLC34A1"
        genes = [re.sub(r"^[A-Za-z0-9]+_{4}", "", g) for g in genes]
        index = {b: i + 1 for i, b in enumerate(whitelist)}  # mtx columns are 1-based
        positions = {index[b] for b in pt_barcodes if b in index}
        if len(positions) < 20:
            return {"file_id": file_id, "participant": participant, "error":
                    f"only {len(positions)} PT barcodes matched of {len(pt_barcodes)} annotated"}
        df = pd.read_csv(io.BytesIO(body), sep=" ", header=None, names=["g", "c", "v"],
                         dtype={"g": np.int32, "c": np.int32, "v": np.float32}, engine="c")
        df = df[df["c"].isin(positions)]
        counts = np.bincount(df["g"].to_numpy() - 1, weights=df["v"].to_numpy(), minlength=len(genes))
    except Exception as exc:
        return {"file_id": file_id, "participant": participant, "error": str(exc)}
    lib = counts.sum()
    if lib <= 0:
        return None
    logcpm = np.log2(counts / lib * 1e6 + PSEUDO)
    series = pd.Series(logcpm, index=genes)
    series = series[~series.index.duplicated(keep="first")]
    z = (series - series.mean()) / (series.std() if series.std() else 1)
    row = {"file_id": file_id, "participant": participant, "group": group,
           "n_PT_cells": len(positions), "n_PT_annotated": len(pt_barcodes), "PT_UMI": int(lib)}
    for sig in SIGNATURES:
        present = [g for g in G["signatures"][sig] if g in z.index]
        row[sig] = z.loc[present].mean() if len(present) >= 8 else np.nan
    return row


def weighted_patient_table(table: pd.DataFrame) -> pd.DataFrame:
    table = table.reset_index(drop=True)      # 过滤过错误行后索引可能不连续
    weights = table["n_PT_cells"].to_numpy(dtype=float)

    def wmean(group: pd.DataFrame, column: str) -> float:
        w = weights[group.index.to_numpy()]
        values = group[column].to_numpy(dtype=float)
        valid = ~np.isnan(values) & (w > 0)
        return float(np.average(values[valid], weights=w[valid])) if valid.any() else np.nan

    rows = []
    for participant, group in table.groupby("participant"):
        record = {
            "participant": participant,
            "group": group["group"].iloc[0],
            "n_libraries": len(group),
            "n_PT_cells": int(group["n_PT_cells"].sum()),
            "n_PT_annotated": int(group["n_PT_annotated"].sum()),
        }
        for sig in SIGNATURES:
            record[sig] = wmean(group, sig)
        rows.append(record)
    return pd.DataFrame(rows)


def main() -> None:
    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    pt_all = meta[meta["subclass.l1"] == "PT"].copy()
    pt_all["barcode"] = pt_all.index.str.split("_", n=1).str[1]
    pt_barcodes = {str(p): set(g["barcode"]) for p, g in pt_all.groupby("patient")}
    print("patients with PT annotations:", len(pt_barcodes))

    sig = pd.read_csv(SIGS)
    signatures = {name: list(g["gene"].astype(str)) for name, g in sig.groupby("signature")}
    signatures["cycling"] = CYCLING
    signatures["aPT_markers"] = APT_MARKERS
    signatures["hypoxia_targets"] = HYPOXIA_TARGETS
    G.update({"pt_barcodes": pt_barcodes, "signatures": signatures})

    jobs = []
    aki = pd.read_csv(META / "KPMP_open_AKI_single_sample_matrices.csv")
    aki = aki[aki["experimental_strategy"].str.contains("Single-cell RNA-Seq", na=False)]
    for _, row in aki.iterrows():
        participant = str(row["participants"])
        if participant in pt_barcodes:
            jobs.append((str(row["file_id"]), participant, "data/KPMP/sc", "AKI"))
    ref_path = META / "KPMP_open_Ref_single_sample_matrices.csv"
    if ref_path.exists():
        ref = pd.read_csv(ref_path)
        for _, row in ref.iterrows():
            participant = str(row["participants"])
            if participant in pt_barcodes:
                jobs.append((str(row["file_id"]), participant, "data/KPMP/sc_ref", "Ref"))
    ckd_path = META / "KPMP_open_CKD_single_sample_matrices.csv"
    if ckd_path.exists():
        ckd = pd.read_csv(ckd_path)
        for _, row in ckd.iterrows():
            participant = str(row["participants"])
            if participant in pt_barcodes:
                jobs.append((str(row["file_id"]), participant, "data/KPMP/sc_ckd",
                             str(row["condition"])))
    print("matrix jobs:", len(jobs))

    with Pool(6) as pool:
        rows = [r for r in pool.map(worker, jobs) if r]
    table = pd.DataFrame(rows)
    if "error" in table.columns:
        bad = table[table["error"].notna()]
        if len(bad):
            print("errors:")
            print(bad[["participant", "group", "error"]].to_string(index=False))
        table = table[table["error"].isna()].drop(columns=["error"])
    table.to_csv(RES / ("KPMP_sc_PT_pseudobulk" + SUFFIX + ".csv"), index=False)

    agg = weighted_patient_table(table)
    stage = aki.drop_duplicates("participants").set_index("participants")["KDIGO Stage"]
    agg["stage"] = agg["participant"].map(stage)
    agg["stage_num"] = pd.to_numeric(agg["stage"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
    state_frac = (pt_all.assign(is_ref=pt_all["state.l2"] == "reference")
                  .groupby("patient")["is_ref"].mean())
    cyc_frac = (pt_all.assign(is_cyc=pt_all["state.l2"] == "cycling")
                .groupby("patient")["is_cyc"].mean())
    agg["reference_state_frac"] = agg["participant"].map(state_frac)
    agg["cycling_state_frac"] = agg["participant"].map(cyc_frac)
    agg.to_csv(RES / ("KPMP_sc_PT_pseudobulk_patient" + SUFFIX + ".csv"), index=False)

    pd.set_option("display.width", 200)
    print("\nPT pseudobulk per patient:")
    print(agg.round(3).to_string(index=False))

    print("\nAKI vs Reference (Mann-Whitney, patient level):")
    from statsmodels.stats.multitest import multipletests
    rows = []
    # CKD patients carry their atlas label (DKD / H-CKD); treat them as one CKD group
    agg["study_group"] = np.where(agg["group"] == "AKI", "AKI",
                          np.where(agg["group"] == "Ref", "Ref", "CKD"))
    comparisons = [("AKI_vs_Ref", "AKI", "Ref"), ("AKI_vs_CKD", "AKI", "CKD"), ("CKD_vs_Ref", "CKD", "Ref")]
    all_rows = []
    for label, group_a, group_b in comparisons:
        for sig_name in SIGNATURES + ["reference_state_frac", "cycling_state_frac"]:
            a = agg.loc[agg["study_group"] == group_a, sig_name].dropna()
            b = agg.loc[agg["study_group"] == group_b, sig_name].dropna()
            if len(a) >= 3 and len(b) >= 3:
                p = stats.mannwhitneyu(a, b).pvalue
                all_rows.append({"contrast": label, "feature": sig_name, "n_a": len(a), "n_b": len(b),
                                 "median_a": a.median(), "median_b": b.median(), "p": p})
                if label == "AKI_vs_Ref":
                    print(f"  {sig_name:22s} n={len(a)}/{len(b)}  median {a.median():+.3f} vs "
                          f"{b.median():+.3f}  p={p:.4f}")
                    rows.append({"feature": sig_name, "n_AKI": len(a), "n_Ref": len(b),
                                 "median_AKI": a.median(), "median_Ref": b.median(), "p": p})
    stats_table = pd.DataFrame(rows)
    if len(stats_table):
        stats_table["fdr"] = multipletests(stats_table["p"], method="fdr_bh")[1]
    stats_table.to_csv(RES / ("KPMP_sc_PT_pseudobulk_AKI_vs_Ref" + SUFFIX + ".csv"), index=False)

    three = pd.DataFrame(all_rows)
    if len(three):
        three["fdr"] = np.nan
        for label in three["contrast"].unique():
            mask = three["contrast"] == label
            three.loc[mask, "fdr"] = multipletests(three.loc[mask, "p"], method="fdr_bh")[1]
        three.to_csv(RES / ("KPMP_sc_PT_pseudobulk_three_group" + SUFFIX + ".csv"), index=False)
        print("\nAKI vs CKD and CKD vs Ref (patient level):")
        print(three[three["contrast"] != "AKI_vs_Ref"].round(4).to_string(index=False))

    print("\nPT state fraction correlation with PT pseudobulk:")
    for sig_name in SIGNATURES:
        rho, p = stats.spearmanr(agg[sig_name], agg["reference_state_frac"], nan_policy="omit")
        print(f"  {sig_name:20s} vs reference state frac: rho={rho:+.3f} p={p:.3f}")

    print("\nStage trend within AKI (Spearman):")
    aki_only = agg[agg["group"] == "AKI"]
    for sig_name in SIGNATURES:
        x = aki_only["stage_num"]
        y = aki_only[sig_name]
        valid = x.notna() & y.notna()
        if valid.sum() >= 5 and x[valid].nunique() >= 2:
            rho, p = stats.spearmanr(x[valid], y[valid])
            print(f"  {sig_name:20s} rho={rho:+.3f} p={p:.3f} n={int(valid.sum())}")

    print("\nCross-check: Klocke-derived vs independent signatures (all patients):")
    cross_rows = []
    for klocke_sig in ["injury_stress", "repair_progenitor", "cycling"]:
        for independent in ["aPT_markers", "hypoxia_targets"]:
            rho, p = stats.spearmanr(agg[klocke_sig], agg[independent], nan_policy="omit")
            cross_rows.append({"klocke_signature": klocke_sig, "independent_signature": independent,
                               "rho": rho, "p": p, "n": int(agg[[klocke_sig, independent]].dropna().shape[0])})
            print(f"  {klocke_sig:20s} vs {independent:18s} rho={rho:+.3f} p={p:.4f}")
    pd.DataFrame(cross_rows).to_csv(RES / ("KPMP_sc_PT_pseudobulk_signature_crosscheck" + SUFFIX + ".csv"), index=False)


if __name__ == "__main__":
    main()
