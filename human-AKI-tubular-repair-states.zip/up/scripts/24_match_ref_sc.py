#!/usr/bin/env python3
"""Match KPMP repository single-cell matrices to Reference (healthy) libraries.

The published sc atlas metadata (GSE183276) labels 18 Reference patients by
their library names; the KPMP repository names the same samples by redcap id.
This resolves the mapping, writes the download list and a manifest.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"
REPO = META / "KPMP_sc_all_open_files.json"
CELL_META = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"
BASE = "https://atlas.kpmp.org/api/v1/file/download"


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def main() -> None:
    rows = json.loads(REPO.read_text())
    matrices = []
    for r in rows:
        if "matrix" not in str(r["file_name"]).lower() or not str(r["file_name"]).endswith(".zip"):
            continue
        rid = r["redcap_id"]
        rid = rid[0] if isinstance(rid, list) and rid else (rid if isinstance(rid, str) else "")
        matrices.append({
            "file_id": r["file_id"],
            "file_name": r["file_name"],
            "package_id": r["package_id"],
            "file_size": float(r["file_size"] or 0),
            "redcap": rid,
            "sample_type": (r["sample_type"] or [""])[0] if isinstance(r["sample_type"], list) else str(r["sample_type"]),
            "enrollment": (r["enrollment_category"] or [""])[0] if isinstance(r["enrollment_category"], list) else str(r["enrollment_category"]),
        })
    print("matrix files in repo:", len(matrices))

    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    ref = meta[meta["condition.l2"] == "Ref"]
    libraries = (ref.groupby("patient")["library"].unique().to_dict())
    print("reference patients:", len(libraries))

    manifest, downloads = [], []
    unmatched = []
    for patient, libs in libraries.items():
        matched = False
        for lib in libs:
            target = norm(lib)
            best = None
            for m in matrices:
                rid = norm(m["redcap"])
                if not rid:
                    continue
                if rid == target or rid.endswith(target) or target.endswith(rid) or target in rid or rid in target:
                    score = abs(len(rid) - len(target))
                    if best is None or score < best[0]:
                        best = (score, m)
            if best is None:
                continue
            m = best[1]
            manifest.append({
                "file_id": m["file_id"], "participants": patient, "library": lib,
                "KDIGO Stage": float("nan"), "file_name": m["file_name"],
                "experimental_strategy": "Single-cell RNA-Seq",
                "sample_type": m["sample_type"], "enrollment": m["enrollment"],
                "file_size": m["file_size"],
            })
            downloads.append(f"{BASE}/{m['package_id']}/{m['file_name']}|"
                             f"data/KPMP/sc_ref/{m['file_id']}_{m['file_name']}|{int(m['file_size'])}")
            matched = True
        if not matched:
            unmatched.append((patient, list(libs)))

    table = pd.DataFrame(manifest)
    table.to_csv(META / "KPMP_open_Ref_single_sample_matrices.csv", index=False)
    (Path("/tmp/kpmp_ref_sc_download_list.txt")).write_text("\n".join(downloads) + "\n")

    print(f"matched {table['participants'].nunique()} patients / {len(table)} libraries")
    print(f"total download {table['file_size'].sum()/1048576:.1f} MB")
    if unmatched:
        print("unmatched patients:")
        for patient, libs in unmatched:
            print("  ", patient, libs)
    print("saved manifest and /tmp/kpmp_ref_sc_download_list.txt")


if __name__ == "__main__":
    main()
