#!/usr/bin/env python3
"""Assemble the code/data-availability release bundle (Zenodo/GitHub ready).

Contents: analysis scripts, the authoritative numbers table, all reports, the
environment specification and data-availability metadata. Raw data are not
redistributed (all sources are public; accessions are listed).
"""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from datetime import date
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RELEASE = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair_release")
VERSION = date.today().isoformat()


def build_readme() -> str:
    return f"""# Human AKI tubular injury/repair analysis code

Release {VERSION}. Cross-sectional re-analysis of public human kidney
transcriptomes: KPMP single-cell and single-nucleus atlases, an independent
single-nucleus cohort (GSE210622), 16 KPMP Visium sections, plus bulk kidney,
blood and clinical validation cohorts.

## What is included

| Path | Content |
|---|---|
| `code/scripts/` | analysis scripts, numbered in execution order (`scripts/README.md` explains each) |
| `results/FINAL_manuscript_numbers.csv` | the single authoritative numbers table (all headline statistics) |
| `results/FINAL_cohort_accounting.csv` | libraries/participants per dataset (used for n reporting) |
| `reports/` | analysis reports, including the reviewer-response analyses |
| `environment.yml`, `R_packages.txt` | software versions |

## Reproducing

1. Download the public inputs listed in `DATA_AVAILABILITY.md` (all open access).
2. Install the environment (`environment.yml` for Python, `R_packages.txt` for R).
3. Run the scripts in numerical order; the key entry points are
   `22_PT_pseudobulk.py` (PT-level pseudobulk), `26_GSE210622_PT_pseudobulk.py`
   (independent cohort), `20_spatial_pilot_analysis.py` (Visium), `21a/21c` and
   `49/50` (RCTD with the two reference panels), `39`-`48` (reviewer-response
   analyses), `47_final_numbers.py` (numbers table).

## Key methodological points

* Statistics are patient level; libraries from the same participant are
  aggregated by median.
* Signature scores are z-scored across expressed genes within each library
  before averaging, so scores are comparable across samples and platforms.
* FDR is reported twice: within predefined feature families and globally within
  each analysis level and contrast.
* Two independent RCTD references (GSE210622 and KPMP sn) are run on the same
  spatial sections; agreement between them is reported.

## Data availability

See `DATA_AVAILABILITY.md`. This repository contains no raw or controlled-access
data.
"""


def write_environment() -> None:
    python_packages = """name: aki-repair
channels:
  - conda-forge
dependencies:
  - python=3.9
  - numpy=1.26.4
  - pandas=2.3.3
  - scipy=1.13.1
  - statsmodels=0.14.4
  - scikit-learn=1.6.1
  - matplotlib=3.4.3
  - pip
  - pip:
      - umap-learn==0.5.9.post2
      - anndata==0.10.9
"""
    (RELEASE / "environment.yml").write_text(python_packages)
    r_packages = """R 4.5.0
Matrix 1.7.4
spacexr 2.2.1        # RCTD deconvolution
Seurat 5.3.0
SpatialExperiment 1.18.0
uwot 0.2.3           # UMAP
limma, edgeR         # bulk validation (optional)
"""
    (RELEASE / "R_packages.txt").write_text(r_packages)


def write_data_availability() -> None:
    text = """# Data availability

All primary data are openly available; no controlled-access or individual-level
data are redistributed here.

| Resource | Accession / location | Use |
|---|---|---|
| KPMP single-cell atlas metadata | GEO GSE183276 | PT/state annotations, discovery cohort |
| KPMP single-nucleus atlas metadata | GEO GSE183277 | sn annotations, KPMP sn RCTD reference |
| KPMP repository matrices (sc AKI / Reference / CKD) | https://atlas.kpmp.org (open access) | PT-level pseudobulk |
| KPMP repository matrices (sn) | https://atlas.kpmp.org (open access) | sn PT-level pseudobulk, RCTD reference |
| KPMP Visium sections | https://atlas.kpmp.org (open access) | spatial validation |
| GSE210622 | GEO | independent sn cohort, second RCTD reference |
| GSE139061 | GEO | bulk kidney signature validation |
| GSE67401 | GEO | blood specificity control, KDIGO meta-analysis |
| GSE122274 | GEO | sepsis kidney biopsy (exploratory) |
| Urine AKI cohort | GitHub (public repository cited in the manuscript) | clinical trajectories |
| KPMP open clinical table | KPMP website (`20260930_OpenAccessClinicalData.csv`) | baseline characteristics |

Derived tables and figures accompany the manuscript; the scripts here regenerate
them from the public inputs.
"""
    (RELEASE / "DATA_AVAILABILITY.md").write_text(text)


def write_zenodo() -> None:
    metadata = {
        "title": "Human AKI tubular injury and repair: analysis code",
        "upload_type": "software",
        "description": ("Analysis code for a cross-sectional re-analysis of public human kidney "
                        "transcriptomes (KPMP sc/sn atlases, GSE210622, KPMP Visium, bulk and "
                        "clinical validation cohorts), covering PT-level pseudobulk, spatial "
                        "deconvolution with two reference panels, and reviewer-response analyses."),
        "creators": [{"name": "TODO: author list"}],
        "license": "TODO",
        "keywords": ["acute kidney injury", "proximal tubule", "single-cell", "spatial transcriptomics"],
        "related_identifiers": [{"identifier": "TODO: manuscript DOI", "relation": "isSupplementTo"}],
        "version": VERSION,
        "language": "eng",
    }
    (RELEASE / ".zenodo.json").write_text(json.dumps(metadata, indent=2) + "\n")


def copy_artefacts() -> list[Path]:
    copied = []
    scripts_src = ROOT / "scripts"
    scripts_dst = RELEASE / "code/scripts"
    if scripts_dst.exists():
        shutil.rmtree(scripts_dst)
    scripts_dst.mkdir(parents=True, exist_ok=True)
    for path in sorted(scripts_src.iterdir()):
        if path.is_file() and path.suffix in {".py", ".R", ".sh", ".md"}:
            shutil.copy2(path, scripts_dst / path.name)
            copied.append(scripts_dst / path.name)
    for name in ("FINAL_manuscript_numbers.csv", "FINAL_cohort_accounting.csv",
                 "Klocke_signature_genes.csv"):
        src = ROOT / "results" / name
        if src.exists():
            shutil.copy2(src, RELEASE / "results" / name)
            copied.append(RELEASE / "results" / name)
    reports_dst = RELEASE / "reports"
    if reports_dst.exists():
        shutil.rmtree(reports_dst)
    reports_dst.mkdir(parents=True, exist_ok=True)
    for path in sorted((ROOT / "reports").glob("*.md")):
        shutil.copy2(path, reports_dst / path.name)
        copied.append(reports_dst / path.name)
    return copied


def checksums(paths: list[Path]) -> None:
    lines = []
    for path in sorted(paths):
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b""):
                digest.update(chunk)
        lines.append(f"{digest.hexdigest()}  {path.relative_to(RELEASE)}")
    (RELEASE / "CHECKSUMS.sha256").write_text("\n".join(lines) + "\n")


def main() -> None:
    RELEASE.mkdir(parents=True, exist_ok=True)
    (RELEASE / "results").mkdir(exist_ok=True)
    (RELEASE / "README.md").write_text(build_readme())
    write_environment()
    write_data_availability()
    write_zenodo()
    copied = copy_artefacts()
    checksums(copied)
    archive = RELEASE.parent / f"aki_repair_release_{VERSION}.tar.gz"
    subprocess.run(["tar", "-czf", str(archive), "-C", str(RELEASE.parent), RELEASE.name], check=True)
    size_mb = archive.stat().st_size / 1048576
    print(f"release: {RELEASE} ({len(copied)} files)")
    print(f"archive: {archive} ({size_mb:.1f} MB)")


if __name__ == "__main__":
    main()
