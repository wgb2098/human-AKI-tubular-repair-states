#!/usr/bin/env python3
"""Assemble key findings and summary figures for the AKI repair direction."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
FIG = ROOT / "figures"

KEY_FEATURES = [
    "frac_state_adaptive - epi", "frac_state_cycling", "frac_state_reference",
    "frac_state_degenerative", "frac_sub_IMM", "frac_sub_FIB", "mean_aEpi.score",
    "mean_degen.score", "mean_cyc.score", "mean_matrisome.score",
]
LABELS = {
    "frac_state_adaptive - epi": "Adaptive epithelial",
    "frac_state_cycling": "Cycling",
    "frac_state_reference": "Reference epithelial",
    "frac_state_degenerative": "Degenerative",
    "frac_sub_IMM": "Immune cells",
    "frac_sub_FIB": "Fibroblasts",
    "mean_aEpi.score": "aEpi score",
    "mean_degen.score": "Degenerative score",
    "mean_cyc.score": "Cycling score",
    "mean_matrisome.score": "Matrisome score",
}


def read_tests(cohort: str) -> pd.DataFrame:
    return pd.read_csv(RES / f"KPMP_{cohort}_feature_tests.csv")


def effect_bar() -> None:
    sc, sn = read_tests("sc"), read_tests("sn")
    features = [f for f in KEY_FEATURES if f in sc["feature"].values]
    x = np.arange(len(features))
    width = 0.36
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.5), gridspec_kw={"width_ratios": [2.2, 1]})

    for offset, tests, cohort, color in [(-width / 2, sc, "sc", "#2874A6"), (width / 2, sn, "sn", "#C0392B")]:
        data = tests.set_index("feature").reindex(features)
        vals = data["mannwhitney_p_aki_vs_ref"].fillna(1)
        score = -np.log10(vals.clip(lower=1e-300))
        axes[0].bar(x + offset, score, width, color=color, label=cohort)
        for xi, (p, fdr) in enumerate(zip(vals, data["fdr_aki_vs_ref"].fillna(1))):
            if fdr < 0.05:
                axes[0].text(xi + offset, score.iloc[xi] + 0.15, "*", ha="center", fontsize=12)
    axes[0].axhline(-np.log10(0.05), color="grey", ls="--", lw=1)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([LABELS.get(f, f) for f in features], rotation=35, ha="right")
    axes[0].set_ylabel("-log10 P (AKI vs Reference)")
    axes[0].set_title("AKI vs Reference (patient-level)")
    axes[0].legend(frameon=False)

    # Stage heatmap (sc)
    samples = pd.read_csv(RES / "KPMP_sc_sample_composition_scores.csv")
    aki = samples[samples["condition"] == "AKI"]
    stage = pd.to_numeric(aki["stage"], errors="coerce")
    heat = []
    for f in features:
        row = [aki.loc[stage == s, f].mean() for s in [1, 2, 3]]
        heat.append(row)
    heat = np.asarray(heat, dtype=float)
    z = (heat - np.nanmean(heat, axis=1, keepdims=True)) / np.nanstd(heat, axis=1, keepdims=True)
    im = axes[1].imshow(z, cmap="RdBu_r", vmin=-1.5, vmax=1.5, aspect="auto")
    axes[1].set_xticks([0, 1, 2]); axes[1].set_xticklabels(["Stage 1", "Stage 2", "Stage 3"])
    axes[1].set_yticks(range(len(features))); axes[1].set_yticklabels([LABELS.get(f, f) for f in features])
    for i in range(len(features)):
        for j in range(3):
            axes[1].text(j, i, f"{heat[i, j]:.2f}", ha="center", va="center", fontsize=7)
    axes[1].set_title("sc: stage means (row z)")
    fig.colorbar(im, ax=axes[1], shrink=0.7, label="row z-score")
    fig.tight_layout()
    fig.savefig(FIG / "Fig_AKI_vs_Ref_and_stage_heatmap.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_AKI_vs_Ref_and_stage_heatmap.pdf", bbox_inches="tight")
    plt.close(fig)


def key_findings_table() -> pd.DataFrame:
    rows = []
    for cohort in ["sc", "sn"]:
        tests = read_tests(cohort).set_index("feature")
        for feature in KEY_FEATURES:
            if feature in tests.index:
                row = tests.loc[feature]
                rows.append({
                    "cohort": cohort, "feature": LABELS.get(feature, feature),
                    "spearman_rho_stage": row.get("spearman_rho_stage"),
                    "spearman_p_stage": row.get("spearman_p_stage"),
                    "fdr_stage": row.get("fdr_stage"),
                    "mannwhitney_p_AKI_vs_Ref": row.get("mannwhitney_p_aki_vs_ref"),
                    "fdr_AKI_vs_Ref": row.get("fdr_aki_vs_ref"),
                    "mean_stage1": row.get("mean_stage1"), "mean_stage2": row.get("mean_stage2"),
                    "mean_stage3": row.get("mean_stage3"),
                    "mean_AKI": row.get("mean_aki"), "mean_Ref": row.get("mean_ref"),
                })
    table = pd.DataFrame(rows)
    table.to_csv(RES / "KEY_FINDINGS_AKI_repair.csv", index=False)

    urine = pd.read_csv(RES / "urine_AKI_recovery_metrics.csv")
    urine_unique = urine.drop_duplicates("patient_base")
    stage = pd.to_numeric(urine_unique["KDIGO_AKI_stage"], errors="coerce")
    rho, p = stats.spearmanr(stage, urine_unique["creatinine_log_slope"], nan_policy="omit")
    summary = [{
        "analysis": "urine cohort", "n_patients": len(urine_unique),
        "stage_vs_creatinine_log_slope_rho": rho, "p": p,
    }]
    pd.DataFrame(summary).to_csv(RES / "urine_recovery_correlation.csv", index=False)
    return table


def main() -> None:
    effect_bar()
    table = key_findings_table()
    pd.set_option("display.width", 200)
    print(table.to_string(index=False))
    print("\nUrine recovery correlation:")
    print(pd.read_csv(RES / "urine_recovery_correlation.csv").to_string(index=False))


if __name__ == "__main__":
    main()
