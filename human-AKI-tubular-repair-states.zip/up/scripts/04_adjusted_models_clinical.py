#!/usr/bin/env python3
"""Adjusted severity models, ATI/AIN comparison and urine-cohort clinical validation."""

from __future__ import annotations

import re
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"
RES = ROOT / "results"
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({"figure.dpi": 150, "font.size": 9, "axes.spines.top": False, "axes.spines.right": False})


def load_samples(cohort: str) -> pd.DataFrame:
    df = pd.read_csv(RES / f"KPMP_{cohort}_sample_composition_scores.csv")
    df = df.loc[:, ~df.columns.duplicated()]
    clinical = pd.read_csv(META / "20260930_OpenAccessClinicalData.csv")
    clinical.columns = [c.strip() for c in clinical.columns]
    clinical["Participant ID"] = clinical["Participant ID"].astype(str)
    df["patient"] = df["patient"].astype(str)
    merged = df.merge(
        clinical[["Participant ID", "Age (Years) (Binned)", "Sex"]],
        left_on="patient", right_on="Participant ID", how="left",
    )
    merged["age_mid"] = merged["Age (Years) (Binned)"].astype(str).str.extract(r"(\d+)").astype(float) + 4.5
    merged["aki_indicator"] = (merged["condition"] == "AKI").astype(int)
    merged["stage_num"] = pd.to_numeric(merged["stage"], errors="coerce")
    return merged


def adjusted_models(samples: pd.DataFrame, cohort: str) -> pd.DataFrame:
    aki = samples[samples["aki_indicator"] == 1].copy()
    features = list(dict.fromkeys(c for c in samples.columns if c.startswith(("frac_state_", "frac_sub_", "mean_aEpi", "mean_degen",
                                                           "mean_cyc", "mean_aStr", "mean_matrisome", "mean_collagen"))))
    rows = []
    for feature in features:
        data = aki[["stage_num", feature, "baseline_eGFR", "age_mid", "Sex"]].dropna()
        if len(data) < 6 or data["stage_num"].nunique() < 2:
            continue
        data = data.copy()
        data["male"] = (data["Sex"].astype(str).str.upper() == "M").astype(int)
        X = sm.add_constant(data[["stage_num", "baseline_eGFR", "age_mid", "male"]])
        try:
            model = sm.OLS(data[feature], X).fit(cov_type="HC3")
            stage_param = model.params.get("stage_num", np.nan)
            stage_se = model.bse.get("stage_num", np.nan)
            rows.append({
                "cohort": cohort, "feature": feature, "n_patients": len(data),
                "stage_beta": stage_param,
                "stage_se": stage_se,
                "stage_ci_low": stage_param - 1.96 * stage_se,
                "stage_ci_high": stage_param + 1.96 * stage_se,
                "stage_p": model.pvalues.get("stage_num", np.nan),
                "egfr_p": model.pvalues.get("baseline_eGFR", np.nan),
            })
        except Exception:
            continue
    out = pd.DataFrame(rows)
    if not out.empty:
        from statsmodels.stats.multitest import multipletests
        out["stage_fdr"] = multipletests(out["stage_p"], method="fdr_bh")[1]
        out = out.sort_values("stage_p")
    out.to_csv(RES / f"KPMP_{cohort}_adjusted_stage_models.csv", index=False)
    return out


def ati_vs_other(samples: pd.DataFrame, cohort: str) -> pd.DataFrame:
    aki = samples[samples["aki_indicator"] == 1]
    rows = []
    for feature in [c for c in samples.columns if c.startswith(("frac_state_", "frac_sub_", "mean_aEpi", "mean_degen",
                                                                "mean_cyc", "mean_aStr", "mean_matrisome"))]:
        ati = aki.loc[aki["adjudicated"] == "Acute Tubular Injury", feature].dropna()
        other = aki.loc[aki["adjudicated"] != "Acute Tubular Injury", feature].dropna()
        if len(ati) >= 3 and len(other) >= 3:
            rows.append({
                "cohort": cohort, "feature": feature, "n_ATI": len(ati), "n_other": len(other),
                "mean_ATI": ati.mean(), "mean_other": other.mean(),
                "mannwhitney_p": stats.mannwhitneyu(ati, other).pvalue,
            })
    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values("mannwhitney_p")
    out.to_csv(RES / f"KPMP_{cohort}_ATI_vs_other.csv", index=False)
    return out


def urine_cohort() -> pd.DataFrame:
    base = ROOT / "data/UrineAKI_github"
    patients = pd.read_csv(base / "Urine_AKI_patient_data.csv", sep=";")
    patients.columns = [c.strip() for c in patients.columns]
    patients = patients.loc[:, ~patients.columns.duplicated()]
    urine = pd.read_csv(base / "Urine_AKI_urine_output_crea_data.csv", sep=";")
    urine.columns = [c.strip() for c in urine.columns]
    urine = urine.loc[:, ~urine.columns.duplicated()]
    urine["serum_creatinine"] = pd.to_numeric(urine["serum_creatinine"], errors="coerce")
    urine["urinary_output"] = pd.to_numeric(urine["urinary_output"], errors="coerce")
    urine["day"] = pd.to_numeric(urine["day"], errors="coerce")
    urine = urine.dropna(subset=["patient", "day"])

    rows = []
    for patient, group in urine.groupby("patient"):
        group = group.sort_values("day")
        scr = group["serum_creatinine"].dropna()
        post = group[group["day"] >= 0]
        if len(post) < 4 or post["serum_creatinine"].notna().sum() < 3:
            continue
        x = post.loc[post["serum_creatinine"].notna(), "day"].values
        y = post.loc[post["serum_creatinine"].notna(), "serum_creatinine"].values
        slope = np.polyfit(x, np.log(np.clip(y, 0.2, None)), 1)[0] if len(x) >= 3 else np.nan
        baseline = y[0]
        peak = np.nanmax(y)
        final = y[-1]
        rows.append({
            "patient": patient, "n_timepoints": len(post),
            "baseline_creatinine": baseline, "peak_creatinine": peak, "final_creatinine": final,
            "creatinine_log_slope": slope,
            "relative_final": final / baseline if baseline else np.nan,
            "urine_output_mean": post["urinary_output"].mean(),
        })
    trajectory = pd.DataFrame(rows)
    patients["patient_base"] = patients["patient"].astype(str).str.replace(r"\.\d+$", "", regex=True)
    trajectory["patient_base"] = trajectory["patient"].astype(str).str.replace(r"\.\d+$", "", regex=True)
    merged = patients.merge(trajectory, on="patient_base", how="inner", suffixes=("_meta", ""))
    merged = merged.drop_duplicates("patient_base")
    merged.to_csv(RES / "urine_AKI_recovery_metrics.csv", index=False)
    urine.to_csv(RES / "urine_AKI_longitudinal_clean.csv", index=False)

    # Plot individual creatinine and urine-output trajectories, colored by KDIGO stage.
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    colors = {1: "#5DADE2", 2: "#F5B041", 3: "#C0392B"}
    patients["patient_base"] = patients["patient"].astype(str).str.replace(r"\.\d+$", "", regex=True)
    stage_map = patients.drop_duplicates("patient_base").set_index("patient_base")["KDIGO_AKI_stage"]
    for patient, group in urine.groupby("patient"):
        stage_raw = str(stage_map.get(patient, "")).strip()
        stage_val = pd.to_numeric(stage_raw, errors="coerce")
        stage = int(stage_val) if pd.notna(stage_val) else None
        color = colors.get(stage, "grey")
        x = group["day"].to_numpy(dtype=float).reshape(-1)
        y = pd.to_numeric(group["serum_creatinine"], errors="coerce").to_numpy(dtype=float).reshape(-1)
        u = pd.to_numeric(group["urinary_output"], errors="coerce").to_numpy(dtype=float).reshape(-1)
        axes[0].plot(x, y, color=color, alpha=0.7, marker="o", ms=2)
        axes[1].plot(x, u, color=color, alpha=0.7, marker="o", ms=2)
    axes[0].set(xlabel="Day relative to sampling", ylabel="Serum creatinine (mg/dL)",
                title="Creatinine trajectories (urine AKI cohort)")
    axes[1].set(xlabel="Day relative to sampling", ylabel="Urine output (mL/day)",
                title="Urine-output trajectories")
    handles = [plt.Line2D([0], [0], color=colors[s], label=f"KDIGO stage {s}") for s in colors]
    axes[1].legend(handles=handles, frameon=False)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_urine_trajectories.png", dpi=300)
    fig.savefig(FIG / "Fig_urine_trajectories.pdf")
    plt.close(fig)
    return merged


def sample_level_figure(sc: pd.DataFrame, sn: pd.DataFrame) -> None:
    features = [
        ("frac_state_adaptive - epi", "Adaptive epithelial"),
        ("frac_state_cycling", "Cycling"),
        ("frac_state_reference", "Reference epithelial"),
        ("frac_sub_IMM", "Immune cells"),
        ("frac_sub_FIB", "Fibroblasts"),
        ("mean_aEpi.score", "aEpi score"),
    ]
    fig, axes = plt.subplots(2, 3, figsize=(12, 7))
    for ax, (feature, title) in zip(axes.ravel(), features):
        for cohort, df, offset, color in [("sc", sc, -0.16, "#2874A6"), ("sn", sn, 0.16, "#C0392B")]:
            data = df[df["stage_num"].isin([1, 2, 3])][["stage_num", feature]].dropna()
            positions = data["stage_num"] + offset
            ax.scatter(positions, data[feature], s=14, alpha=0.65, color=color, label=cohort)
            means = data.groupby("stage_num")[feature].mean()
            ax.plot(np.asarray(means.index, dtype=float) + offset,
                    np.asarray(means, dtype=float).reshape(-1), color=color, lw=1.5)
        ax.set_xticks([1, 2, 3])
        ax.set_xticklabels(["Stage 1", "Stage 2", "Stage 3"])
        ax.set_title(title)
        ax.set_ylabel("Sample-level value")
    axes[0, 0].legend(frameon=False)
    fig.suptitle("KPMP human AKI: cell states and repair scores across KDIGO severity", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_KDIGO_state_scores.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_KDIGO_state_scores.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    sc = load_samples("sc")
    sn = load_samples("sn")
    models_sc = adjusted_models(sc, "sc")
    models_sn = adjusted_models(sn, "sn")
    ati_sc = ati_vs_other(sc, "sc")
    ati_sn = ati_vs_other(sn, "sn")
    recovery = urine_cohort()
    sample_level_figure(sc, sn)

    print("Adjusted stage models (sc), top:")
    print(models_sc.head(12).to_string(index=False))
    print("\nAdjusted stage models (sn), top:")
    print(models_sn.head(12).to_string(index=False))
    print("\nATI vs other adjudicated categories (sc), top:")
    print(ati_sc.head(10).to_string(index=False))
    print("\nUrine recovery metrics:")
    print(recovery[["patient_base", "patient", "KDIGO_AKI_stage", "baseline_creatinine", "peak_creatinine",
                    "final_creatinine", "creatinine_log_slope"]].to_string(index=False))
    if len(recovery) >= 5:
        stage = pd.to_numeric(recovery["KDIGO_AKI_stage"], errors="coerce")
        rho, p = stats.spearmanr(stage, recovery["creatinine_log_slope"], nan_policy="omit")
        print(f"\nKDIGO stage vs creatinine log-slope: rho={rho:.3f}, p={p:.3f}, n={len(recovery)}")


if __name__ == "__main__":
    main()
