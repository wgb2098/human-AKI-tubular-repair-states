#!/usr/bin/env python3
"""按 cell subclass 导出患者级 pseudobulk（用于③的配体-受体分析：PT/免疫/成纤维）。"""
from __future__ import annotations
import gzip, io, re, zipfile, sys
from multiprocessing import Pool
from pathlib import Path
import numpy as np, pandas as pd
from scipy import sparse
from scipy.io import mmwrite

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
OUT = ROOT / "data/celltype_pseudobulk"
META = ROOT / "metadata"
CELL_META = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"
TYPES = ["PT", "IMM", "FIB", "EC"]
MIN_CELLS = 20
G: dict = {}

def worker(job):
    file_id, participant, directory = job
    matches = sorted(ROOT.glob(f"{directory}/{file_id}*.zip"))
    if not matches: return None
    mapping = G["cells"].get(participant)
    if not mapping: return None
    try:
        with zipfile.ZipFile(matches[0]) as zf:
            names = zf.namelist()
            def read(name):
                with zf.open(name) as h: data = h.read()
                return gzip.decompress(data) if name.endswith(".gz") else data
            mtx = next(n for n in names if "matrix" in n.lower() and ".mtx" in n.lower())
            feat = next(n for n in names if "features" in n.lower() or "genes" in n.lower())
            bc = next(n for n in names if "barcode" in n.lower())
            whitelist = read(bc).decode(errors="replace").split()
            body = read(mtx).split(b"\n", 3)[3]
            features = pd.read_csv(io.BytesIO(read(feat)), sep="\t", header=None)
        genes = (features.iloc[:,1].astype(str) if features.shape[1]>1 else features.iloc[:,0]).tolist()
        genes = [re.sub(r"^[A-Za-z0-9]+_{4}", "", g) for g in genes]
        index = {b: i+1 for i, b in enumerate(whitelist)}
        wanted = {}
        for ctype, barcodes in mapping.items():
            pos = {index[b] for b in barcodes if b in index}
            if len(pos) >= MIN_CELLS: wanted[ctype] = pos
        if not wanted: return None
        df = pd.read_csv(io.BytesIO(body), sep=" ", header=None, names=["g","c","v"],
                         dtype={"g": np.int32, "c": np.int32, "v": np.float32}, engine="c")
        out = {"participant": participant, "genes": genes, "counts": {}}
        for ctype, pos in wanted.items():
            sub = df[df["c"].isin(pos)]
            counts = np.rint(np.bincount(sub["g"].to_numpy()-1, weights=sub["v"].to_numpy(),
                                         minlength=len(genes))).astype(np.int64)
            out["counts"][ctype] = (counts, len(pos))
        return out
    except Exception as exc:
        print("skip", file_id, exc); return None

def main():
    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    meta["barcode"] = meta.index.str.split("_", n=1).str[1]
    meta["patient"] = meta["patient"].astype(str)
    cells = {}
    for patient, group in meta.groupby("patient"):
        mapping = {}
        for t in TYPES:
            b = set(group.loc[group["subclass.l1"] == t, "barcode"])
            if b: mapping[t] = b
        if mapping: cells[patient] = mapping
    G["cells"] = cells
    print("patients:", len(cells))
    jobs = []
    for manifest, directory in [("KPMP_open_AKI_single_sample_matrices.csv","data/KPMP/sc"),
                                ("KPMP_open_Ref_single_sample_matrices.csv","data/KPMP/sc_ref"),
                                ("KPMP_open_CKD_single_sample_matrices.csv","data/KPMP/sc_ckd")]:
        frame = pd.read_csv(META/manifest)
        if "experimental_strategy" in frame.columns:
            frame = frame[frame["experimental_strategy"].astype(str).str.contains("Single-cell", na=False)]
        for _, row in frame.iterrows():
            if str(row["participants"]) in cells:
                jobs.append((str(row["file_id"]), str(row["participants"]), directory))
    print("jobs:", len(jobs))
    with Pool(6) as pool:
        results = [r for r in pool.map(worker, jobs) if r]
    OUT.mkdir(parents=True, exist_ok=True)
    shared = sorted(set.intersection(*[set(r["genes"]) for r in results]))
    (OUT/"genes.txt").write_text("\n".join(shared)+"\n")
    print("shared genes:", len(shared), "| matrices:", len(results))
    for t in TYPES:
        per = {}
        for r in results:
            if t not in r["counts"]: continue
            counts, n = r["counts"][t]
            idx = {g:i for i,g in enumerate(r["genes"])}
            vec = counts[[idx[g] for g in shared]]
            if r["participant"] in per: per[r["participant"]] = (per[r["participant"]][0]+vec, per[r["participant"]][1]+n)
            else: per[r["participant"]] = (vec, n)
        if not per: print("no data for", t); continue
        pids = sorted(per)
        mat = np.vstack([per[p][0] for p in pids]).T
        mmwrite(OUT/f"{t}_counts.mtx", sparse.csr_matrix(mat.astype(np.int32)))
        pd.DataFrame({"patient": pids, "n_cells": [per[p][1] for p in pids]}).to_csv(OUT/f"{t}_samples.csv", index=False)
        print(f"  {t}: {len(pids)} patients, {int(sum(per[p][1] for p in pids))} cells")

if __name__ == "__main__":
    main()
