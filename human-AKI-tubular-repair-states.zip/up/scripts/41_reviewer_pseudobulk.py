#!/usr/bin/env python3
"""Reviewer requests 1 and 4: patient-level and composition-adjusted whole-library pseudobulk.

The whole-library pseudobulk of 42 AKI versus 72 reference libraries treats
libraries as independent and is confounded by the PT fraction of each library.
Here we (i) re-test at the patient level and (ii) adjust for the annotated PT
fraction in the subset of libraries that have cell-level metadata, then contrast
the result with the PT-only pseudobulk of script 22.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
SIGNATURES = ["injury_stress", "repair_progenitor", "cycling", "reference_PT"]


def main() -> None:
    lib = pd.read_csv(RES / "KPMP_combined_pseudobulk_signatures.csv")
    lib["group_simple"] = np.where(lib["group"] == "AKI", "AKI", "Ref")
    score_cols = [f"{s}_score" for s in SIGNATURES]

    # ---------- 1) library level vs patient level ----------
    rows = []
    patient_level = lib.groupby(["group_simple", "participant"], as_index=False)[score_cols].median()
    for signature, column in zip(SIGNATURES, score_cols):
        a_lib = lib.loc[lib["group_simple"] == "AKI", column].dropna()
        b_lib = lib.loc[lib["group_simple"] == "Ref", column].dropna()
        a_pat = patient_level.loc[patient_level["group_simple"] == "AKI", column].dropna()
        b_pat = patient_level.loc[patient_level["group_simple"] == "Ref", column].dropna()
        rows.append({
            "signature": signature,
            "n_lib_AKI": len(a_lib), "n_lib_Ref": len(b_lib),
            "n_pat_AKI": len(a_pat), "n_pat_Ref": len(b_pat),
            "median_lib_AKI": a_lib.median(), "median_lib_Ref": b_lib.median(),
            "p_library_level": stats.mannwhitneyu(a_lib, b_lib).pvalue,
            "median_pat_AKI": a_pat.median(), "median_pat_Ref": b_pat.median(),
            "p_patient_level": stats.mannwhitneyu(a_pat, b_pat).pvalue,
        })
    comparison = pd.DataFrame(rows)
    for column in ("p_library_level", "p_patient_level"):
        comparison[f"fdr_{column}"] = multipletests(comparison[column], method="fdr_bh")[1]
    comparison.to_csv(RES / "reviewer_pseudobulk_library_vs_patient.csv", index=False)
    print("Whole-library pseudobulk: library level vs patient level")
    print(comparison.round(4).to_string(index=False))
    print(f"\npatients: {patient_level['group_simple'].value_counts().to_dict()} "
          f"(libraries: {lib['group_simple'].value_counts().to_dict()})")

    # ---------- 2) composition adjustment ----------
    meta = pd.read_csv(ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz",
                       sep="\t", index_col=0, low_memory=False)
    comp = (meta.assign(is_pt=meta["subclass.l1"] == "PT")
            .groupby("patient", as_index=False)["is_pt"].mean()
            .rename(columns={"patient": "participant", "is_pt": "pt_fraction"}))
    # participant ids differ slightly between the atlas and the repository
    # (e.g. 1157EO2 vs Sample1157-EO2), so join on a normalised key
    def norm(text: object) -> str:
        return re.sub(r"[^a-z0-9]", "", str(text).lower())

    comp["key"] = comp["participant"].map(norm)
    lib["key"] = lib["participant"].map(norm)
    merged = lib.merge(comp.drop(columns=["participant"]), on="key", how="inner")
    print(f"\nlibraries with annotated composition: {len(merged)} "
          f"({merged['group_simple'].value_counts().to_dict()})")

    adj_rows = []
    for signature, column in zip(SIGNATURES, score_cols):
        subset = merged[["group_simple", "pt_fraction", column]].dropna()
        if subset["group_simple"].value_counts().min() < 5:
            continue
        rho, p_rho = stats.spearmanr(subset[column], subset["pt_fraction"])
        subset = subset.assign(rank_score=subset[column].rank(pct=True))
        design = pd.DataFrame({
            "group_AKI": (subset["group_simple"] == "AKI").astype(float),
            "pt_fraction": subset["pt_fraction"].astype(float),
        })
        design = sm.add_constant(design)
        model = sm.OLS(subset["rank_score"], design).fit(cov_type="HC3")
        design_plain = sm.add_constant(pd.DataFrame({"group_AKI": (subset["group_simple"] == "AKI").astype(float)}))
        model_plain = sm.OLS(subset["rank_score"], design_plain).fit(cov_type="HC3")
        adj_rows.append({
            "signature": signature,
            "n_AKI": int((subset["group_simple"] == "AKI").sum()),
            "n_Ref": int((subset["group_simple"] == "Ref").sum()),
            "rho_score_vs_PTfraction": rho, "p_rho_vs_PTfraction": p_rho,
            "p_group_unadjusted": model_plain.pvalues["group_AKI"],
            "p_group_adjusted_PTfraction": model.pvalues["group_AKI"],
            "beta_group_adjusted": model.params["group_AKI"],
        })
    adjusted = pd.DataFrame(adj_rows)
    if len(adjusted):
        adjusted["fdr_adjusted"] = multipletests(adjusted["p_group_adjusted_PTfraction"], method="fdr_bh")[1]
    adjusted.to_csv(RES / "reviewer_pseudobulk_composition_adjusted.csv", index=False)
    print("\nWhole-library pseudobulk adjusted for the annotated PT fraction")
    print(adjusted.round(4).to_string(index=False))

    print("\nFor comparison, PT-only pseudobulk (script 22, patient level):")
    pt = pd.read_csv(RES / "KPMP_sc_PT_pseudobulk_AKI_vs_Ref.csv")
    print(pt.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
