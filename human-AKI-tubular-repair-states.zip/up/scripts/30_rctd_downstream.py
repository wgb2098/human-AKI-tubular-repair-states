#!/usr/bin/env python3
"""Downstream analysis of the RCTD deconvolution of KPMP Visium samples.

Per spot: signature scores (injury/stress, repair progenitor, cycling, reference)
from the Visium counts; per spot: compartment fractions from RCTD. Then
spot-level colocalisation, per-sample aggregation and KDIGO-stage trends.
"""

from __future__ import annotations

import gzip
import io
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.io import mmread
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
SPATIAL = ROOT / "data/KPMP_spatial"
RES = ROOT / "results"
META = ROOT / "metadata"

CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]
SIGNATURE_LABELS = {
    "injury_stress": "Injury/stress",
    "repair_progenitor": "Repair progenitor",
    "cycling": "Cycling",
    "reference_PT": "Reference state",
}
COMPARTMENTS = {
    "PT": ["PT"],
    "TAL": ["TAL"],
    "distal": ["DCT", "CNT", "CD-PC", "CD-IC-A", "CD-IC-B", "tL", "IntC"],
    "endothelium": ["EC"],
    "immune": ["Leuk"],
    "podocyte": ["Podo"],
}


def spot_scores(counts: np.ndarray, genes: list[str], signatures: dict[str, list[str]]) -> pd.DataFrame:
    totals = counts.sum(axis=0)
    keep = totals > 0
    logcpm = np.zeros_like(counts, dtype=np.float32)
    logcpm[:, keep] = np.log2(counts[:, keep] / totals[keep] * 1e6 + 1)
    frame = pd.DataFrame(logcpm, index=genes)
    frame = frame[~frame.index.duplicated(keep="first")]
    z = frame.sub(frame.mean(axis=1), axis=0).div(frame.std(axis=1).replace(0, np.nan), axis=0)
    out = {}
    for name, gene_list in signatures.items():
        present = [g for g in gene_list if g in z.index]
        if len(present) >= 8:
            out[name] = z.loc[present].mean(axis=0)
    return pd.DataFrame(out)


def main() -> None:
    signatures = {name: list(g["gene"].astype(str))
                  for name, g in pd.read_csv(RES / "Klocke_signature_genes.csv").groupby("signature")}
    signatures["cycling"] = CYCLING

    rctd_files = sorted(RES.glob("rctd_weights_*.csv"))
    if not rctd_files:
        print("no RCTD outputs yet")
        return

    pilot = json.loads((META / "kpmp_spatial_pilot_files.json").read_text())
    patient_meta = {p: s for p, s in pilot["pilot"].items()}

    spot_tables, sample_rows = [], []
    for weights_path in rctd_files:
        patient = weights_path.stem.replace("rctd_weights_", "")
        inp = SPATIAL / patient / "rctd_input"
        if not (inp / "counts.mtx").exists():
            print("skip", patient, "inputs missing")
            continue
        weights = pd.read_csv(weights_path, index_col=0)
        counts = mmread(inp / "counts.mtx").toarray().astype(np.float32)
        genes = [re.sub(r"^[A-Za-z0-9]+_{4}", "", g) for g in (inp / "genes.txt").read_text().split()]
        spots = (inp / "barcodes.txt").read_text().split()
        scores = spot_scores(counts, genes, signatures)
        scores.index = spots
        scores = scores.loc[[s for s in spots if s in weights.index]]
        weights = weights.loc[scores.index]

        compartments = pd.DataFrame(index=weights.index)
        for name, members in COMPARTMENTS.items():
            present = [c for c in members if c in weights.columns]
            compartments[name] = weights[present].sum(axis=1) if present else np.nan
        merged = scores.join(compartments)
        merged.insert(0, "patient", patient)
        merged.insert(1, "stage", patient_meta.get(patient, ""))
        spot_tables.append(merged)

        row = {"patient": patient, "stage": patient_meta.get(patient, ""), "n_spots": len(merged),
               "n_spots_exported": len(spots), "n_spots_dropped_low_umi": len(spots) - len(merged)}
        for name in signatures:
            row[f"score_{name}"] = merged[name].mean()
        for name in COMPARTMENTS:
            row[f"frac_{name}"] = merged[name].mean()
        sample_rows.append(row)
        print(f"{patient:9s} spots={len(merged):5d} PT={row['frac_PT']:.3f} "
              f"TAL={row['frac_TAL']:.3f} immune={row['frac_immune']:.3f} "
              f"injury={row['score_injury_stress']:+.3f}")

    spots_all = pd.concat(spot_tables, ignore_index=True)
    spots_all.to_csv(RES / "spatial_rctd_spot_table.csv.gz", index=False, compression="gzip")
    samples = pd.DataFrame(sample_rows)
    samples["stage_num"] = pd.to_numeric(samples["stage"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
    samples.to_csv(RES / "spatial_rctd_sample_table.csv", index=False)

    print("\nSpot-level correlations between PT signature and compartment fractions:")
    rows = []
    for score in signatures:
        for compartment in COMPARTMENTS:
            if compartment == "PT" and score != "cycling":
                pass
            rho, p = stats.spearmanr(spots_all[score], spots_all[compartment], nan_policy="omit")
            rows.append({"score": score, "compartment": compartment, "rho": rho, "p": p,
                         "n_spots": int(spots_all[[score, compartment]].dropna().shape[0])})
    corr = pd.DataFrame(rows)
    corr["fdr"] = multipletests(corr["p"].fillna(1), method="fdr_bh")[1]
    corr.to_csv(RES / "spatial_rctd_spot_correlations.csv", index=False)
    print(corr.pivot(index="score", columns="compartment", values="rho").round(3).to_string())

    print("\nPatient-level correlations (PT score vs compartment fraction):")
    patient_corr = []
    for score in signatures:
        for compartment in COMPARTMENTS:
            rho, p = stats.spearmanr(samples[f"score_{score}"], samples[f"frac_{compartment}"],
                                     nan_policy="omit")
            patient_corr.append({"score": score, "compartment": compartment, "rho": rho, "p": p,
                                 "n_samples": len(samples)})
    patient_corr = pd.DataFrame(patient_corr)
    patient_corr["fdr"] = multipletests(patient_corr["p"].fillna(1), method="fdr_bh")[1]
    patient_corr.to_csv(RES / "spatial_rctd_patient_correlations.csv", index=False)
    print(patient_corr.pivot(index="score", columns="compartment", values="rho").round(3).to_string())

    print("\nKDIGO-stage trends across samples (Spearman):")
    trend_rows = []
    for column in list(samples.columns):
        if not (column.startswith("score_") or column.startswith("frac_")):
            continue
        x, y = samples["stage_num"], samples[column]
        valid = x.notna() & y.notna()
        if valid.sum() >= 6 and x[valid].nunique() >= 2:
            rho, p = stats.spearmanr(x[valid], y[valid])
            trend_rows.append({"feature": column, "rho": rho, "p": p, "n": int(valid.sum())})
    trend = pd.DataFrame(trend_rows, columns=["feature", "rho", "p", "n"])
    trend = trend.sort_values("p") if len(trend) else trend
    trend.to_csv(RES / "spatial_rctd_stage_trends.csv", index=False)
    print(trend.to_string(index=False))
    if len(trend) == 0:
        print("(not enough samples with KDIGO stage for a trend test yet)")


if __name__ == "__main__":
    main()
