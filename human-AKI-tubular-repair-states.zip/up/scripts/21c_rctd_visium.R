#!/usr/bin/env Rscript
# RCTD deconvolution of KPMP Visium samples using the GSE210622 reference.

suppressPackageStartupMessages({
  library(Matrix)
  library(spacexr)
})

root <- "/media/desk16/iy16128/comorbidity_analysis/aki_repair"
ref_dir <- file.path(root, "data/rctd_reference")
spatial_dir <- file.path(root, "data/KPMP_spatial")
result_dir <- file.path(root, "results")

counts <- Matrix::readMM(file.path(ref_dir, "reference_counts.mtx"))
genes <- readLines(file.path(ref_dir, "reference_genes.txt"))
cells <- readLines(file.path(ref_dir, "reference_cells.txt"))
ctypes <- readLines(file.path(ref_dir, "reference_celltypes.txt"))
# drop duplicated gene symbols (RCTD requires unique rownames)
keep_g <- !duplicated(genes)
counts <- counts[keep_g, , drop = FALSE]
genes <- genes[keep_g]
rownames(counts) <- genes
colnames(counts) <- make.unique(cells)  # barcodes repeat across patients
counts <- as(counts, "dgCMatrix")
cell_types <- factor(ctypes)
names(cell_types) <- colnames(counts)
reference <- spacexr::Reference(counts, cell_types)
cat("reference:", dim(counts), "cell types:", length(levels(factor(ctypes))), "\n")

patients <- list.dirs(spatial_dir, full.names = FALSE, recursive = FALSE)
args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1 && nzchar(args[1])) {
  wanted <- strsplit(args[1], ",")[[1]]
  patients <- intersect(patients, wanted)
}
cat("processing", length(patients), "patients:", paste(patients, collapse = ", "), "\n")
for (p in patients) {
  inp <- file.path(spatial_dir, p, "rctd_input")
  if (!file.exists(file.path(inp, "counts.mtx"))) next
  out_rds <- file.path(result_dir, paste0("rctd_", p, ".rds"))
  out_csv <- file.path(result_dir, paste0("rctd_weights_", p, ".csv"))
  if (file.exists(out_rds)) {
    cat("skip existing", p, "\n")
    next
  }
  cat("RCTD", p, "...\n")
  sp_counts <- Matrix::readMM(file.path(inp, "counts.mtx"))
  sp_genes <- readLines(file.path(inp, "genes.txt"))
  sp_cells <- readLines(file.path(inp, "barcodes.txt"))
  keep_s <- !duplicated(sp_genes)
  sp_counts <- sp_counts[keep_s, , drop = FALSE]
  sp_genes <- sp_genes[keep_s]
  rownames(sp_counts) <- sp_genes
  colnames(sp_counts) <- sp_cells
  # restrict spatial genes to those in the reference so both share the same feature space
  shared <- intersect(sp_genes, genes)
  sp_counts <- as(sp_counts[shared, , drop = FALSE], "dgCMatrix")
  cat("  shared genes:", length(shared), "\n")

  coords <- read.csv(file.path(inp, "coords.csv"), row.names = 1)
  coords <- coords[sp_cells, , drop = FALSE]
  coords_df <- data.frame(x = coords$pxl_col, y = coords$pxl_row, row.names = sp_cells)

  spatialRNA <- spacexr::SpatialRNA(coords_df, sp_counts)
  rctd <- spacexr::create.RCTD(spatialRNA, reference, max_cores = 24)
  rctd <- spacexr::run.RCTD(rctd, doublet_mode = "full")
  saveRDS(rctd, out_rds)
  weights <- as.matrix(rctd@results$weights)
  write.csv(weights, out_csv)
  cat(p, "done:", dim(weights), "\n")
}
cat("all RCTD finished\n")
