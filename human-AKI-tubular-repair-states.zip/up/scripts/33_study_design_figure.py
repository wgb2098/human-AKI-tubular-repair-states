#!/usr/bin/env python3
"""Study-design schematic (Figure 1) for the AKI repair manuscript."""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

FIG = "/media/desk16/iy16128/comorbidity_analysis/aki_repair/figures"

BLUE = "#2874A6"
RED = "#C0392B"
GREY = "#5D6D7E"
GREEN = "#1E8449"


def box(ax, x, y, w, h, text, color, fontsize=8.5, text_color="white"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.012,rounding_size=0.02",
                                linewidth=1.1, edgecolor=color, facecolor=color, alpha=0.92))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fontsize,
            color=text_color, wrap=True)


def arrow(ax, x1, y1, x2, y2, color=GREY, style="-|>"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=12,
                                 linewidth=1.2, color=color, shrinkA=2, shrinkB=2))


def main() -> None:
    fig, ax = plt.subplots(figsize=(12.4, 7.0))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    # Row 1 - data sources
    ax.text(0.02, 0.95, "A  Data", fontsize=11, weight="bold", color="black")
    box(ax, 0.03, 0.79, 0.21, 0.12,
        "KPMP atlas sc + sn\n(GSE183276 / GSE183277)\nAKI, DKD, H-CKD, Reference", BLUE)
    box(ax, 0.27, 0.79, 0.21, 0.12,
        "KPMP repository matrices\n42 AKI libraries\n+ 18 Reference patients", BLUE)
    box(ax, 0.51, 0.79, 0.21, 0.12,
        "GSE210622 snRNA-seq\n8 AKI (5 COVID)\n6 control kidneys", RED)
    box(ax, 0.75, 0.79, 0.22, 0.12,
        "KPMP Visium\n16 sections\nStage 1 x5 / 2 x5 / 3 x6", GREEN)

    # Row 2 - analyses
    ax.text(0.02, 0.70, "B  Analyses", fontsize=11, weight="bold")
    box(ax, 0.06, 0.55, 0.24, 0.11,
        "Tissue-level composition\nand PT state fractions\n(patient-level tests)", BLUE)
    box(ax, 0.34, 0.55, 0.25, 0.11,
        "PT-only pseudobulk\nAKI vs Reference\n4 signatures", BLUE)
    box(ax, 0.63, 0.55, 0.25, 0.11,
        "Independent PT replication\n+ signature scoring\n+ KDIGO stage trend", RED)

    box(ax, 0.06, 0.39, 0.24, 0.11,
        "Whole-library pseudobulk\n42 AKI vs 72-74 Reference", BLUE)
    box(ax, 0.34, 0.39, 0.25, 0.11,
        "Spatial signature maps\nMoran's I + co-localisation", GREEN)
    box(ax, 0.63, 0.39, 0.25, 0.11,
        "RCTD deconvolution\n12 cell types per spot", GREEN)

    # Row 3 - validation and clinical
    ax.text(0.02, 0.30, "C  Validation", fontsize=11, weight="bold")
    box(ax, 0.06, 0.16, 0.24, 0.10, "Bulk kidney GSE139061\n(AUC validation)", GREY)
    box(ax, 0.34, 0.16, 0.25, 0.10, "Blood GSE67401\n(tissue specificity + meta)", GREY)
    box(ax, 0.63, 0.16, 0.25, 0.10, "Urine AKI cohort\n(clinical trajectories)", GREY)

    # Row 4 - conclusions
    box(ax, 0.16, 0.02, 0.68, 0.09,
        "PT injury/stress, repair-progenitor and cycling programmes are induced in human AKI, "
        "reference PT state is depleted,\nand the injury score tracks KDIGO stage (exploratory)",
        "#212F3D", fontsize=9)

    # arrows
    for x in (0.135, 0.375, 0.615, 0.86):
        arrow(ax, x, 0.79, x, 0.665)
    arrow(ax, 0.30, 0.605, 0.335, 0.605)
    arrow(ax, 0.59, 0.605, 0.625, 0.605)
    arrow(ax, 0.18, 0.55, 0.18, 0.505)
    arrow(ax, 0.46, 0.55, 0.46, 0.505)
    arrow(ax, 0.755, 0.55, 0.755, 0.505)
    for x in (0.18, 0.465, 0.755):
        arrow(ax, x, 0.39, x, 0.265)
    for x in (0.18, 0.465, 0.755):
        arrow(ax, x, 0.16, x, 0.115)

    ax.text(0.5, 0.72, "Patient-level statistics throughout; signatures from Klocke et al. tubular states",
            ha="center", fontsize=8.5, style="italic", color="#212F3D")

    fig.tight_layout()
    fig.savefig(f"{FIG}/Fig1_study_design.png", dpi=300, bbox_inches="tight")
    fig.savefig(f"{FIG}/Fig1_study_design.pdf", bbox_inches="tight")
    plt.close(fig)
    print("saved figures/Fig1_study_design.png/.pdf")


if __name__ == "__main__":
    main()
