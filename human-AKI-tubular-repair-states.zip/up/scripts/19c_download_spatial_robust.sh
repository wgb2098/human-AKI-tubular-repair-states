#!/usr/bin/env bash
set -u
root=/media/desk16/iy16128/comorbidity_analysis/aki_repair
cd "$root"
while IFS='|' read -r url out size; do
  [ -z "$url" ] && continue
  mkdir -p "$(dirname "$out")"
  if [ -s "$out" ]; then printf 'exists %s\n' "$out"; continue; fi
  printf 'start %s (%s bytes)\n' "$(basename "$out")" "$size"
  python scripts/02_robust_download.py "$url" "$out" --chunk-mb 2 >/dev/null 2>&1 || printf 'failed %s\n' "$out"
  [ -s "$out" ] && stat --printf='saved %n (%s bytes)\n' "$out"
done < /tmp/kpmp_spatial_download_list.txt
