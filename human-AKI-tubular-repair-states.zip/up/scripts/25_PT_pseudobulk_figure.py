#!/usr/bin/env python3
"""Figure and summary table for the patient-level PT pseudobulk comparison."""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = "/media/desk16/iy16128/comorbidity_analysis/aki_repair"
RES = f"{ROOT}/results"
FIG = f"{ROOT}/figures"

PANELS = [
    ("injury_stress", "Injury/stress signature"),
    ("repair_progenitor", "Repair-progenitor signature"),
    ("cycling", "Cycling signature"),
    ("reference_PT", "Reference-state signature"),
    ("reference_state_frac", "Reference-state fraction (metadata)"),
    ("cycling_state_frac", "Cycling-state fraction (metadata)"),
]
COLORS = {"AKI": "#C0392B", "Ref": "#2874A6"}


def main() -> None:
    table = pd.read_csv(f"{RES}/KPMP_sc_PT_pseudobulk_patient.csv")
    order = ["Ref", "AKI"]
    fig, axes = plt.subplots(2, 3, figsize=(11.5, 6.4))
    rows = []
    for ax, (feature, label) in zip(axes.ravel(), PANELS):
        data = [table.loc[table["group"] == g, feature].dropna() for g in order]
        bp = ax.boxplot(data, labels=order, widths=0.55, patch_artist=True,
                        medianprops={"color": "black", "lw": 1.1})
        for patch, g in zip(bp["boxes"], order):
            patch.set_facecolor(COLORS[g])
            patch.set_alpha(0.45)
        rng = np.random.default_rng(0)
        for i, (values, g) in enumerate(zip(data, order), start=1):
            ax.scatter(np.full(len(values), i) + rng.uniform(-0.09, 0.09, len(values)),
                       values, s=16, color=COLORS[g], zorder=3, linewidths=0)
        p = stats.mannwhitneyu(*data).pvalue
        ax.set_title(f"{label}\nMann-Whitney P={p:.4f}  (n={len(data[1])} AKI / {len(data[0])} Ref)",
                     fontsize=8.5)
        ax.tick_params(labelsize=8)
        rows.append({"feature": feature, "n_AKI": len(data[1]), "n_Ref": len(data[0]),
                     "median_AKI": np.median(data[1]), "median_Ref": np.median(data[0]), "p": p})
    fig.suptitle("Proximal-tubule pseudobulk: AKI vs healthy reference (KPMP scRNA-seq, patient level)",
                 fontsize=10.5)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(f"{FIG}/Fig_PT_pseudobulk_AKI_vs_Ref.png", dpi=300)
    fig.savefig(f"{FIG}/Fig_PT_pseudobulk_AKI_vs_Ref.pdf")
    plt.close(fig)

    summary = pd.DataFrame(rows)
    summary.to_csv(f"{RES}/KPMP_sc_PT_pseudobulk_AKI_vs_Ref_tests.csv", index=False)

    # stage trend within AKI, using the same patient table
    aki = table[table["group"] == "AKI"]
    trend = []
    for feature, label in PANELS[:4]:
        valid = aki["stage_num"].notna() & aki[feature].notna()
        rho, p = stats.spearmanr(aki.loc[valid, "stage_num"], aki.loc[valid, feature])
        trend.append({"feature": feature, "rho": rho, "p": p, "n": int(valid.sum())})
    pd.DataFrame(trend).to_csv(f"{RES}/KPMP_sc_PT_pseudobulk_stage_trend.csv", index=False)
    print(summary.to_string(index=False))
    print(pd.DataFrame(trend).to_string(index=False))


if __name__ == "__main__":
    main()
