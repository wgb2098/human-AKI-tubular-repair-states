#!/usr/bin/env python3
"""Sensitivity of the cycling result in GSE210622 to the cell-cycle gene set.

The original 12-gene cycling signature does not replicate in GSE210622
(P = 0.081). Here the same PT pseudobulk is rescored with an expanded S/G2M core
set and with its S-phase and G2M halves, to separate "signature definition" from
"cohort power" as explanations.
"""

from __future__ import annotations

import gzip
import io
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.io import mmread
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
EXTRACTED = ROOT / "data/GSE210622/extracted"
RES = ROOT / "results"

CYCLING_12 = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20",
              "TPX2", "CENPF", "CCNA2", "AURKB"]
S_PHASE = ["PCNA", "MCM2", "MCM3", "MCM4", "MCM5", "MCM6", "MCM7", "MCM10", "CDC6", "CDC45",
           "CDT1", "ORC1", "ORC6", "GINS1", "GINS2", "TIPIN", "RPA1", "RPA2", "RPA3", "RFC3",
           "RFC4", "RFC5", "POLA1", "POLA2", "POLD1", "POLD2", "POLD3", "POLE", "POLE2",
           "FEN1", "LIG1", "RRM1", "RRM2", "TYMS", "DTYMK", "TK1", "GMNN", "E2F1",
           "SLBP", "UHRF1", "HELLS", "WDHD1", "CHAF1A", "CHAF1B", "ASF1B", "MYBL2"]
G2M_PHASE = ["CDK1", "CCNB1", "CCNB2", "CENPA", "CENPE", "CENPF", "BUB1", "BUB1B", "AURKA",
             "AURKB", "PLK1", "TOP2A", "MKI67", "NDC80", "NUF2", "SPC24", "SPC25", "KIF11",
             "KIF23", "KIF2C", "KIF15", "ANLN", "PRC1", "NUSAP1", "TACC3", "TPX2", "UBE2C",
             "UBE2S", "CKS1B", "CKS2", "PTTG1", "BIRC5", "CCNA2", "NEK2", "TTK", "ESCO2",
             "RAD21", "SMC4", "CCNF", "CEP55", "ECT2", "RACGAP1", "KIF20A", "DLGAP5", "ASPM",
             "CIT", "INCENP", "CDCA8"]
GENE_SETS = {
    "cycling_12": CYCLING_12,
    "cell_cycle_broad": sorted(set(S_PHASE) | set(G2M_PHASE)),
    "S_phase": S_PHASE,
    "G2M_phase": G2M_PHASE,
}


def files_for(sample: str) -> dict[str, Path]:
    out = {}
    for p in EXTRACTED.glob("*.gz"):
        m = re.match(r"GSM\d+_(.+)\.(barcodes|features|matrix)\.(tsv|mtx)\.gz$", p.name)
        if m and m.group(1) == sample:
            out[m.group(2)] = p
    return out


def main() -> None:
    cells = pd.read_csv(ROOT / "metadata/GSE210622_cells.csv")
    cells["barcode"] = cells["cell"].str.split("_", n=1).str[1]
    mapping = json.loads((ROOT / "metadata/GSE210622_AKI_file_map.json").read_text())
    cells["file_sample"] = cells["sample"].map({v: k for k, v in mapping.items()}).fillna(cells["sample"])
    pt = cells[cells["celltype"] == "PT"]

    rows = []
    for file_sample, group in pt.groupby("file_sample"):
        files = files_for(str(file_sample))
        if len(files) < 3:
            continue
        features = pd.read_csv(io.BytesIO(gzip.decompress(files["features"].read_bytes())),
                               sep="\t", header=None)
        genes = (features.iloc[:, 1] if features.shape[1] > 1 else features.iloc[:, 0]).astype(str).tolist()
        barcodes = gzip.decompress(files["barcodes"].read_bytes()).decode().split()
        index = {b: i for i, b in enumerate(barcodes)}
        positions = sorted(index[b] for b in group["barcode"] if b in index)
        if len(positions) < 20:
            continue
        matrix = mmread(io.BytesIO(gzip.decompress(files["matrix"].read_bytes()))).tocsc()
        counts = np.asarray(matrix[:, positions].sum(axis=1)).ravel()
        lib = counts.sum()
        logcpm = np.log2(counts / lib * 1e6 + 1)
        series = pd.Series(logcpm, index=genes)
        series = series[~series.index.duplicated(keep="first")]
        z = (series - series.mean()) / (series.std() if series.std() else 1)
        record = {"file_sample": file_sample, "sample": group["sample"].iloc[0],
                  "group": group["group"].iloc[0], "n_PT_cells": len(positions)}
        for name, gene_list in GENE_SETS.items():
            present = [g for g in gene_list if g in z.index]
            record[f"{name}_score"] = z.loc[present].mean() if len(present) >= 8 else np.nan
            record[f"{name}_n_genes"] = len(present)
        rows.append(record)

    table = pd.DataFrame(rows)
    table["is_AKI"] = table["group"] != "Control"
    table.to_csv(RES / "reviewer_GSE210622_cycling_sensitivity.csv", index=False)

    print("gene set coverage (median genes found):")
    for name in GENE_SETS:
        print(f"  {name:18s} {int(table[f'{name}_n_genes'].median())} of {len(set(GENE_SETS[name]))}")

    print("\nAKI vs Control per gene set (PT pseudobulk, sample level):")
    results = []
    for name in GENE_SETS:
        a = table.loc[table["is_AKI"], f"{name}_score"].dropna()
        b = table.loc[~table["is_AKI"], f"{name}_score"].dropna()
        p = stats.mannwhitneyu(a, b).pvalue if len(a) >= 3 and len(b) >= 3 else np.nan
        results.append({"gene_set": name, "n_genes": len(set(GENE_SETS[name])),
                        "n_AKI": len(a), "n_Control": len(b),
                        "median_AKI": a.median(), "median_Control": b.median(), "p": p})
        print(f"  {name:18s} median {a.median():+.3f} vs {b.median():+.3f}  p={p:.4f}")
    results = pd.DataFrame(results)
    results["fdr"] = multipletests(results["p"].fillna(1), method="fdr_bh")[1]
    results.to_csv(RES / "reviewer_GSE210622_cycling_sensitivity_tests.csv", index=False)
    print("\nwrote reviewer_GSE210622_cycling_sensitivity*.csv")


if __name__ == "__main__":
    main()
