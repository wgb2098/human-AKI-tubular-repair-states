#!/usr/bin/env python3
"""Neighbourhood enrichment in the Visium sections.

For each section, spots are labelled high/low for each signature/marker (top
quartile within the section). For every pair of labels we count the fraction of
k-nearest-neighbour edges that connect two "high" spots and compare it with the
distribution expected under random label permutation.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.spatial import cKDTree

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
K = 6
N_PERM = 500
FEATURES = ["injury_stress", "repair_progenitor", "cycling", "reference_PT",
            "marker_PT", "marker_TAL", "marker_immune", "marker_fibroblast", "marker_endothelial"]
rng = np.random.default_rng(0)


def enrichment(coords: np.ndarray, high: np.ndarray, neighbour_idx: np.ndarray) -> tuple[float, float]:
    """Observed vs permuted fraction of edges joining two high spots."""
    def fraction(labels: np.ndarray) -> float:
        both = labels[neighbour_idx[:, 0]] & labels[neighbour_idx[:, 1]]
        return both.mean()

    observed = fraction(high)
    n_high = int(high.sum())
    permuted = np.empty(N_PERM)
    for i in range(N_PERM):
        labels = np.zeros(len(high), dtype=bool)
        labels[rng.choice(len(high), size=n_high, replace=False)] = True
        permuted[i] = fraction(labels)
    z = (observed - permuted.mean()) / (permuted.std() if permuted.std() else 1)
    p = (np.sum(permuted >= observed) + 1) / (N_PERM + 1)
    return observed, z, p


def main() -> None:
    spot = pd.read_csv(RES / "spatial_pilot_spot_scores.csv.gz")
    rows = []
    for (patient, stage), group in spot.groupby(["patient", "stage"]):
        group = group.dropna(subset=FEATURES).reset_index(drop=True)
        if len(group) < 60:
            continue
        coords = group[["pxl_col", "pxl_row"]].to_numpy(dtype=float)
        tree = cKDTree(coords)
        _, neighbour_idx = tree.query(coords, k=min(K + 1, len(group)))
        neighbour_idx = neighbour_idx[:, 1:]  # drop self
        high = {feature: (group[feature].to_numpy() >= np.nanquantile(group[feature], 0.75))
                for feature in FEATURES}
        for a in FEATURES:
            for b in FEATURES:
                if a > b:
                    continue
                pair_high = high[a] & high[b]
                if pair_high.sum() < 5:
                    continue
                observed, z, p = enrichment(coords, pair_high, neighbour_idx)
                rows.append({"patient": patient, "stage": stage, "feature_a": a, "feature_b": b,
                             "observed": observed, "z": z, "p": p, "n_spots": len(group)})

    result = pd.DataFrame(rows)
    result.to_csv(RES / "spatial_neighborhood_enrichment.csv", index=False)

    summary = (result.groupby(["feature_a", "feature_b"])
               .agg(n_sections=("z", "count"), median_z=("z", "median"),
                    median_p=("p", "median"), mean_observed=("observed", "mean"))
               .reset_index().sort_values("median_z", ascending=False))
    summary.to_csv(RES / "spatial_neighborhood_summary.csv", index=False)
    print(summary.to_string(index=False))

    print("\nOne-sample test of per-section z against 0 (Wilcoxon):")
    for (a, b), group in result.groupby(["feature_a", "feature_b"]):
        if len(group) >= 8:
            w, p = stats.wilcoxon(group["z"])
            print(f"  {a:22s} + {b:22s} n={len(group):2d} median z={group['z'].median():+.2f} P={p:.2e}")


if __name__ == "__main__":
    main()
