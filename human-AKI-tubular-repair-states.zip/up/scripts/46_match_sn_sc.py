#!/usr/bin/env python3
"""Match GSE183277 sn atlas patients to KPMP repository single-nucleus matrices.

Used for (i) a KPMP-matched RCTD reference and (ii) sn PT-level pseudobulk.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"
BASE = "https://atlas.kpmp.org/api/v1/file/download"
CELL_META = ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz"


def norm(text: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def main() -> None:
    rows = json.loads((META / "KPMP_sn_all_open_files.json").read_text())

    def g(row: dict, key: str):
        value = row.get(key)
        return value.get("raw") if isinstance(value, dict) and "raw" in value else value

    matrices = []
    for row in rows:
        name = str(row["file_name"])
        if "matrix" not in name.lower() or not name.endswith(".zip"):
            continue
        redcap = g(row, "redcap_id")
        redcap = redcap[0] if isinstance(redcap, list) and redcap else str(redcap)
        matrices.append({
            "file_id": row["file_id"], "file_name": name, "package_id": row["package_id"],
            "redcap": redcap, "file_size": float(row["file_size"] or 0),
            "enrollment": str(g(row, "enrollment_category")),
            "age_binned": g(row, "age_binned"), "sex": g(row, "sex"),
            "kdigo_stage": g(row, "kdigo_stage"),
        })
    matrices = pd.DataFrame(matrices)
    matrices["key"] = matrices["redcap"].map(norm)
    print("sn repository matrices:", len(matrices))

    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    atlas = meta.groupby("patient").agg(
        condition=("condition.l2", lambda s: s.iloc[0]),
        libraries=("library", lambda s: sorted({str(v) for v in s.dropna()})),
        n_cells=("library", "size"),
    )

    manifest, downloads, unmatched = [], [], []
    for patient, row in atlas.iterrows():
        candidates = [norm(patient)] + [norm(lib) for lib in row["libraries"]]
        hits = matrices[matrices["key"].apply(
            lambda k: any(bool(k) and (k == c or k in c or c in k) for c in candidates))]
        if not len(hits):
            unmatched.append(patient)
            continue
        for _, hit in hits.iterrows():
            manifest.append({
                "file_id": hit["file_id"], "participants": patient,
                "condition": row["condition"], "libraries": ";".join(row["libraries"]),
                "file_name": hit["file_name"],
                "data_url": f"{BASE}/{hit['package_id']}/{hit['file_name']}",
                "file_size": hit["file_size"], "repo_redcap": hit["redcap"],
                "repo_enrollment": hit["enrollment"], "repo_age_binned": hit["age_binned"],
                "repo_sex": hit["sex"],
                "experimental_strategy": "Single-nucleus RNA-Seq",
            })
            downloads.append(f"{BASE}/{hit['package_id']}/{hit['file_name']}|"
                             f"data/KPMP/sn/{hit['file_id']}_{hit['file_name']}|{int(hit['file_size'])}")

    table = pd.DataFrame(manifest)
    table.to_csv(META / "KPMP_open_sn_single_sample_matrices.csv", index=False)
    Path("/tmp/kpmp_sn_download_list.txt").write_text("\n".join(downloads) + "\n")

    print(f"matched {table['participants'].nunique()} patients / {len(table)} matrices, "
          f"total {table['file_size'].sum()/2**30:.2f} GB")
    print(table.groupby("condition").agg(patients=("participants", "nunique"), files=("file_id", "count"),
                                         GB=("file_size", lambda s: round(s.sum() / 2**30, 2))).to_string())
    if unmatched:
        print("unmatched patients:", unmatched)


if __name__ == "__main__":
    main()
