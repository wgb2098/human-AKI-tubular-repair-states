#!/usr/bin/env python3
"""Build a KPMP snRNA-seq (GSE183277 atlas) reference for RCTD.

Rationale: the Visium sections are KPMP samples, so a KPMP sn reference removes
the cross-cohort mismatch of the current GSE210622 reference (and adds
fibroblasts, which GSE210622 lacks). Cells are capped per (sample, cell type) to
keep the reference tractable; AKI, CKD and reference samples are all included so
that injury states are represented.
"""

from __future__ import annotations

import gzip
import io
import re
import zipfile
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmwrite

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
SN_DIR = ROOT / "data/KPMP/sn"
META_DIR = ROOT / "metadata"
OUT = ROOT / "data/rctd_reference_kpmp"
CELL_META = ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz"

MAX_PER_TYPE_PER_SAMPLE = 80
MIN_CELLS_PER_TYPE = 30
G = {}


def worker(job: tuple[str, str, str]) -> dict | None:
    file_id, patient, condition = job
    matches = sorted(SN_DIR.glob(f"{file_id}*.zip"))
    if not matches:
        return None
    cells = G["cells"].get(patient)
    if not cells:
        return None
    try:
        with zipfile.ZipFile(matches[0]) as zf:
            names = zf.namelist()

            def read(name: str) -> bytes:
                with zf.open(name) as handle:
                    data = handle.read()
                return gzip.decompress(data) if name.endswith(".gz") else data

            matrix_name = next(n for n in names if "matrix" in n.lower() and ".mtx" in n.lower())
            feature_name = next(n for n in names if "features" in n.lower() or "genes" in n.lower())
            barcode_name = next(n for n in names if "barcode" in n.lower())
            whitelist = read(barcode_name).decode(errors="replace").split()
            body = read(matrix_name).split(b"\n", 3)[3]
            features = pd.read_csv(io.BytesIO(read(feature_name)), sep="\t", header=None)
        genes = (features.iloc[:, 1].astype(str).tolist() if features.shape[1] > 1
                 else features.iloc[:, 0].astype(str).tolist())
        genes = [re.sub(r"^[A-Za-z0-9]+_{4}", "", g) for g in genes]
        index = {b: i + 1 for i, b in enumerate(whitelist)}
        kept = [b for b in cells if b in index]
        if len(kept) < 20:
            return None
        positions = [index[b] for b in kept]
        df = pd.read_csv(io.BytesIO(body), sep=" ", header=None, names=["g", "c", "v"],
                         dtype={"g": np.int32, "c": np.int32, "v": np.float32}, engine="c")
        df = df[df["c"].isin(set(positions))]
        col_map = {p: i for i, p in enumerate(positions)}
        cols = df["c"].map(col_map).to_numpy()
        mat = sparse.coo_matrix((df["v"].to_numpy(), (df["g"].to_numpy() - 1, cols)),
                                shape=(len(genes), len(positions))).tocsc()
    except Exception as exc:
        print("skip", file_id, exc)
        return None
    return {"file_id": file_id, "patient": patient, "condition": condition,
            "genes": genes, "barcodes": kept, "matrix": mat}


def main() -> None:
    manifest = pd.read_csv(META_DIR / "KPMP_open_sn_single_sample_matrices.csv")
    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    meta = meta[~meta["subclass.l1"].isna()].copy()
    meta["barcode"] = meta.index.str.split("_", n=1).str[1]
    meta["patient"] = meta["patient"].astype(str)

    chosen_cells = {}
    for (patient, celltype), group in meta.groupby(["patient", "subclass.l1"]):
        patient = str(patient)
        if len(group) < MIN_CELLS_PER_TYPE:
            continue
        take = group.sample(min(len(group), MAX_PER_TYPE_PER_SAMPLE), random_state=0)
        safe_type = re.sub(r"[^A-Za-z0-9_+-]", "_", str(celltype))  # RCTD forbids "/" etc.
        chosen_cells.setdefault(patient, {})[safe_type] = dict(zip(take["barcode"], [safe_type] * len(take)))
    G["cells"] = {patient: set().union(*[set(v.keys()) for v in subset.values()])
                  for patient, subset in chosen_cells.items()}
    print("patients with selected cells:", len(chosen_cells),
          "| total selected cells:", sum(len(v) for v in G["cells"].values()))

    jobs = [(str(row["file_id"]), str(row["participants"]), str(row["condition"]))
            for _, row in manifest.iterrows() if str(row["participants"]) in chosen_cells]
    print("matrix jobs:", len(jobs))

    # one file per patient is enough for the reference; keep the first per patient/condition
    seen, deduped = set(), []
    for job in jobs:
        key = (job[1],)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(job)
    print("deduped jobs (one library per patient):", len(deduped))

    with Pool(6) as pool:
        results = [r for r in pool.map(worker, deduped) if r]
    print("loaded:", len(results))

    gene_sets = [set(r["genes"]) for r in results]
    shared = sorted(set.intersection(*gene_sets))
    print("shared genes:", len(shared))

    blocks, names, types, samples = [], [], [], []
    for r in results:
        subset = chosen_cells[r["patient"]]
        lookup = {}
        for celltype, mapping in subset.items():
            lookup.update(mapping)
        idx = {g: i for i, g in enumerate(r["genes"])}
        keep = [b for b in r["barcodes"] if b in lookup]
        cols = [r["barcodes"].index(b) for b in keep]
        rows = [idx[g] for g in shared]
        blocks.append(r["matrix"][rows, :][:, cols])
        names.extend(f"{r['patient']}|{b}" for b in keep)
        types.extend(lookup[b] for b in keep)
        samples.extend([r["patient"]] * len(keep))

    matrix = sparse.hstack(blocks).tocsr()
    print("reference matrix:", matrix.shape, "cell types:", len(set(types)))
    print(pd.Series(types).value_counts().to_string())

    OUT.mkdir(parents=True, exist_ok=True)
    sparse.save_npz(OUT / "reference_counts.npz", matrix.astype(np.int32))
    mmwrite(OUT / "reference_counts.mtx", matrix.astype(np.int32))
    (OUT / "reference_genes.txt").write_text("\n".join(shared) + "\n")
    (OUT / "reference_cells.txt").write_text("\n".join(names) + "\n")
    (OUT / "reference_celltypes.txt").write_text("\n".join(types) + "\n")
    pd.DataFrame({"cell": names, "celltype": types, "sample": samples}).to_csv(
        OUT / "reference_cells_meta.csv", index=False)
    print("saved to", OUT)


if __name__ == "__main__":
    main()
