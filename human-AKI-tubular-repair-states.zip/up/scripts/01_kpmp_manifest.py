#!/usr/bin/env python3
"""Build the KPMP AKI clinical table and open-transcriptomics file manifest."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"

clinical = pd.read_csv(META / "20260930_OpenAccessClinicalData.csv")
clinical.columns = [c.strip() for c in clinical.columns]

aki = clinical[clinical["Enrollment Category"].astype(str).str.strip().eq("AKI")].copy()
aki_summary = aki[[
    "Participant ID", "Primary Adjudicated Category", "Sex", "Age (Years) (Binned)",
    "KDIGO Stage", "Baseline eGFR (ml/min/1.73m2)",
    "Diabetes History", "Hypertension History",
]].copy()
aki_summary.to_csv(META / "KPMP_AKI_clinical_summary.csv", index=False)

print("Clinical rows:", len(clinical))
print("AKI rows:", len(aki))
print("AKI with KDIGO stage:", aki["KDIGO Stage"].notna().sum())
print("\nKDIGO stage counts:")
print(aki["KDIGO Stage"].value_counts(dropna=False).to_string())
print("\nPrimary adjudicated category in AKI:")
print(aki["Primary Adjudicated Category"].value_counts(dropna=False).to_string())

files = json.loads((META / "kpmp_transcriptomics_open_aki.json").read_text())["rows"]
rows = []
for item in files:
    redcap = item.get("redcap_id")
    if isinstance(redcap, str):
        redcap = [redcap]
    if not redcap:
        redcap = []
    kdigo = item.get("kdigo_stage")
    if isinstance(kdigo, str):
        kdigo = [kdigo]
    rows.append({
        "file_name": item.get("file_name"),
        "package_id": item.get("package_id"),
        "file_id": item.get("file_id"),
        "file_size": item.get("file_size"),
        "data_format": item.get("data_format"),
        "data_type": item.get("data_type"),
        "experimental_strategy": item.get("experimental_strategy"),
        "workflow_type": item.get("workflow_type"),
        "n_participants": len(redcap),
        "participants": ";".join(str(x) for x in redcap),
        "kdigo_stage": ";".join(str(x) for x in (kdigo or [])),
    })
manifest = pd.DataFrame(rows)
for col in ["data_type", "workflow_type", "experimental_strategy", "data_format"]:
    manifest[col] = manifest[col].astype(str)
manifest.to_csv(META / "KPMP_open_AKI_transcriptomics_files.csv", index=False)

print("\nOpen AKI transcriptomics files:", len(manifest))
print(manifest.groupby(["data_type", "workflow_type"])["file_name"].count().to_string())

# Map open per-sample expression matrices to KDIGO stage through participant ID.
expr = manifest[
    manifest["workflow_type"].astype(str).str.contains("Expression Matrix", na=False)
    & manifest["experimental_strategy"].astype(str).str.contains("Single-cell|Single-nucleus|Multiome", regex=True, na=False)
].copy()
expr_single = expr[expr["n_participants"] == 1].copy()
clinical_index = clinical.set_index("Participant ID")
expr_single["Enrollment Category"] = expr_single["participants"].map(clinical_index["Enrollment Category"])
expr_single["KDIGO Stage"] = expr_single["participants"].map(clinical_index["KDIGO Stage"])
expr_single["Primary Adjudicated Category"] = expr_single["participants"].map(clinical_index["Primary Adjudicated Category"])
expr_single["Baseline eGFR"] = expr_single["participants"].map(clinical_index["Baseline eGFR (ml/min/1.73m2)"])
expr_single.to_csv(META / "KPMP_open_AKI_single_sample_matrices.csv", index=False)

matched = expr_single[expr_single["Enrollment Category"] == "AKI"]
print("\nSingle-sample open matrices assigned to AKI:", len(matched))
print(matched.groupby(["experimental_strategy", "KDIGO Stage"])["file_name"].count().to_string())
print("\nSaved manifest files under", META)
