#!/usr/bin/env python3
"""Verify the KPMP sn matrices on disk against the manifest (size + zip integrity)."""

from __future__ import annotations

import zipfile
from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
SN = ROOT / "data/KPMP/sn"


def main() -> None:
    manifest = pd.read_csv(ROOT / "metadata/KPMP_open_sn_single_sample_matrices.csv")
    rows = []
    for _, row in manifest.iterrows():
        pattern = f"{row['file_id']}*.zip"
        found = sorted(SN.glob(pattern))
        if not found:
            rows.append({"participants": row["participants"], "condition": row["condition"],
                         "state": "missing", "expected_MB": round(row["file_size"] / 2**20, 1),
                         "actual_MB": None, "zip_ok": None})
            continue
        path = found[0]
        actual = path.stat().st_size
        expected = int(row["file_size"])
        ok = None
        if actual == expected:
            try:
                with zipfile.ZipFile(path) as zf:
                    ok = zf.testzip() is None and bool(zf.namelist())
            except Exception:
                ok = False
        rows.append({"participants": row["participants"], "condition": row["condition"],
                     "state": "complete" if actual == expected and ok else "incomplete/partial",
                     "expected_MB": round(expected / 2**20, 1), "actual_MB": round(actual / 2**20, 1),
                     "zip_ok": ok})
    table = pd.DataFrame(rows)
    table.to_csv(ROOT / "reports/SN_DOWNLOAD_VERIFY.csv", index=False)
    print(table.groupby(["condition", "state"]).size().to_string())
    print()
    print(f"complete: {int((table['state'] == 'complete').sum())} / {len(table)}")
    bad = table[table["state"] != "complete"]
    if len(bad):
        print("\n未完成:")
        print(bad.to_string(index=False))


if __name__ == "__main__":
    main()
