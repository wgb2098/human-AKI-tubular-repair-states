#!/usr/bin/env python3
"""Three-group figure (AKI vs CKD vs reference) for the reviewer revision."""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = "/media/desk16/iy16128/comorbidity_analysis/aki_repair"
RES = f"{ROOT}/results"
FIG = f"{ROOT}/figures"
COLORS = {"Ref": "#2874A6", "AKI": "#C0392B", "CKD": "#7D3C98"}
ORDER = ["Ref", "AKI", "CKD"]


def boxplot(ax, frame: pd.DataFrame, feature: str, title: str, ylabel: str = "") -> None:
    data = [frame.loc[frame["group"] == g, feature].dropna() for g in ORDER]
    bp = ax.boxplot(data, labels=ORDER, widths=0.55, patch_artist=True,
                    medianprops={"color": "black", "lw": 1.1})
    for patch, group in zip(bp["boxes"], ORDER):
        patch.set_facecolor(COLORS[group])
        patch.set_alpha(0.45)
    rng = np.random.default_rng(0)
    for i, (values, group) in enumerate(zip(data, ORDER), start=1):
        ax.scatter(np.full(len(values), i) + rng.uniform(-0.1, 0.1, len(values)),
                   values, s=15, color=COLORS[group], zorder=3, linewidths=0)
    p_aki_ref = stats.mannwhitneyu(data[1], data[0]).pvalue
    p_aki_ckd = stats.mannwhitneyu(data[1], data[2]).pvalue
    ax.set_title(f"{title}\nP(AKI vs Ref)={p_aki_ref:.2g}   P(AKI vs CKD)={p_aki_ckd:.2g}", fontsize=8.5)
    ax.tick_params(labelsize=8)
    if ylabel:
        ax.set_ylabel(ylabel)


def main() -> None:
    sc_pt = pd.read_csv(f"{RES}/reviewer_sc_patient_table.csv")
    sc_pt["group"] = sc_pt["study_group"]
    pseudo = pd.read_csv(f"{RES}/KPMP_sc_PT_pseudobulk_patient.csv")
    pseudo["group"] = np.where(pseudo["group"] == "AKI", "AKI",
                       np.where(pseudo["group"] == "Ref", "Ref", "CKD"))

    fig, axes = plt.subplots(2, 3, figsize=(12.5, 7.0))
    boxplot(axes[0, 0], sc_pt, "frac_adaptive", "PT adaptive-state fraction", "fraction of PT cells")
    boxplot(axes[0, 1], sc_pt, "frac_reference", "PT reference-state fraction")
    boxplot(axes[0, 2], sc_pt, "frac_cycling", "PT cycling-state fraction")
    boxplot(axes[1, 0], pseudo, "injury_stress", "PT pseudobulk: injury/stress", "signature score")
    boxplot(axes[1, 1], pseudo, "aPT_markers", "PT pseudobulk: independent aPT markers")
    boxplot(axes[1, 2], pseudo, "cycling", "PT pseudobulk: cycling")
    fig.suptitle("Proximal-tubule programmes in AKI, CKD and reference kidneys "
                 "(KPMP scRNA-seq, patient level)", fontsize=10.5)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(f"{FIG}/Fig_PT_three_group.png", dpi=300)
    fig.savefig(f"{FIG}/Fig_PT_three_group.pdf")
    plt.close(fig)
    print("saved figures/Fig_PT_three_group.png/.pdf")


if __name__ == "__main__":
    main()
