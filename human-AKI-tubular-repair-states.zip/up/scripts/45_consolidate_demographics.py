#!/usr/bin/env python3
"""Consolidated patient-level demographics for the KPMP atlas cohorts.

Three sources are combined, in priority order:
  1. KPMP repository file index (age_binned, sex, baseline_egfr per participant);
  2. the open clinical table (age bins, eGFR, diabetes/hypertension history);
  3. the published cell metadata (sex, race).
Matching is by normalised participant / library id with containment in both
directions, and sex conflicts between sources are flagged instead of resolved.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"
REPO_JSON = META / "KPMP_sc_all_open_files_demographics.json"
CELL_META = {
    "sc": ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz",
    "sn": ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz",
}
AGE_MIDPOINT = {"10-19 Years": 14.5, "20-29 Years": 24.5, "30-39 Years": 34.5, "40-49 Years": 44.5,
                "50-59 Years": 54.5, "60-69 Years": 64.5, "70-79 Years": 74.5, "80-89 Years": 84.5}
EGFR_RE = re.compile(r"(\d+(?:\.\d+)?)")


def norm(text: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def sex_code(value: object) -> str | None:
    """Normalise 'F'/'Female'/'M'/'Male' (and lists) to a single code."""
    text = str(first(value)).strip().lower()
    if text.startswith("f"):
        return "F"
    if text.startswith("m"):
        return "M"
    return None


def first(value: object) -> object:
    if isinstance(value, list):
        return value[0] if value else None
    return value


def parse_egfr(value: object) -> float:
    """Turn '120-129 ml/min/1.73m2 (eGFR)' or a number into a point estimate."""
    text = str(value)
    numbers = [float(v) for v in EGFR_RE.findall(text)] if value is not None else []
    if not numbers:
        return np.nan
    return float(np.mean(numbers[:2])) if len(numbers) >= 2 else numbers[0]


def repository_table() -> pd.DataFrame:
    rows = json.loads(REPO_JSON.read_text())
    records = []
    for row in rows:
        redcap = first(row.get("redcap_id"))
        participants = row.get("participants")
        identifiers = [str(v) for v in ([redcap] + (participants if isinstance(participants, list)
                                                   else [participants])) if v]
        records.append({
            "identifiers": identifiers,
            "keys": [norm(v) for v in identifiers if norm(v)],
            "sex": sex_code(row.get("sex")),
            "age_num": AGE_MIDPOINT.get(str(first(row.get("age_binned")))),
            "age_bin": first(row.get("age_binned")),
            "egfr": parse_egfr(first(row.get("baseline_egfr"))),
            "enrollment": first(row.get("enrollment_category")),
        })
    return pd.DataFrame(records)


def clinical_table() -> pd.DataFrame:
    cl = pd.read_csv(META / "20260930_OpenAccessClinicalData.csv", low_memory=False)
    cl["key"] = cl["Participant ID"].map(norm)
    cl["age_num"] = cl["Age (Years) (Binned)"].map(AGE_MIDPOINT)
    cl["egfr"] = pd.to_numeric(cl["Baseline eGFR (ml/min/1.73m2)"], errors="coerce")
    cl["sex"] = cl["Sex"].map(sex_code)
    return cl


def main() -> None:
    repo = repository_table()
    clinical = clinical_table()
    out_rows = []
    for cohort, path in CELL_META.items():
        meta = pd.read_csv(path, sep="\t", index_col=0, low_memory=False,
                           usecols=["patient", "sex", "race", "library"])
        meta["patient"] = meta["patient"].astype(str)
        grouped = meta.groupby("patient").agg(
            atlas_sex=("sex", lambda s: sex_code(s.dropna().mode().iloc[0]) if s.notna().any() else None),
            race=("race", lambda s: s.dropna().astype(str).mode().iloc[0] if s.notna().any() else None),
            libraries=("library", lambda s: sorted({str(v) for v in s.dropna()})),
        ).reset_index()

        for _, patient_row in grouped.iterrows():
            patient = patient_row["patient"]
            keys = {norm(v) for v in ([patient] + patient_row["libraries"]) if norm(v)}

            # source 1: repository index
            repo_hits = repo[repo["keys"].apply(lambda ks: any(k in keys or any(k in key or key in k for key in keys) for k in ks))]
            repo_age = repo_hits["age_num"].dropna()
            repo_sex = {str(v) for v in repo_hits["sex"].dropna()}
            repo_egfr = repo_hits["egfr"].dropna()

            # source 2: clinical table
            clin_hits = clinical[clinical["key"].apply(lambda k: bool(k) and (k in keys or any(k in key or key in k for key in keys)))]
            clin_age = clin_hits["age_num"].dropna()
            clin_sex = {str(v) for v in clin_hits["sex"].dropna()}
            clin_egfr = clin_hits["egfr"].dropna()

            atlas_sex = patient_row["atlas_sex"]
            sexes = repo_sex | clin_sex | ({atlas_sex} if atlas_sex else set())
            conflict = len(sexes) > 1

            # clinical table is participant-curated and takes priority; the repository
            # index is only used to fill gaps, and only when it does not contradict
            # the clinical value (age within 5 years) or the known sex
            prefer_clinical = len(clin_age) > 0
            age = clin_age.median() if prefer_clinical else (repo_age.median() if len(repo_age) else np.nan)
            if prefer_clinical and len(repo_age) and abs(repo_age.median() - age) > 5:
                age_note = "repository_age_discordant_ignored"
            else:
                age_note = "clinical" if prefer_clinical else ("repository" if len(repo_age) else "none")
            # exact participant-level eGFR exists only in the clinical table; the
            # repository index stores eGFR as a 10-unit bin, so it is only a fallback
            if len(clin_egfr):
                egfr, egfr_note = clin_egfr.median(), "clinical"
            elif len(repo_egfr):
                egfr, egfr_note = repo_egfr.median(), "repository_bin_midpoint"
            else:
                egfr, egfr_note = np.nan, "none"
            out_rows.append({
                "cohort": cohort, "patient": patient, "sex": atlas_sex or (sorted(sexes)[0] if sexes else None),
                "sex_conflict": conflict, "race": patient_row["race"],
                "age_num": age,
                "age_source": age_note,
                "egfr": egfr,
                "egfr_source": egfr_note,
                "n_repo_hits": len(repo_hits), "n_clinical_hits": len(clin_hits),
                "diabetes": clin_hits["Diabetes History"].dropna().iloc[0] if clin_hits["Diabetes History"].notna().any() else None,
                "hypertension": clin_hits["Hypertension History"].dropna().iloc[0] if clin_hits["Hypertension History"].notna().any() else None,
                "enrollment": clin_hits["Enrollment Category"].dropna().iloc[0] if clin_hits["Enrollment Category"].notna().any() else None,
                "kdigo": clin_hits["KDIGO Stage"].dropna().iloc[0] if clin_hits["KDIGO Stage"].notna().any() else None,
            })

    table = pd.DataFrame(out_rows)
    table.to_csv(META / "patient_demographics_consolidated.csv", index=False)

    print("coverage by cohort and availability:")
    print(table.groupby("cohort").agg(
        n=("patient", "size"),
        age=("age_num", lambda s: int(s.notna().sum())),
        egfr=("egfr", lambda s: int(s.notna().sum())),
        sex_conflicts=("sex_conflict", "sum"),
    ).to_string())
    print("\nage source:", table.groupby(["cohort", "age_source"]).size().to_dict())
    print("egfr source:", table.groupby(["cohort", "egfr_source"]).size().to_dict())


if __name__ == "__main__":
    main()
