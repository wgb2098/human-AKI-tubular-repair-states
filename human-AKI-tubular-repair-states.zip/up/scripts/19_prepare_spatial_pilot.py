#!/usr/bin/env python3
"""Select KPMP Visium files for the 6-sample spatial pilot.

Pilot patients are chosen to be stage-balanced (2 x stage 1, 2 x stage 2,
2 x stage 3) and to overlap with patients that already have single-cell data.
"""

from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"
API = "https://atlas.kpmp.org/spatial-viewer/search/api/as/v1/engines/atlas-repository/search.json"
KEY = "search-vwz67uj2sf8h83h4y8i8j6g3"

PILOT = {
    # Stage 1
    "34-10184": "Stage 1",
    "34-10729": "Stage 1",
    "34-10666": "Stage 1",
    "30-11084": "Stage 1",
    "34-11066": "Stage 1",
    # Stage 2
    "34-11025": "Stage 2",
    "936-10217": "Stage 2",
    "30-11072": "Stage 2",
    "30-10868": "Stage 2",
    "34-10187": "Stage 2",
    # Stage 3
    "30-11080": "Stage 3",
    "30-11141": "Stage 3",
    "34-10306": "Stage 3",
    "34-10331": "Stage 3",
    "30-10018": "Stage 3",
    "34-11042": "Stage 3",
}
WANTED_WORKFLOWS = {"Expression Matrix", "Spatial Imaging Data", "Experimental Metadata"}


def query_page(page: int, size: int = 100) -> tuple[list[dict], int]:
    body = {
        "query": "",
        "page": {"size": size, "current": page},
        "filters": {"all": [
            {"data_category": "Molecular"},
            {"data_type": "Transcriptomics"},
            {"access": "open"},
            {"enrollment_category": "AKI"},
            {"experimental_strategy": "Spatial Transcriptomics Visium"},
        ]},
    }
    cmd = [
        "curl", "--http1.1", "-L", "--silent", "--show-error", "--fail",
        "--connect-timeout", "20", "--max-time", "120",
        "--request", "POST", API,
        "--header", f"Authorization: Bearer {KEY}",
        "--header", "Content-Type: application/json",
        "--header", "Origin: https://atlas.kpmp.org",
        "--header", "Referer: https://atlas.kpmp.org/repository/",
        "--user-agent", "Mozilla/5.0",
        "--data", json.dumps(body),
    ]
    for attempt in range(4):
        result = subprocess.run(cmd, capture_output=True)
        if result.returncode == 0:
            try:
                payload = json.loads(result.stdout)
                rows = []
                for item in payload.get("results", []):
                    raw = item.get("raw", item)
                    rows.append({k: (v.get("raw") if isinstance(v, dict) and "raw" in v else v)
                                 for k, v in raw.items()})
                return rows, payload.get("meta", {}).get("page", {}).get("total_pages", 1)
            except json.JSONDecodeError:
                pass
        time.sleep(2 + attempt)
    raise RuntimeError(f"query failed for page {page}")


def main() -> None:
    rows: list[dict] = []
    page = 1
    while True:
        batch, total_pages = query_page(page)
        rows.extend(batch)
        print(f"page {page}/{total_pages}: {len(batch)} files")
        if page >= total_pages or not batch:
            break
        page += 1
        time.sleep(0.3)

    selected = []
    for row in rows:
        redcap = row.get("redcap_id") or []
        if isinstance(redcap, str):
            redcap = [redcap]
        workflows = row.get("workflow_type") or []
        if isinstance(workflows, str):
            workflows = [workflows]
        hit = [p for p in PILOT if p in redcap]
        if not hit:
            continue
        if not any(w in WANTED_WORKFLOWS for w in workflows):
            continue
        selected.append({
            "patient": hit[0],
            "stage": PILOT[hit[0]],
            "file_id": row.get("file_id"),
            "file_name": row.get("file_name"),
            "package_id": row.get("package_id"),
            "file_size": float(row.get("file_size") or 0),
            "workflow_type": workflows,
            "data_format": row.get("data_format"),
            "adjudicated": row.get("primary_adjudicated_category"),
        })

    selected.sort(key=lambda r: (r["patient"], str(r["workflow_type"])))
    out = META / "kpmp_spatial_pilot_files.json"
    out.write_text(json.dumps({"pilot": PILOT, "files": selected}, indent=2, ensure_ascii=False))

    print(f"\nselected {len(selected)} files for {len(PILOT)} patients")
    total = 0
    for row in selected:
        total += row["file_size"]
        print(f"  {row['patient']:9s} {row['stage']:8s} {str(row['workflow_type']):35s} "
              f"{row['data_format']:20s} {row['file_size']/1048576:7.1f} MB")
    print(f"total: {total/1048576:.1f} MB")
    print("saved", out)


if __name__ == "__main__":
    main()
