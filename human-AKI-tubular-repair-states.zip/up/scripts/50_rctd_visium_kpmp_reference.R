#!/usr/bin/env Rscript
# RCTD deconvolution of the 16 Visium sections using the KPMP sn reference.
# Outputs use the rctd_KPMPref_* prefix so the GSE210622-based run is preserved.

suppressPackageStartupMessages({
  library(Matrix)
  library(spacexr)
})

root <- "/media/desk16/iy16128/comorbidity_analysis/aki_repair"
ref_dir <- file.path(root, "data/rctd_reference_kpmp")
spatial_dir <- file.path(root, "data/KPMP_spatial")
result_dir <- file.path(root, "results")

counts <- as(Matrix::readMM(file.path(ref_dir, "reference_counts.mtx")), "CsparseMatrix")
genes <- readLines(file.path(ref_dir, "reference_genes.txt"))
cells <- readLines(file.path(ref_dir, "reference_cells.txt"))
ctypes <- gsub("/", "_", readLines(file.path(ref_dir, "reference_celltypes.txt")))
keep_g <- !duplicated(genes)
counts <- counts[keep_g, , drop = FALSE]
genes <- genes[keep_g]
rownames(counts) <- genes
colnames(counts) <- make.unique(cells)
cell_types <- factor(ctypes)
names(cell_types) <- colnames(counts)
reference <- spacexr::Reference(counts, cell_types)
cat("reference:", dim(counts), "cell types:", length(levels(cell_types)), "\n")

patients <- list.dirs(spatial_dir, full.names = FALSE, recursive = FALSE)
args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1 && nzchar(args[1])) {
  patients <- intersect(patients, strsplit(args[1], ",")[[1]])
}
cat("processing", length(patients), "patients\n")

for (p in patients) {
  inp <- file.path(spatial_dir, p, "rctd_input")
  if (!file.exists(file.path(inp, "counts.mtx"))) next
  out_rds <- file.path(result_dir, paste0("rctd_KPMPref_", p, ".rds"))
  out_csv <- file.path(result_dir, paste0("rctd_KPMPref_weights_", p, ".csv"))
  if (file.exists(out_rds)) {
    cat("skip existing", p, "\n")
    next
  }
  cat("RCTD(KPMP ref)", p, "...\n")
  sp_counts <- Matrix::readMM(file.path(inp, "counts.mtx"))
  sp_genes <- readLines(file.path(inp, "genes.txt"))
  sp_cells <- readLines(file.path(inp, "barcodes.txt"))
  keep_s <- !duplicated(sp_genes)
  sp_counts <- sp_counts[keep_s, , drop = FALSE]
  sp_genes <- sp_genes[keep_s]
  rownames(sp_counts) <- sp_genes
  colnames(sp_counts) <- sp_cells
  shared <- intersect(sp_genes, genes)
  sp_counts <- as(sp_counts[shared, , drop = FALSE], "CsparseMatrix")

  coords <- read.csv(file.path(inp, "coords.csv"), row.names = 1)
  coords <- coords[sp_cells, , drop = FALSE]
  coords_df <- data.frame(x = coords$pxl_col, y = coords$pxl_row, row.names = sp_cells)

  spatialRNA <- spacexr::SpatialRNA(coords_df, sp_counts)
  rctd <- spacexr::create.RCTD(spatialRNA, reference, max_cores = 12)
  rctd <- spacexr::run.RCTD(rctd, doublet_mode = "full")
  saveRDS(rctd, out_rds)
  weights <- as.matrix(rctd@results$weights)
  write.csv(weights, out_csv)
  cat(p, "done:", dim(weights), "\n")
}
cat("all KPMP-reference RCTD finished\n")
