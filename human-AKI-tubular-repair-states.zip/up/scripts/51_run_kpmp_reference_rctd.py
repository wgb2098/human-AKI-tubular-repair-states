#!/usr/bin/env python3
"""Wait for the sn download, then build the KPMP sn reference and rerun RCTD.

Sequence: download complete -> 49 (reference build) -> 50 (RCTD, 4 parallel
batches) -> 52 (reference comparison) -> checksums.
"""

from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
LOGS = ROOT / "logs"
EXPECTED_FILES = 43
PATIENTS = ["34-10184", "34-10729", "34-10666", "30-11084", "34-11066", "34-11025", "936-10217",
            "30-11072", "30-10868", "34-10187", "30-11080", "30-11141", "34-10306", "34-10331",
            "30-10018", "34-11042"]


def run(command: list[str], log: str) -> int:
    with open(LOGS / log, "a") as handle:
        return subprocess.run(command, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT).returncode


def download_running() -> bool:
    out = subprocess.run(["pgrep", "-f", "kpmp_sn_download_list"], capture_output=True, text=True)
    return bool(out.stdout.strip())


def main() -> None:
    started = time.time()
    while True:
        have = len(list((ROOT / "data/KPMP/sn").glob("*.zip")))
        print(f"[{time.strftime('%H:%M:%S')}] sn matrices on disk: {have}/{EXPECTED_FILES} "
              f"(downloader active: {download_running()})", flush=True)
        if have >= EXPECTED_FILES or (not download_running() and have > 0):
            break
        if time.time() - started > 6 * 3600:
            print("timeout waiting for the sn download", flush=True)
            return
        time.sleep(120)

    print("building KPMP sn RCTD reference", flush=True)
    run([sys.executable, "-I", "scripts/49_build_rctd_reference_kpmp.py"], "rctd_kpmp_reference.log")

    if not (ROOT / "data/rctd_reference_kpmp/reference_counts.mtx").exists():
        print("reference build failed; aborting", flush=True)
        return

    batches = [PATIENTS[i::4] for i in range(4)]
    processes = []
    for index, batch in enumerate(batches):
        handle = open(LOGS / f"rctd_kpmp_batch_{index}.log", "w")
        processes.append(subprocess.Popen(
            ["Rscript", "scripts/50_rctd_visium_kpmp_reference.R", ",".join(batch)],
            cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True))
        print(f"launched batch {index}: {len(batch)} sections", flush=True)

    for process in processes:
        process.wait()
    print("all KPMP-reference RCTD batches finished", flush=True)

    run([sys.executable, "-I", "scripts/52_compare_rctd_references.py"], "rctd_kpmp_compare.log")
    print("comparison written", flush=True)


if __name__ == "__main__":
    main()
