#!/usr/bin/env python3
"""Parallel downloader for the KPMP spatial pilot files.

The server ignores Range requests, so each worker streams a whole file and
restarts it on failure. Six workers give roughly 5-7x the single-stream speed.
"""

from __future__ import annotations

import subprocess
import sys
import time
import zipfile
from multiprocessing import Pool
from pathlib import Path

LIST = Path("/tmp/kpmp_spatial_download_list.txt")
ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")


def valid(path: Path, expected: int) -> bool:
    if not path.exists() or path.stat().st_size != expected:
        return False
    if path.suffix.lower() == ".zip":
        try:
            with zipfile.ZipFile(path) as zf:
                return zf.testzip() is None and bool(zf.namelist())
        except Exception:
            return False
    return True


def worker(job: tuple[str, str, int]) -> tuple[str, bool, str]:
    url, out, expected = job
    target = ROOT / out
    target.parent.mkdir(parents=True, exist_ok=True)
    if valid(target, expected):
        return out, True, "already valid"
    part = target.with_suffix(target.suffix + ".part")
    for attempt in range(1, 11):
        if part.exists():
            part.unlink()
        result = subprocess.run(
            ["curl", "--http1.1", "-L", "--silent", "--show-error",
             "--connect-timeout", "20", "--max-time", "1800",
             "--user-agent", "Mozilla/5.0", "--output", str(part), url],
            capture_output=True,
        )
        if result.returncode == 0 and valid(part, expected):
            part.replace(target)
            return out, True, f"ok (attempt {attempt})"
        time.sleep(2)
    return out, False, "failed after 10 attempts"


def main() -> None:
    list_path = Path(sys.argv[1]) if len(sys.argv) > 1 else LIST
    jobs = []
    for line in list_path.read_text().strip().splitlines():
        url, out, size = line.split("|")
        jobs.append((url, out, int(size)))
    print(f"jobs: {len(jobs)}, total {sum(j[2] for j in jobs)/1048576:.1f} MB", flush=True)
    ok = 0
    with Pool(6) as pool:
        for out, success, message in pool.imap_unordered(worker, jobs):
            ok += int(success)
            print(f"{'OK  ' if success else 'FAIL'} {out} :: {message}", flush=True)
    print(f"finished: {ok}/{len(jobs)} ok", flush=True)


if __name__ == "__main__":
    main()
