#!/usr/bin/env python3
"""Verify downloaded KPMP spatial pilot files and remove truncated/corrupt ones."""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
SPATIAL = ROOT / "data/KPMP_spatial"
META = ROOT / "metadata"


def check(path: Path, expected_size: float) -> tuple[str, str]:
    if not path.exists():
        return "missing", ""
    actual = path.stat().st_size
    if actual != int(expected_size):
        return "size_mismatch", f"{actual} vs {int(expected_size)}"
    if path.suffix.lower() == ".zip":
        try:
            with zipfile.ZipFile(path) as zf:
                bad = zf.testzip()
                if bad is not None:
                    return "zip_corrupt", str(bad)
                if not zf.namelist():
                    return "zip_empty", ""
        except Exception as exc:
            return "zip_error", str(exc)
    return "ok", ""


def main() -> None:
    pilot = json.loads((META / "kpmp_spatial_pilot_files.json").read_text())
    report = []
    invalid = []
    for row in pilot["files"]:
        path = SPATIAL / row["patient"] / row["file_name"]
        status, detail = check(path, row["file_size"])
        report.append({"patient": row["patient"], "file": row["file_name"],
                       "status": status, "detail": detail,
                       "expected": int(row["file_size"]),
                       "actual": path.stat().st_size if path.exists() else 0})
        if status != "ok":
            invalid.append(path)
            print(f"{status:14s} {row['patient']:9s} {row['file_name'][-60:]} {detail}")
    for path in invalid:
        if path.exists():
            path.unlink()
    (META / "spatial_download_verify.json").write_text(
        json.dumps({"files": report, "invalid_removed": [str(p) for p in invalid]}, indent=2))
    print(f"\nchecked {len(report)} files; invalid removed: {len(invalid)}")


if __name__ == "__main__":
    main()
