#!/usr/bin/env python3
"""Cell-type composition and injury/repair scores by KDIGO severity in KPMP atlas."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"
RES = ROOT / "results"
RES.mkdir(parents=True, exist_ok=True)

CLINICAL = META / "20260930_OpenAccessClinicalData.csv"
SC = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"
SN = ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz"

STAGE_MAP = {"Stage 1": 1, "Stage 2": 2, "Stage 3": 3}


def load_clinical() -> pd.DataFrame:
    clinical = pd.read_csv(CLINICAL)
    clinical.columns = [c.strip() for c in clinical.columns]
    clinical["kdigo_stage_num"] = clinical["KDIGO Stage"].map(STAGE_MAP)
    return clinical


def analyse(cohort: str, path: Path, clinical: pd.DataFrame) -> dict[str, pd.DataFrame]:
    meta = pd.read_csv(path, sep="\t", index_col=0, low_memory=False)
    meta["cell_id"] = meta.index
    rename = {"predicted.class": "class", "condition.l1": "condition"}
    for old, new in rename.items():
        if old in meta.columns and new not in meta.columns:
            meta[new] = meta[old]
    meta = meta.merge(
        clinical[["Participant ID", "kdigo_stage_num", "Baseline eGFR (ml/min/1.73m2)",
                  "Primary Adjudicated Category", "Diabetes History", "Hypertension History"]],
        left_on="patient", right_on="Participant ID", how="left",
    )

    print(f"\n==== {cohort} ====")
    print("cells:", len(meta))
    print("condition counts:\n", meta["condition"].value_counts().to_string())
    print("AKI patients:", meta.loc[meta["condition"] == "AKI", "patient"].nunique())
    aki = meta[meta["condition"] == "AKI"].copy()
    print("AKI cells with KDIGO stage:", aki["kdigo_stage_num"].notna().sum(),
          "of", len(aki))
    print(pd.crosstab(aki["patient"], aki["kdigo_stage_num"]).sum(axis=0).to_string())

    score_cols = [c for c in ["degen.score", "aEpi.score", "aStr.score", "cyc.score",
                              "matrisome.score", "collagen.score", "glycoprotein.score",
                              "proteoglycan.score", "percent.mt", "nFeature_RNA"]
                  if c in meta.columns]
    state_col = "state.l2" if "state.l2" in meta.columns else None
    subclass_col = "subclass.l1" if "subclass.l1" in meta.columns else "predicted.subclass.l1"

    rows = []
    for (patient, sample, stage), group in meta.groupby(["patient", "library", "kdigo_stage_num"], dropna=False):
        row = {
            "cohort": cohort, "patient": patient, "sample": sample, "stage": stage,
            "condition": group["condition"].iloc[0], "n_cells": len(group),
            "adjudicated": group["Primary Adjudicated Category"].iloc[0],
            "baseline_eGFR": group["Baseline eGFR (ml/min/1.73m2)"].iloc[0],
        }
        for score in score_cols:
            row[f"mean_{score}"] = pd.to_numeric(group[score], errors="coerce").mean()
        if state_col:
            for state, count in group[state_col].value_counts().items():
                row[f"frac_state_{state}"] = count / len(group)
        for sub, count in group[subclass_col].value_counts().items():
            row[f"frac_sub_{sub}"] = count / len(group)
        rows.append(row)
    sample_table = pd.DataFrame(rows)
    feature_cols = [c for c in sample_table.columns if c.startswith(("frac_", "mean_"))]
    sample_table[feature_cols] = sample_table[feature_cols].fillna(0.0)
    sample_table.to_csv(RES / f"KPMP_{cohort}_sample_composition_scores.csv", index=False)

    # AKI vs Reference per-cell comparisons (patient-level aggregation also reported)
    comp_tests = []
    features = [c for c in sample_table.columns if c.startswith(("frac_", "mean_"))]
    for feature in features:
        aki_vals = sample_table.loc[sample_table["stage"].notna(), feature]
        stage_vals = sample_table.loc[sample_table["stage"].notna(), "stage"]
        if len(aki_vals) < 5 or stage_vals.nunique() < 2:
            continue
        groups = [sample_table.loc[sample_table["stage"] == s, feature].dropna() for s in [1, 2, 3]]
        if min(len(g) for g in groups) < 2:
            kw_p = np.nan
        else:
            kw_p = stats.kruskal(*groups).pvalue
        rho, spearman_p = stats.spearmanr(stage_vals, aki_vals, nan_policy="omit")
        aki_group = sample_table.loc[sample_table["condition"] == "AKI", feature].dropna()
        ref_group = sample_table.loc[sample_table["condition"] == "Ref", feature].dropna()
        mw_p = stats.mannwhitneyu(aki_group, ref_group).pvalue if len(aki_group) >= 3 and len(ref_group) >= 3 else np.nan
        comp_tests.append({
            "cohort": cohort, "feature": feature, "n_aki_samples": len(aki_vals),
            "kruskal_p_stage": kw_p, "spearman_rho_stage": rho, "spearman_p_stage": spearman_p,
            "mannwhitney_p_aki_vs_ref": mw_p,
            "mean_stage1": sample_table.loc[sample_table["stage"] == 1, feature].mean(),
            "mean_stage2": sample_table.loc[sample_table["stage"] == 2, feature].mean(),
            "mean_stage3": sample_table.loc[sample_table["stage"] == 3, feature].mean(),
            "mean_aki": aki_group.mean(), "mean_ref": ref_group.mean(),
        })
    tests = pd.DataFrame(comp_tests)
    tests["fdr_stage"] = stats.false_discovery_control(tests["spearman_p_stage"].fillna(1)) if hasattr(stats, "false_discovery_control") else np.nan
    tests.to_csv(RES / f"KPMP_{cohort}_feature_tests.csv", index=False)

    return {"cells": meta, "samples": sample_table, "tests": tests}


def main() -> None:
    clinical = load_clinical()
    sc = analyse("sc", SC, clinical)
    sn = analyse("sn", SN, clinical)

    if hasattr(stats, "false_discovery_control"):
        from statsmodels.stats.multitest import multipletests
        for cohort, result in [("sc", sc), ("sn", sn)]:
            tests = result["tests"]
            mask = tests["spearman_p_stage"].notna()
            tests.loc[mask, "fdr_stage"] = multipletests(tests.loc[mask, "spearman_p_stage"], method="fdr_bh")[1]
            tests.loc[:, "fdr_aki_vs_ref"] = multipletests(tests["mannwhitney_p_aki_vs_ref"].fillna(1), method="fdr_bh")[1]
            tests.to_csv(RES / f"KPMP_{cohort}_feature_tests.csv", index=False)

    for cohort, result in [("sc", sc), ("sn", sn)]:
        tests = result["tests"]
        print(f"\nTop stage-trend features ({cohort}):")
        cols = ["feature", "spearman_rho_stage", "spearman_p_stage", "fdr_stage",
                "mean_stage1", "mean_stage2", "mean_stage3", "mannwhitney_p_aki_vs_ref"]
        print(tests.sort_values("spearman_p_stage")[cols].head(20).to_string(index=False))


if __name__ == "__main__":
    main()
