#!/usr/bin/env python3
"""PT-specific state analysis and composite repair index across KDIGO severity."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

SC = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"
SN = ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz"
STAGE = {"Stage 1": 1, "Stage 2": 2, "Stage 3": 3}


def load(path: Path, clinical: pd.DataFrame) -> pd.DataFrame:
    meta = pd.read_csv(path, sep="\t", index_col=0, low_memory=False)
    meta = meta.merge(
        clinical[["Participant ID", "KDIGO Stage", "Baseline eGFR (ml/min/1.73m2)"]],
        left_on="patient", right_on="Participant ID", how="left",
    )
    meta["stage_num"] = meta["KDIGO Stage"].map(STAGE)
    return meta


def pt_analysis(meta: pd.DataFrame, cohort: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    pt = meta[meta["subclass.l1"] == "PT"].copy()
    rows = []
    for (patient, sample, stage, condition), group in pt.groupby(
            ["patient", "library", "stage_num", "condition.l1"], dropna=False):
        if len(group) < 20:
            continue
        row = {
            "cohort": cohort, "patient": patient, "sample": sample, "stage": stage,
            "condition": condition, "n_PT": len(group),
            "frac_adaptive": (group["state.l2"] == "adaptive - epi").mean(),
            "frac_degenerative": (group["state.l2"] == "degenerative").mean(),
            "frac_reference": (group["state.l2"] == "reference").mean(),
            "frac_cycling": (group["state.l2"] == "cycling").mean(),
            "frac_transitioning": (group["state.l2"] == "transitioning").mean(),
            "mean_aEpi": group["aEpi.score"].mean(),
            "mean_degen": group["degen.score"].mean(),
            "mean_cyc": group["cyc.score"].mean(),
        }
        row["repair_index"] = row["frac_adaptive"] + row["frac_cycling"] - row["frac_reference"]
        rows.append(row)
    table = pd.DataFrame(rows)
    pts = []
    for feature in ["frac_adaptive", "frac_degenerative", "frac_reference", "frac_cycling",
                    "repair_index", "mean_aEpi", "mean_degen"]:
        aki = table[table["condition"] == "AKI"]
        data = aki[["stage", feature]].dropna()
        if data["stage"].nunique() < 2 or len(data) < 5:
            continue
        rho, p = stats.spearmanr(data["stage"], data[feature])
        ref = table.loc[table["condition"] == "Ref", feature].dropna()
        aki_vals = aki[feature].dropna()
        mw = stats.mannwhitneyu(aki_vals, ref).pvalue if len(ref) >= 3 else np.nan
        pts.append({"cohort": cohort, "feature": feature, "n_AKI_samples": len(data),
                    "spearman_rho_stage": rho, "spearman_p_stage": p,
                    "mean_stage1": aki.loc[aki["stage"] == 1, feature].mean(),
                    "mean_stage2": aki.loc[aki["stage"] == 2, feature].mean(),
                    "mean_stage3": aki.loc[aki["stage"] == 3, feature].mean(),
                    "mean_AKI": aki_vals.mean(), "mean_Ref": ref.mean(),
                    "mannwhitney_p_AKI_vs_Ref": mw})
    tests = pd.DataFrame(pts)
    if not tests.empty:
        tests["fdr_stage"] = multipletests(tests["spearman_p_stage"], method="fdr_bh")[1]
        tests["fdr_AKI_vs_Ref"] = multipletests(tests["mannwhitney_p_AKI_vs_Ref"].fillna(1), method="fdr_bh")[1]
    table.to_csv(RES / f"KPMP_{cohort}_PT_state_table.csv", index=False)
    tests.to_csv(RES / f"KPMP_{cohort}_PT_state_tests.csv", index=False)
    return table, tests


def figure(sc_table: pd.DataFrame, sn_table: pd.DataFrame) -> None:
    features = [("repair_index", "Composite repair index"), ("frac_adaptive", "Adaptive PT state"),
                ("frac_cycling", "Cycling PT state"), ("frac_reference", "Reference PT state"),
                ("mean_aEpi", "aEpi score"), ("mean_degen", "Degenerative score")]
    fig, axes = plt.subplots(2, 3, figsize=(12, 7.5))
    for ax, (feature, title) in zip(axes.ravel(), features):
        for cohort, table, offset, color in [("sc", sc_table, -0.16, "#2874A6"), ("sn", sn_table, 0.16, "#C0392B")]:
            aki = table[(table["condition"] == "AKI") & table["stage"].isin([1, 2, 3])]
            ax.scatter(aki["stage"] + offset, aki[feature], s=16, alpha=0.7, color=color, label=cohort)
            means = aki.groupby("stage")[feature].mean()
            ax.plot(np.asarray(means.index, dtype=float) + offset, np.asarray(means, dtype=float).reshape(-1),
                    color=color, lw=1.6)
            ref = table.loc[table["condition"] == "Ref", feature].dropna()
            if len(ref):
                ax.axhline(ref.mean(), color=color, ls=":", lw=1, alpha=0.8)
        ax.set_xticks([1, 2, 3]); ax.set_xticklabels(["Stage 1", "Stage 2", "Stage 3"])
        ax.set_title(title); ax.set_ylabel("Value")
    axes[0, 0].legend(frameon=False, title="sc / sn (dotted = Ref mean)")
    fig.suptitle("Proximal-tubule states across KDIGO severity in human AKI", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_PT_states_KDIGO.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_PT_states_KDIGO.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    clinical = pd.read_csv(RES.parent / "metadata/20260930_OpenAccessClinicalData.csv")
    clinical.columns = [c.strip() for c in clinical.columns]
    sc = load(SC, clinical)
    sn = load(SN, clinical)
    sc_table, sc_tests = pt_analysis(sc, "sc")
    sn_table, sn_tests = pt_analysis(sn, "sn")
    figure(sc_table, sn_table)
    print("PT state tests (sc):")
    print(sc_tests.to_string(index=False))
    print("\nPT state tests (sn):")
    print(sn_tests.to_string(index=False))


if __name__ == "__main__":
    main()
