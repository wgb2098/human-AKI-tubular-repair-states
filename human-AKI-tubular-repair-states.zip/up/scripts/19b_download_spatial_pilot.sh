#!/usr/bin/env bash
set -u
root=/media/desk16/iy16128/comorbidity_analysis/aki_repair
cd "$root"
while IFS='|' read -r url out size; do
  [ -z "$url" ] && continue
  mkdir -p "$(dirname "$out")"
  if [ -e "$out" ]; then printf 'exists %s\n' "$out"; continue; fi
  printf 'start %s (%s bytes)\n' "$(basename "$out")" "$size"
  for attempt in $(seq 1 8); do
    curl --http1.1 -L --silent --show-error --fail --connect-timeout 20 --max-time 900 \
      --continue-at - --user-agent 'Mozilla/5.0' --output "$out.part" "$url" && break
    printf 'retry %s for %s\n' "$attempt" "$(basename "$out")"
    sleep 5
  done
  if [ -s "$out.part" ]; then mv -- "$out.part" "$out"; stat --printf='saved %n (%s bytes)\n' "$out"; fi
done < /tmp/kpmp_spatial_download_list.txt
