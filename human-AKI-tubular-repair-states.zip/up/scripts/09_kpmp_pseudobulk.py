#!/usr/bin/env python3
"""Pseudobulk signature scores from downloaded KPMP single-cell matrices.

Runs incrementally: only matrices already present are processed.
"""

from __future__ import annotations

import gzip
import io
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.io import mmread
from scipy.sparse import csr_matrix

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
DATA = ROOT / "data/KPMP/sc"
RES = ROOT / "results"
SIGS = RES / "Klocke_signature_genes.csv"

CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]


def load_signatures() -> dict[str, list[str]]:
    sets = pd.read_csv(SIGS)
    return {name: list(g["gene"].astype(str)) for name, g in sets.groupby("signature")}


def read_zip(zip_path: Path) -> tuple[list[str], csr_matrix, int]:
    import re
    with zipfile.ZipFile(zip_path) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]

        matrix_name = next((n for n in names if "matrix" in n.lower() and ".mtx" in n.lower()), None)
        if matrix_name is None:
            raise FileNotFoundError(f"matrix not in {zip_path.name}: {names}")
        version_match = re.search(r"-v(\d+)", matrix_name)
        version = f"-v{version_match.group(1)}" if version_match else None

        def pick(keyword: str) -> str:
            candidates = [n for n in names if keyword in n.lower()]
            if version:
                versioned = [n for n in candidates if version in n]
                if versioned:
                    return versioned[0]
            if not candidates:
                raise FileNotFoundError(f"{keyword} not in {zip_path.name}: {names}")
            return candidates[0]

        def read_bytes(name: str) -> bytes:
            with z.open(name) as handle:
                data = handle.read()
            return gzip.decompress(data) if name.endswith(".gz") else data

        feature_name = pick("features") if any("features" in n.lower() for n in names) else pick("genes")
        features = pd.read_csv(io.BytesIO(read_bytes(feature_name)), sep="\t", header=None)
        barcodes = read_bytes(pick("barcodes")).decode(errors="replace").split()
        matrix = mmread(io.BytesIO(read_bytes(matrix_name))).tocsr()

    n_genes = matrix.shape[0]
    genes = features.iloc[:, 1].astype(str) if features.shape[1] > 1 else features.iloc[:, 0].astype(str)
    genes = list(genes)
    if len(genes) > n_genes:
        genes = genes[:n_genes]
    elif len(genes) < n_genes:
        genes = genes + [f"gene_{i}" for i in range(len(genes), n_genes)]
    return genes, matrix, len(barcodes)


def pseudobulk(genes: list[str], matrix: csr_matrix) -> pd.Series:
    totals = np.asarray(matrix.sum(axis=0)).ravel()
    keep = totals > 0
    matrix = matrix[:, keep]
    counts = np.asarray(matrix.sum(axis=1)).ravel()
    lib = counts.sum()
    cpm = counts / lib * 1e6
    result = pd.Series(np.log2(cpm + 1), index=genes)
    return result[~result.index.duplicated(keep="first")]


def main() -> None:
    manifest = pd.read_csv(ROOT / "metadata/KPMP_open_AKI_single_sample_matrices.csv")
    manifest = manifest[manifest["experimental_strategy"].str.contains("Single-cell RNA-Seq", na=False)].copy()
    manifest["path"] = manifest.apply(
        lambda r: DATA / f"{r['file_id']}_{r['file_name']}", axis=1)
    available = manifest[manifest["path"].apply(lambda p: p.exists())].copy()
    print(f"available matrices: {len(available)} / {len(manifest)}")
    if available.empty:
        print("no matrices available yet")
        return

    signatures = load_signatures()
    signatures["cycling"] = CYCLING
    rows = []
    for _, row in available.iterrows():
        try:
            genes, matrix, n_cells = read_zip(row["path"])
        except Exception as exc:
            print("skip", row["path"].name, exc)
            continue
        pb = pseudobulk(genes, matrix)
        record = {
            "file_id": row["file_id"], "participant": row["participants"],
            "stage": row["KDIGO Stage"], "n_cells": n_cells, "n_genes": len(pb),
            "total_UMI": float(matrix.sum()),
        }
        for name, gene_list in signatures.items():
            present = [g for g in gene_list if g in pb.index]
            record[f"{name}_score"] = pb.loc[present].mean() if len(present) >= 8 else np.nan
            record[f"{name}_n_genes"] = len(present)
        rows.append(record)
    table = pd.DataFrame(rows)
    table.to_csv(RES / "KPMP_sc_pseudobulk_signatures.csv", index=False)

    stage_num = pd.to_numeric(table["stage"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
    print("\nPer-sample signature table:")
    print(table.to_string(index=False))
    print("\nStage correlations:")
    for name in signatures:
        col = f"{name}_score"
        x = stage_num
        y = table[col]
        valid = x.notna() & y.notna()
        if valid.sum() >= 5 and x[valid].nunique() >= 2:
            rho, p = stats.spearmanr(x[valid], y[valid])
            print(f"  {name}: rho={rho:.3f}, p={p:.3f}, n={valid.sum()}")
        else:
            print(f"  {name}: not enough staged samples (n={valid.sum()})")


if __name__ == "__main__":
    main()
