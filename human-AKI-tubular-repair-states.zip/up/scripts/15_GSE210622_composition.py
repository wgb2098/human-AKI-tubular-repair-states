#!/usr/bin/env python3
"""Independent cell-composition validation in GSE210622 (Control / Non-COVID AKI / COVID AKI)."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
FIG = ROOT / "figures"
CELLS = ROOT / "metadata/GSE210622_cells.csv"

plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "font.size": 9})


def main() -> None:
    cells = pd.read_csv(CELLS)
    cells["group"] = cells["group"].replace({"Control": "Control", "Non-COVID": "AKI_nonCOVID", "COVID": "AKI_COVID"})
    fractions = (cells.groupby(["sample", "group", "celltype"]).size()
                 .unstack("celltype", fill_value=0))
    fractions = fractions.div(fractions.sum(axis=1), axis=0)
    fractions = fractions.reset_index()
    fractions.to_csv(RES / "GSE210622_sample_celltype_fractions.csv", index=False)

    celltypes = [c for c in fractions.columns if c not in ("sample", "group")]
    rows = []
    for ct in celltypes:
        control = fractions.loc[fractions["group"] == "Control", ct]
        noncov = fractions.loc[fractions["group"] == "AKI_nonCOVID", ct]
        cov = fractions.loc[fractions["group"] == "AKI_COVID", ct]
        aki = pd.concat([noncov, cov])
        rows.append({
            "celltype": ct,
            "n_control": len(control), "n_nonCOVID": len(noncov), "n_COVID": len(cov),
            "mean_control": control.mean(), "mean_nonCOVID": noncov.mean(), "mean_COVID": cov.mean(),
            "p_control_vs_AKI": stats.mannwhitneyu(control, aki).pvalue if len(control) >= 3 and len(aki) >= 3 else np.nan,
            "p_nonCOVID_vs_COVID": stats.mannwhitneyu(noncov, cov).pvalue if len(noncov) >= 3 and len(cov) >= 3 else np.nan,
        })
    tests = pd.DataFrame(rows)
    tests["fdr_control_vs_AKI"] = multipletests(tests["p_control_vs_AKI"].fillna(1), method="fdr_bh")[1]
    tests["fdr_nonCOVID_vs_COVID"] = multipletests(tests["p_nonCOVID_vs_COVID"].fillna(1), method="fdr_bh")[1]
    tests.to_csv(RES / "GSE210622_composition_tests.csv", index=False)

    # Stacked composition figure
    order = ["Control", "AKI_nonCOVID", "AKI_COVID"]
    fractions["group"] = pd.Categorical(fractions["group"], categories=order, ordered=True)
    fractions = fractions.sort_values("group")
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5), gridspec_kw={"width_ratios": [2, 1.4]})
    bottom = np.zeros(len(fractions))
    palette = plt.cm.tab20(np.linspace(0, 1, len(celltypes)))
    for color, ct in zip(palette, celltypes):
        axes[0].bar(fractions["sample"], fractions[ct], bottom=bottom, label=ct, color=color, width=0.7)
        bottom += fractions[ct].values
    axes[0].set_xticklabels(fractions["sample"], rotation=60, ha="right", fontsize=7)
    axes[0].set_ylabel("Cell-type fraction")
    axes[0].set_title("GSE210622 cell composition per sample")
    axes[0].legend(bbox_to_anchor=(1.0, 1.0), frameon=False, fontsize=6, ncol=2)

    key_types = ["PT", "TAL", "Leuk", "EC"]
    for pos, ct in enumerate(key_types, 1):
        data = [fractions.loc[fractions["group"] == g, ct] for g in order]
        for offset, vals, color in zip([-0.25, 0.0, 0.25], data, ["#7F8C8D", "#2874A6", "#C0392B"]):
            axes[1].boxplot([vals], positions=[pos + offset], widths=0.2, patch_artist=True,
                            boxprops=dict(facecolor=color, alpha=0.55), medianprops=dict(color="black"))
            axes[1].scatter(np.ones(len(vals)) * (pos + offset), vals, s=12, color=color)
    axes[1].set_xticks(range(1, len(key_types) + 1)); axes[1].set_xticklabels(key_types)
    axes[1].set_ylabel("Fraction")
    axes[1].set_title("Key compartments (grey=Control, blue=AKI non-COVID, red=COVID)")
    fig.tight_layout()
    fig.savefig(FIG / "Fig_GSE210622_composition.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_GSE210622_composition.pdf", bbox_inches="tight")
    plt.close(fig)

    print("Cell-type fraction tests:")
    print(tests.sort_values("p_control_vs_AKI").to_string(index=False))


if __name__ == "__main__":
    main()
