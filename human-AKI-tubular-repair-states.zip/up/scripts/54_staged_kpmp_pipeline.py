#!/usr/bin/env python3
"""Staged pipeline for the KPMP-reference RCTD run.

Stage 1: wait until enough sn matrices are on disk (>=12 files spanning >=3
         conditions) -> build the KPMP sn reference -> RCTD on the 16 sections
         -> compare the two references.
Stage 2: wait for the remaining downloads -> KPMP sn PT pseudobulk -> refresh the
         final numbers table -> refresh checksums.

Running the reference build on a subset keeps the critical path short; the
remaining samples only add to the PT pseudobulk cohort in stage 2.
"""

from __future__ import annotations

import hashlib
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
LOGS = ROOT / "logs"
SN = ROOT / "data/KPMP/sn"
MANIFEST = ROOT / "metadata/KPMP_open_sn_single_sample_matrices.csv"
PATIENTS = ["34-10184", "34-10729", "34-10666", "30-11084", "34-11066", "34-11025", "936-10217",
            "30-11072", "30-10868", "34-10187", "30-11080", "30-11141", "34-10306", "34-10331",
            "30-10018", "34-11042"]
STAGE1_MIN_FILES = 12
STAGE1_MIN_CONDITIONS = 3


def run(command: list[str], log: str) -> None:
    with open(LOGS / log, "a") as handle:
        subprocess.run(command, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT)


def on_disk() -> pd.DataFrame:
    manifest = pd.read_csv(MANIFEST)
    manifest["file_id"] = manifest["file_id"].astype(str)
    present = {p.name.split("_")[0] for p in SN.glob("*.zip")}
    manifest["present"] = manifest["file_id"].isin(present)
    return manifest


def downloader_active() -> bool:
    result = subprocess.run(["pgrep", "-f", "kpmp_sn_missing_"], capture_output=True, text=True)
    return bool(result.stdout.strip())


def wait_for(predicate, description: str, timeout_hours: float = 8.0) -> bool:
    start = time.time()
    while True:
        frame = on_disk()
        done = int(frame["present"].sum())
        conditions = frame.loc[frame["present"], "condition"].nunique()
        active = downloader_active()
        print(f"[{time.strftime('%H:%M:%S')}] {description}: {done}/{len(frame)} files, "
              f"{conditions} conditions (downloader active: {active})", flush=True)
        if predicate(done, conditions) or (not active and done > 0):
            return done > 0
        if time.time() - start > timeout_hours * 3600:
            print("timeout", flush=True)
            return False
        time.sleep(150)


def refresh_checksums() -> None:
    targets = []
    for folder in ("results", "figures", "reports", "scripts", "metadata"):
        targets += sorted(p for p in (ROOT / folder).rglob("*") if p.is_file() and p.suffix != ".pyc")
    lines = []
    for path in targets:
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b""):
                digest.update(chunk)
        lines.append(f"{digest.hexdigest()}  {path.relative_to(ROOT)}")
    (ROOT / "reports/file_checksums.sha256").write_text("\n".join(lines) + "\n")
    print(f"checksums refreshed ({len(lines)} files)", flush=True)


def main() -> None:
    # ---------------- stage 1 ----------------
    ok = wait_for(lambda done, conds: done >= STAGE1_MIN_FILES and conds >= STAGE1_MIN_CONDITIONS,
                  "stage 1 (reference build)")
    if not ok:
        print("no sn matrices available; aborting", flush=True)
        return

    run([sys.executable, "-I", "scripts/49_build_rctd_reference_kpmp.py"], "rctd_kpmp_reference.log")
    if not (ROOT / "data/rctd_reference_kpmp/reference_counts.mtx").exists():
        print("reference build failed; aborting stage 1", flush=True)
    else:
        batches = [PATIENTS[i::4] for i in range(4)]
        processes = []
        for index, batch in enumerate(batches):
            handle = open(LOGS / f"rctd_kpmp_batch_{index}.log", "w")
            processes.append(subprocess.Popen(
                ["Rscript", "scripts/50_rctd_visium_kpmp_reference.R", ",".join(batch)],
                cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True))
            print(f"launched RCTD batch {index}", flush=True)
        for process in processes:
            process.wait()
        print("KPMP-reference RCTD finished", flush=True)
        run([sys.executable, "-I", "scripts/52_compare_rctd_references.py"], "rctd_kpmp_compare.log")
        print("reference comparison written", flush=True)

    # ---------------- stage 2 ----------------
    wait_for(lambda done, conds: done >= 43, "stage 2 (all matrices)")
    run([sys.executable, "-I", "scripts/53_sn_PT_pseudobulk.py"], "sn_pt_pseudobulk.log")
    run([sys.executable, "-I", "scripts/47_final_numbers.py"], "final_numbers.log")
    refresh_checksums()
    print("staged pipeline complete", flush=True)


if __name__ == "__main__":
    main()
