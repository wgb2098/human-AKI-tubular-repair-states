#!/usr/bin/env python3
"""Compile the single authoritative numbers table used by the manuscript.

One long table with a frozen convention:
  * statistics are patient level (or sample level where patients are the samples),
  * medians (not means) are reported,
  * FDR is given twice: within a predefined feature family and globally within the
    same analysis level and contrast.

Sources: reviewer_* tables, KPMP PT pseudobulk tables, GSE210622 tables and the
cohort accounting of the pseudobulk comparison.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
REPORTS = ROOT / "reports"

FAMILIES = {
    "epithelial_state_fraction": ["frac_state_adaptive - epi", "frac_state_adaptive - str",
                                  "frac_state_degenerative", "frac_state_reference",
                                  "frac_state_cycling", "frac_state_transitioning"],
    "subclass_fraction": ["frac_sub_PT", "frac_sub_TAL", "frac_sub_DTL", "frac_sub_ATL", "frac_sub_CNT",
                          "frac_sub_DCT", "frac_sub_IC", "frac_sub_PC", "frac_sub_EC", "frac_sub_VSM/P",
                          "frac_sub_POD", "frac_sub_PEC", "frac_sub_FIB", "frac_sub_IMM", "frac_sub_NEU",
                          "frac_sub_PapE"],
    "module_score": ["mean_aEpi.score", "mean_degen.score", "mean_cyc.score", "mean_aStr.score",
                     "mean_matrisome.score", "mean_collagen.score", "mean_glycoprotein.score",
                     "mean_proteoglycan.score", "mean_aEpi", "mean_degen", "mean_cyc"],
    "qc": ["mean_percent.mt", "mean_nFeature_RNA"],
    "pt_state_fraction": ["frac_adaptive", "frac_degenerative", "frac_reference", "frac_cycling",
                          "frac_transitioning", "repair_index"],
    "pt_pseudobulk_signature": ["injury_stress", "repair_progenitor", "cycling", "reference_PT",
                                "aPT_markers", "hypoxia_targets", "reference_state_frac",
                                "cycling_state_frac"],
    "pseudobulk_signature": ["injury_stress", "repair_progenitor", "cycling", "reference_PT"],
}


def family_of(feature: str) -> str:
    for family, members in FAMILIES.items():
        if feature in members:
            return family
    return "other"


def add_fdr(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    for column in ("statistic", "statistic_name"):
        if column not in frame.columns:
            frame[column] = np.nan
    frame["fdr_family"] = np.nan
    frame["fdr_global"] = np.nan
    keys = ["analysis_level", "cohort", "contrast"]
    for _, index in frame.groupby(keys, dropna=False).groups.items():
        subset = frame.loc[index]
        frame.loc[index, "fdr_global"] = multipletests(subset["p"].fillna(1), method="fdr_bh")[1]
        for family, group_index in subset.groupby(subset["feature"].map(family_of)).groups.items():
            frame.loc[group_index, "fdr_family"] = multipletests(
                frame.loc[group_index, "p"].fillna(1), method="fdr_bh")[1]
    return frame


def load_three_group(cohort: str, entity: str) -> pd.DataFrame:
    path = RES / f"reviewer_{cohort}_{entity}_three_group.csv"
    table = pd.read_csv(path)
    rows = []
    for _, row in table.iterrows():
        for contrast in ("AKI_vs_Ref", "AKI_vs_CKD", "CKD_vs_Ref"):
            p = row.get(f"p_{contrast}")
            if pd.isna(p):
                continue
            group_a, group_b = contrast.split("_vs_")
            rows.append({
                "analysis_level": f"{cohort}_{entity}", "cohort": cohort, "contrast": contrast,
                "feature": row["feature"], "family": family_of(row["feature"]),
                "n_a": row.get(f"n_{group_a}"), "n_b": row.get(f"n_{group_b}"),
                "median_a": row.get(f"median_{group_a}"), "median_b": row.get(f"median_{group_b}"),
                "p": p, "test": "Mann-Whitney U", "unit": "patient",
                "covariates": "none", "source_table": path.name,
            })
    return pd.DataFrame(rows)



def extra_layers() -> pd.DataFrame:
    """补充层：KDIGO 趋势、严重度 meta、GSE139061、GSE67401、尿液与感染亚组。

    这些数字此前只在各自报告里，未进 FINAL 表（审计意见 A5）。
    """
    rows = []

    def add(level, cohort, contrast, feature, stat, stat_name, p, n, source, test="Spearman rho"):
        rows.append({"analysis_level": level, "cohort": cohort, "contrast": contrast,
                     "feature": feature, "family": family_of(feature),
                     "n_a": n, "n_b": np.nan, "median_a": np.nan, "median_b": np.nan,
                     "p": p, "test": test, "unit": "patient", "covariates": "none",
                     "source_table": source, "statistic": stat, "statistic_name": stat_name})

    # KDIGO 趋势（患者水平）
    path = RES / "KPMP_sc_PT_pseudobulk_stage_trend.csv"
    if path.exists():
        for _, r in pd.read_csv(path).iterrows():
            add("KDIGO_trend", "sc", "stage", r["feature"], r["rho"], "rho", r["p"], r["n"], path.name)
    for name, level in (("KPMP_sc_feature_tests.csv", "sc_tissue_trend"),
                        ("KPMP_sn_feature_tests.csv", "sn_tissue_trend")):
        path = RES / name
        if path.exists():
            for _, r in pd.read_csv(path).iterrows():
                if pd.notna(r.get("spearman_p_stage")):
                    add("KDIGO_trend", name.split("_")[1], "stage", r["feature"], r.get("spearman_rho_stage"),
                        "rho", r["spearman_p_stage"], r.get("n_stage", np.nan), name)
    path = RES / "spatial_rctd_stage_trends_by_reference.csv"
    if path.exists():
        for _, r in pd.read_csv(path).iterrows():
            add(f"KDIGO_trend_spatial_{r['reference']}", "spatial", "stage", r["feature"],
                r["rho"], "rho", r["p"], r["n"], path.name)
    path = RES / "spatial_rctd_stage_trends.csv"
    if path.exists():
        for _, r in pd.read_csv(path).iterrows():
            add("KDIGO_trend_spatial_GSE210622", "spatial", "stage", r["feature"], r["rho"], "rho",
                r["p"], r["n"], path.name)

    # 严重度跨队列 meta
    path = RES / "severity_meta_analysis.csv"
    if path.exists():
        meta = pd.read_csv(path)
        for _, r in meta.iterrows():
            add("severity_meta", "KPMP_sc+GSE67401", "stage_meta", r["signature"],
                r.get("pooled_rho"), "pooled rho", r.get("pooled_p"),
                (r.get("KPMP sc (kidney)_n", 0) or 0) + (r.get("GSE67401 (blood)_n", 0) or 0), path.name,
                test="random-effects (DerSimonian-Laird)")

    # 其它队列
    path = RES / "GSE139061_signature_validation.csv"
    if path.exists():
        for _, r in pd.read_csv(path).iterrows():
            rows.append({"analysis_level": "GSE139061_bulk", "cohort": "GSE139061",
                         "contrast": "AKI_vs_Ref", "feature": r["signature"],
                         "family": family_of(str(r["signature"])),
                         "n_a": r.get("n_AKI"), "n_b": r.get("n_Ref"),
                         "median_a": np.nan, "median_b": np.nan, "p": r.get("mannwhitney_p"),
                         "test": "Mann-Whitney U (AUC)", "unit": "sample", "covariates": "none",
                         "source_table": path.name, "statistic": r.get("auc"),
                         "statistic_name": "AUC"})
    path = RES / "GSE67401_blood_signature_validation.csv"
    if path.exists():
        for _, r in pd.read_csv(path).iterrows():
            rows.append({"analysis_level": "GSE67401_blood", "cohort": "GSE67401",
                         "contrast": "AKI_vs_non_AKI", "feature": r["signature"],
                         "family": family_of(str(r["signature"])),
                         "n_a": 53, "n_b": 58,      # 文档化桥接：111 例 SIRS = 53 AKI + 58 non-AKI
                         "median_a": r.get("mean_AKI"), "median_b": r.get("mean_nonAKI"),
                         "p": r.get("mannwhitney_p"), "test": "Mann-Whitney U",
                         "unit": "sample", "covariates": "none", "source_table": path.name,
                         "statistic": r.get("spearman_rho_stage"), "statistic_name": "rho vs stage"})
    path = RES / "infection_AKI_sn_tests.csv"
    if path.exists():
        for _, r in pd.read_csv(path).iterrows():
            rows.append({"analysis_level": "infection_sn", "cohort": "KPMP_sn",
                         "contrast": "COV-AKI_vs_AKI", "feature": r["feature"],
                         "family": family_of(str(r["feature"])), "n_a": r.get("n_COV"),
                         "n_b": r.get("n_AKI"), "median_a": r.get("mean_COV"),
                         "median_b": r.get("mean_AKI"), "p": r.get("p_COV_vs_AKI"),
                         "test": "Mann-Whitney U", "unit": "patient", "covariates": "none",
                         "source_table": path.name, "statistic": np.nan, "statistic_name": np.nan})
    path = RES / "infection_AKI_urine_tests.csv"
    if path.exists():
        for _, r in pd.read_csv(path).iterrows():
            rows.append({"analysis_level": "infection_urine", "cohort": "urine",
                         "contrast": "infection_vs_noninfectious", "feature": r["feature"],
                         "family": "other", "n_a": r.get("n_infection"), "n_b": r.get("n_non"),
                         "median_a": r.get("median_infection"), "median_b": r.get("median_non"),
                         "p": r.get("p"), "test": "Mann-Whitney U / chi2", "unit": "patient",
                         "covariates": "none", "source_table": path.name,
                         "statistic": np.nan, "statistic_name": np.nan})
    path = RES / "urine_recovery_correlation.csv"
    if path.exists():
        for _, r in pd.read_csv(path).iterrows():
            rows.append({"analysis_level": "urine_recovery", "cohort": "urine",
                         "contrast": "KDIGO_vs_recovery_slope",
                         "feature": "KDIGO stage vs log-creatinine slope",
                         "family": "other", "n_a": r.get("n_patients"), "n_b": np.nan,
                         "median_a": np.nan, "median_b": np.nan, "p": r.get("p"),
                         "test": "Spearman rho", "unit": "patient", "covariates": "none",
                         "source_table": path.name,
                         "statistic": r.get("stage_vs_creatinine_log_slope_rho"),
                         "statistic_name": "rho"})
    return pd.DataFrame(rows)


def main() -> None:
    frames = []

    # 1) atlas, patient level, three groups (sc and sn; tissue and PT)
    for cohort in ("sc", "sn"):
        for entity in ("tissue", "PT"):
            try:
                frames.append(load_three_group(cohort, entity))
            except FileNotFoundError:
                print("missing", cohort, entity)

    # 2) PT pseudobulk (sc, patient level, three groups)
    pt = pd.read_csv(RES / "KPMP_sc_PT_pseudobulk_three_group.csv")
    rows = []
    for _, row in pt.iterrows():
        group_a, group_b = row["contrast"].split("_vs_")
        rows.append({
            "analysis_level": "sc_PT_pseudobulk", "cohort": "sc", "contrast": row["contrast"],
            "feature": row["feature"], "family": family_of(row["feature"]),
            "n_a": row["n_a"], "n_b": row["n_b"], "median_a": row["median_a"], "median_b": row["median_b"],
            "p": row["p"], "test": "Mann-Whitney U", "unit": "patient",
            "covariates": "none", "source_table": "KPMP_sc_PT_pseudobulk_three_group.csv",
        })
    frames.append(pd.DataFrame(rows))

    # 3) whole-library pseudobulk: library vs patient level
    lib = pd.read_csv(RES / "reviewer_pseudobulk_library_vs_patient.csv")
    rows = []
    for _, row in lib.iterrows():
        for scope, p_column, n_a, n_b in (
                ("library", "p_library_level", row["n_lib_AKI"], row["n_lib_Ref"]),
                ("patient", "p_patient_level", row["n_pat_AKI"], row["n_pat_Ref"])):
            rows.append({
                "analysis_level": f"whole_library_pseudobulk_{scope}", "cohort": "sc",
                "contrast": "AKI_vs_Ref", "feature": row["signature"],
                "family": "pseudobulk_signature", "n_a": n_a, "n_b": n_b,
                "median_a": row[f"median_{'lib' if scope == 'library' else 'pat'}_AKI"],
                "median_b": row[f"median_{'lib' if scope == 'library' else 'pat'}_Ref"],
                "p": row[p_column], "test": "Mann-Whitney U", "unit": scope,
                "covariates": "none", "source_table": "reviewer_pseudobulk_library_vs_patient.csv",
            })
    frames.append(pd.DataFrame(rows))

    # 4) composition-adjusted whole library (annotated subset)
    adj_lib = pd.read_csv(RES / "reviewer_wholelibrary_annotated_tests.csv")
    rows = []
    for _, row in adj_lib.iterrows():
        for label, p, cov in (("unadjusted", row["p_unadjusted"], "none"),
                              ("PT-fraction adjusted", row["p_adjusted_PTfraction"], "annotated PT fraction")):
            rows.append({
                "analysis_level": f"whole_library_pseudobulk_annotated_{label.split()[0]}",
                "cohort": "sc", "contrast": "AKI_vs_Ref", "feature": row["signature"],
                "family": "pseudobulk_signature", "n_a": row["n_AKI"], "n_b": row["n_Ref"],
                "median_a": row["median_AKI"], "median_b": row["median_Ref"], "p": p,
                "test": "rank-ANCOVA (HC3)", "unit": "patient", "covariates": cov,
                "source_table": "reviewer_wholelibrary_annotated_tests.csv",
            })
    frames.append(pd.DataFrame(rows))

    # 5) covariate-adjusted main contrasts
    for cohort in ("sc", "sn"):
        path = RES / f"reviewer_{cohort}_adjusted_contrasts.csv"
        table = pd.read_csv(path)
        rows = []
        for _, row in table.iterrows():
            for label, p, cov in (("unadjusted", row["p_unadjusted_mannwhitney"], "none"),
                                  ("sex adjusted", row["p_sex_adjusted"], "sex"),
                                  ("sex+age adjusted", row["p_sex_age_adjusted"], "sex, age"),
                                  ("sex+age+eGFR adjusted", row["p_sex_age_egfr_adjusted"],
                                   "sex, age, baseline eGFR")):
                if pd.isna(p):
                    continue
                rows.append({
                    "analysis_level": f"{cohort}_adjusted", "cohort": cohort,
                    "contrast": row["contrast"], "feature": row["feature"],
                    "family": family_of(row["feature"]), "n_a": row["n_AKI"], "n_b": row["n_other"],
                    "median_a": np.nan, "median_b": np.nan, "p": p,
                    "test": "rank-ANCOVA (HC3)" if label != "unadjusted" else "Mann-Whitney U",
                    "unit": "patient", "covariates": cov, "source_table": path.name,
                })
        frames.append(pd.DataFrame(rows))

    # 5b) KPMP sn PT pseudobulk (third PT-level dataset)
    sn_path = RES / "KPMP_sn_PT_pseudobulk_three_group.csv"
    if sn_path.exists():
        sn = pd.read_csv(sn_path)
        rows = []
        for _, row in sn.iterrows():
            group_a, group_b = row["contrast"].split("_vs_")
            rows.append({
                "analysis_level": "sn_PT_pseudobulk", "cohort": "sn", "contrast": row["contrast"],
                "feature": row["feature"], "family": family_of(row["feature"]),
                "n_a": row["n_a"], "n_b": row["n_b"], "median_a": row["median_a"],
                "median_b": row["median_b"], "p": row["p"], "test": "Mann-Whitney U",
                "unit": "patient", "covariates": "none",
                "source_table": "KPMP_sn_PT_pseudobulk_three_group.csv",
            })
        frames.append(pd.DataFrame(rows))

    # 5c) state-specific DE（adaptive/degenerative/reference 内的 AKI vs CKD 等）
    summary_path = RES / "state_DE_summary.csv"
    if summary_path.exists():
        s = pd.read_csv(summary_path)
        rows = []
        for _, r in s.iterrows():
            rows.append({"analysis_level": f"state_DE_{r['state']}", "cohort": "sc",
                         "contrast": r["contrast"], "feature": f"n_DE_genes({r['contrast']})",
                         "family": "state_specific_DE", "n_a": r["n_patients_a"],
                         "n_b": r["n_patients_b"], "median_a": np.nan, "median_b": np.nan,
                         "p": np.nan, "test": "edgeR QL F-test (sex-adjusted)",
                         "unit": "patient", "covariates": "sex",
                         "source_table": "state_DE_summary.csv",
                         "statistic": r["n_DE"], "statistic_name": "n_DE_genes_FDR0.05"})
            rows.append({"analysis_level": f"state_DE_{r['state']}", "cohort": "sc",
                         "contrast": r["contrast"], "feature": "top_gene_logFC",
                         "family": "state_specific_DE", "n_a": r["n_patients_a"],
                         "n_b": r["n_patients_b"], "median_a": np.nan, "median_b": np.nan,
                         "p": r["top_FDR"], "test": "edgeR QL F-test (sex-adjusted)",
                         "unit": "patient", "covariates": "sex",
                         "source_table": "state_DE_summary.csv",
                         "statistic": r["top_logFC"], "statistic_name": f"top gene: {r['top_gene']}"})
        frames.append(pd.DataFrame(rows))
    set_tests = RES / "state_DE_gene_set_tests.csv"
    if set_tests.exists():
        st = pd.read_csv(set_tests)
        rows = []
        for _, r in st.iterrows():
            rows.append({"analysis_level": "state_DE_gene_sets", "cohort": "sc",
                         "contrast": f"{r['state']}|{r['contrast']}", "feature": r["gene_set"],
                         "family": "state_specific_DE", "n_a": r["n_genes_in_set"], "n_b": np.nan,
                         "median_a": r["median_logFC_set"], "median_b": np.nan, "p": r["p"],
                         "test": "competitive Mann-Whitney (logFC vs background)",
                         "unit": "gene", "covariates": "sex",
                         "source_table": "state_DE_gene_set_tests.csv",
                         "statistic": r["median_logFC_set"], "statistic_name": "median logFC"})
        frames.append(pd.DataFrame(rows))

    # 5d) 尿液桥梁（②）
    urine_path = RES / "urine_signature_clinical.csv"
    if urine_path.exists():
        u = pd.read_csv(urine_path)
        rows = []
        for _, r in u.iterrows():
            rows.append({"analysis_level": "urine_bridge", "cohort": "urine (GSE199321)",
                         "contrast": r["comparison"], "feature": r["feature"],
                         "family": "urine_bridge", "n_a": r["n"], "n_b": np.nan,
                         "median_a": np.nan, "median_b": np.nan, "p": r["p"],
                         "test": r["test"], "unit": "sample", "covariates": "none",
                         "source_table": "urine_signature_clinical.csv",
                         "statistic": r["statistic"], "statistic_name": "rho"})
        frames.append(pd.DataFrame(rows))

    # 5e) 聚焦配体-受体（③）
    lr_path = RES / "cellcomm_LR_tests.csv"
    if lr_path.exists():
        lr = pd.read_csv(lr_path)
        rows = []
        for _, r in lr.iterrows():
            for contrast in ("AKI_vs_CKD", "AKI_vs_Ref"):
                pcol = f"p_{contrast}"
                if pcol in lr.columns and pd.notna(r.get(pcol)):
                    rows.append({"analysis_level": "cellcomm_LR", "cohort": "sc",
                                 "contrast": contrast, "feature": f"{r['ligand']}->{r['receptor_set']}",
                                 "family": "ligand_receptor", "n_a": r["n_AKI"],
                                 "n_b": r["n_CKD"] if contrast == "AKI_vs_CKD" else r["n_Ref"],
                                 "median_a": r["median_AKI"],
                                 "median_b": r["median_CKD"] if contrast == "AKI_vs_CKD" else r["median_Ref"],
                                 "p": r[pcol], "test": "Mann-Whitney U (patient level)",
                                 "unit": "patient", "covariates": "none",
                                 "source_table": "cellcomm_LR_tests.csv",
                                 "statistic": np.nan, "statistic_name": np.nan})
        if rows:
            frames.append(pd.DataFrame(rows))
    link_path = RES / "cellcomm_LR_links.csv"
    if link_path.exists():
        lk = pd.read_csv(link_path)
        rows = []
        for _, r in lk.iterrows():
            rows.append({"analysis_level": "cellcomm_LR_links", "cohort": "sc",
                         "contrast": "LR_score_vs_immune_fraction",
                         "feature": f"{r['ligand']}->{r['receptor_set']}",
                         "family": "ligand_receptor", "n_a": r["n"], "n_b": np.nan,
                         "median_a": np.nan, "median_b": np.nan,
                         "p": r["p_vs_immune_fraction"], "test": "Spearman rho",
                         "unit": "patient", "covariates": "none",
                         "source_table": "cellcomm_LR_links.csv",
                         "statistic": r["rho_vs_immune_fraction"], "statistic_name": "rho"})
        frames.append(pd.DataFrame(rows))

    # 5f) 伪计数敏感性
    pseudo_path = RES / "PT_pseudocount_sensitivity.csv"
    if pseudo_path.exists():
        ps = pd.read_csv(pseudo_path)
        rows = []
        for _, r in ps.iterrows():
            for tag in ("+1", "+0.5", "+0.1"):
                if f"p_{tag}" in ps.columns and pd.notna(r.get(f"p_{tag}")):
                    rows.append({"analysis_level": "PT_pseudocount_sensitivity", "cohort": "sc",
                                 "contrast": f"AKI_vs_Ref|pseudo{tag}",
                                 "feature": r["feature"], "family": "pt_pseudobulk_signature",
                                 "n_a": 12, "n_b": 18,
                                 "median_a": r.get(f"median_AKI_{tag}"), "median_b": r.get(f"median_Ref_{tag}"),
                                 "p": r[f"p_{tag}"], "test": "Mann-Whitney U (patient level)",
                                 "unit": "patient", "covariates": "none",
                                 "source_table": "PT_pseudocount_sensitivity.csv",
                                 "statistic": r.get(f"fdr_{tag}"), "statistic_name": "fdr_family"})
        frames.append(pd.DataFrame(rows))

    # 6) independent cohorts
    gse = pd.read_csv(RES / "GSE210622_PT_pseudobulk_tests.csv")
    rows = []
    for _, row in gse.iterrows():
        rows.append({
            "analysis_level": "GSE210622_PT_pseudobulk", "cohort": "GSE210622", "contrast": "AKI_vs_Control",
            "feature": row["feature"], "family": family_of(row["feature"]),
            "n_a": row["n_AKI"], "n_b": row["n_Control"],
            "median_a": row["median_AKI"], "median_b": row["median_Control"], "p": row["p"],
            "test": "Mann-Whitney U", "unit": "sample", "covariates": "none",
            "source_table": "GSE210622_PT_pseudobulk_tests.csv",
        })
    frames.append(pd.DataFrame(rows))

    frames.append(extra_layers())
    table = pd.concat(frames, ignore_index=True)
    table = add_fdr(table)
    table["p"] = table["p"].astype(float)
    table = table.sort_values(["analysis_level", "contrast", "p"])
    table.to_csv(RES / "FINAL_manuscript_numbers.csv", index=False)
    print(f"FINAL_manuscript_numbers.csv: {len(table)} rows, "
          f"{table['analysis_level'].nunique()} analysis levels")

    # cohort accounting (answers the 51 vs 57 question)
    accounting = []
    combined = pd.read_csv(RES / "KPMP_combined_pseudobulk_signatures.csv")
    for group, sub in combined.groupby("group"):
        accounting.append({"cohort": "KPMP whole-library pseudobulk", "group": group,
                           "libraries": len(sub), "participants": sub["participant"].nunique()})
    for cohort, manifest, strategy in [
            ("sc (AKI enrollment)", "KPMP_open_AKI_single_sample_matrices.csv", "Single-cell RNA-Seq"),
            ("AKI manifest (all strategies)", "KPMP_open_AKI_single_sample_matrices.csv", None),
            ("sc_ref (Reference enrollment)", "KPMP_open_Ref_single_sample_matrices.csv", "Single-cell RNA-Seq"),
            ("sc_ckd (CKD enrollment)", "KPMP_open_CKD_single_sample_matrices.csv", "Single-cell RNA-Seq"),
            ("sn (GSE183277 samples)", "KPMP_open_sn_single_sample_matrices.csv", "Single-nucleus RNA-Seq")]:
        path = ROOT / "metadata" / manifest
        if not path.exists():
            continue
        frame = pd.read_csv(path)
        label = "manifest rows (all strategies)" if strategy is None else "expression matrices"
        if strategy:
            frame = frame[frame["experimental_strategy"].astype(str).str.contains(strategy, na=False)]
        detail = ""
        if strategy is None:
            counts = frame["experimental_strategy"].astype(str).value_counts()
            detail = " / ".join(f"{k.replace(chr(39)+'['+chr(39),'').replace(chr(39)+']'+chr(39),'')}: {v}"
                                for k, v in counts.items())
            accounting.append({"cohort": f"KPMP {cohort}", "group": label,
                               "libraries": len(frame), "participants": frame["participants"].nunique(),
                               "detail": detail,
                               "note": "仅其中 Single-cell RNA-Seq 行（42/38）用于 PT pseudobulk"})
            continue
        accounting.append({"cohort": f"KPMP {cohort}", "group": label,
                           "libraries": len(frame), "participants": frame["participants"].nunique(),
                           "detail": detail, "note": ""})
    for level, path in [("sc_PT_pseudobulk", "KPMP_sc_PT_pseudobulk_patient.csv")]:
        frame = pd.read_csv(RES / path)
        for group, sub in frame.groupby("group"):
            accounting.append({"cohort": level, "group": group, "libraries": int(sub["n_libraries"].sum()),
                               "participants": len(sub)})
    pd.DataFrame(accounting).to_csv(RES / "FINAL_cohort_accounting.csv", index=False)

    # markdown digest of the headline numbers
    from datetime import date as _date
    lines = ["# 稿件最终数字（权威来源）", f"生成时间：{_date.today().isoformat()}", "",
             "**唯一数据源**：`results/FINAL_manuscript_numbers.csv`（长表）。字段：`analysis_level / cohort / contrast / feature / family / n_a / n_b / median_a / median_b / statistic / statistic_name / p / test / unit / covariates / fdr_family / fdr_global / source_table`。",
             "",
             "**覆盖范围**（`analysis_level` 全清单见文末）：图谱层（sc/sn：组织层、PT 层、校正模型）、PT pseudobulk（sc、sn、GSE210622 三个队列）、全库 pseudobulk（文库口径/患者口径/组成校正）、**KDIGO 分期趋势（图谱/PT/空间三套）**、**严重度跨队列 meta**、**GSE139061 / GSE67401 / 尿液 / 感染亚组**、空间 RCTD 双参考对比。",
             "",
             "## 口径说明（回答审稿人可能提出的 6 类「看似矛盾」）",
             "",
             "1. **sn 参考组 13 vs 12**：组织层 13 名参考患者，PT 层 12 名（1 名参考患者无 PT 细胞）。同一患者在不同层缺席属正常，非数据冲突。",
             "2. **sn PT 内 cycling 方向与 sc 相反**（AKI 0.72% < Ref 1.00%，而 sc 为 4.14% > 0%）：数值在两个文件中互相吻合，是**真实的跨平台不一致**；sn 平台核内 S 期转录本缺失、AKI 侧仅 4 例，故不作为结论。",
             "3. **FDR 两级标注（关键示例）**：sn 组织层 adaptive-epi 与 reference 的 `fdr_family=0.021`（显著）而 `fdr_global=0.107`（不显著）——按冻结口径应表述为**显著**，全局值只作敏感性；切勿用 `fdr_global` 下结论。`fdr_family` 为预定义特征族内 BH 校正，`fdr_global` 为同一分析层/对比内全部特征校正。**BH 非单调，`fdr_global` 并非恒严于 `fdr_family`**（共 {n_rows} 行中 {n_gl} 行出现 global < family）。结论以 `fdr_family`（冻结口径）为准，`fdr_global` 仅作敏感性。",
             "4. **全库 pseudobulk 文库数 41 vs 42**：cycling 行为 41（1 个 AKI 文库缺 cycling 基因覆盖），其余签名为 42。",
             "5. **严重度分析的多重 n**：42 个 AKI 文库 → 34 个有 KDIGO 分期 → 33 个同时有 cycling 分值（1 个文库缺 cycling 基因）→ 患者水平聚合后 30 名患者；跨队列 meta 用 30 名 KPMP 患者 + 53 例 GSE67401 血液样本。引用时必须标明层级。",
             "6. **GSE67401 的 111 vs 53**：数据集共 133 个样本（111 例 SIRS：58 非 AKI + 53 AKI；另 22 例血液透析对照），严重度 meta 只用其中的 53 例 SIRS-AKI。",
             "",
             "## 分析层（共 {n_layers} 层）",
             ""]
    headline = table[table["feature"].isin(
        ["frac_state_adaptive - epi", "frac_state_reference", "frac_state_cycling", "frac_sub_IMM",
         "frac_adaptive", "frac_reference", "frac_cycling", "repair_index",
         "injury_stress", "repair_progenitor", "cycling", "reference_PT", "aPT_markers"])]
    for (level, contrast), group in headline.groupby(["analysis_level", "contrast"]):
        lines.append(f"## {level} — {contrast}")
        lines.append("")
        lines.append("| feature | n | median A | median B | p | FDR(family) | FDR(global) |")
        lines.append("|---|---:|---:|---:|---:|---:|---:|")
        for _, row in group.sort_values("p").iterrows():
            lines.append(f"| {row['feature']} | {row['n_a']}/{row['n_b']} | {row['median_a']:.4g} | "
                         f"{row['median_b']:.4g} | {row['p']:.4g} | {row['fdr_family']:.4g} | "
                         f"{row['fdr_global']:.4g} |")
        lines.append("")
    text = "\n".join(lines).replace("{n_layers}", str(table["analysis_level"].nunique()))
    comparable = table.dropna(subset=["fdr_family", "fdr_global"])
    text = text.replace("{n_rows}", f"{len(comparable)}").replace(
        "{n_gl}", f"{int((comparable['fdr_global'] < comparable['fdr_family']).sum())}")
    lines = text.split("\n")
    acc = pd.read_csv(RES / "FINAL_cohort_accounting.csv")
    lines += ["## 队列人数（用于统一 51 vs 57 争议）", "", "| cohort | group | libraries | participants |",
              "|---|---|---:|---:|"]
    for _, row in acc.iterrows():
        lines.append(f"| {row['cohort']} | {row['group']} | {row['libraries']} | {row['participants']} |")
    (REPORTS / "FINAL_NUMBERS.md").write_text("\n".join(lines) + "\n")
    print("wrote reports/FINAL_NUMBERS.md")
    print(acc.to_string(index=False))


if __name__ == "__main__":
    main()
