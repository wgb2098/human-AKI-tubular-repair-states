#!/usr/bin/env python3
"""KPMP Visium spatial pilot: signature scores, spatial maps and Moran's I.

Reads expression matrices and tissue coordinates directly from the downloaded
zip archives.
"""

from __future__ import annotations

import gzip
import io
import json
import re
import zipfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmread
from scipy.spatial import cKDTree
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
SPATIAL = ROOT / "data/KPMP_spatial"
META = ROOT / "metadata"
RES = ROOT / "results"
FIG = ROOT / "figures"
SIGS = RES / "Klocke_signature_genes.csv"
CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]
SIGNATURES = ["injury_stress", "repair_progenitor", "cycling", "reference_PT"]
LABELS = {
    "injury_stress": "Injury / stress",
    "repair_progenitor": "Repair / progenitor",
    "cycling": "Cycling",
    "reference_PT": "Reference PT",
}
MARKERS = {
    "marker_PT": ["SLC34A1", "SLC22A6", "LRP2", "CUBN", "HNF4A", "GPX3"],
    "marker_TAL": ["UMOD", "SLC12A1", "KCNJ1", "CLDN16", "CASR"],
    "marker_immune": ["PTPRC", "CD14", "LYZ", "FCGR3A", "TYROBP", "AIF1"],
    "marker_fibroblast": ["COL1A1", "COL1A2", "COL3A1", "DCN", "PDGFRA"],
    "marker_endothelial": ["PECAM1", "VWF", "EMCN", "KDR", "CDH5"],
}


def load_signatures() -> dict[str, list[str]]:
    sets = pd.read_csv(SIGS)
    signatures = {name: list(g["gene"].astype(str)) for name, g in sets.groupby("signature")}
    signatures["cycling"] = CYCLING
    return signatures


def find_entry(zf: zipfile.ZipFile, keyword: str, suffix: str | None = None) -> str | None:
    candidates = [n for n in zf.namelist() if keyword in n.lower()]
    if suffix:
        candidates = [n for n in candidates if n.lower().endswith(suffix)]
    return candidates[0] if candidates else None


def read_zip_gz(zf: zipfile.ZipFile, name: str) -> bytes:
    with zf.open(name) as handle:
        data = handle.read()
    return gzip.decompress(data) if name.lower().endswith(".gz") else data


def read_visium(expr_zip: Path) -> tuple[list[str], list[str], sparse.csr_matrix]:
    with zipfile.ZipFile(expr_zip) as zf:
        matrix_name = find_entry(zf, "matrix", ".mtx") or find_entry(zf, "matrix", ".mtx.gz")
        barcode_name = find_entry(zf, "barcode", ".tsv.gz") or find_entry(zf, "barcode", ".tsv")
        feature_name = find_entry(zf, "feature", ".tsv.gz") or find_entry(zf, "feature", ".tsv")
        if not (matrix_name and barcode_name and feature_name):
            raise FileNotFoundError(f"10x files not found in {expr_zip.name}: {zf.namelist()}")
        matrix = mmread(io.BytesIO(read_zip_gz(zf, matrix_name))).tocsr()
        barcodes = read_zip_gz(zf, barcode_name).decode(errors="replace").split()
        features = pd.read_csv(io.BytesIO(read_zip_gz(zf, feature_name)), sep="\t", header=None)
    genes = features.iloc[:, 1].astype(str) if features.shape[1] > 1 else features.iloc[:, 0].astype(str)
    return list(genes), barcodes, matrix


def read_positions(spatial_archive: Path) -> pd.DataFrame:
    """Read tissue positions from either a zip or a tar.gz spatial bundle."""
    text = None
    if spatial_archive.suffix.lower() == ".zip":
        with zipfile.ZipFile(spatial_archive) as zf:
            name = find_entry(zf, "tissue_positions", ".csv")
            if name is None:
                raise FileNotFoundError(f"tissue positions not found in {spatial_archive.name}: {zf.namelist()}")
            text = read_zip_gz(zf, name).decode(errors="replace")
    else:
        import tarfile
        with tarfile.open(spatial_archive, "r:gz") as tar:
            member = next((m for m in tar.getmembers()
                           if "tissue_positions" in m.name.lower() and m.name.lower().endswith(".csv")), None)
            if member is None:
                raise FileNotFoundError(f"tissue positions not found in {spatial_archive.name}")
            handle = tar.extractfile(member)
            text = gzip.decompress(handle.read()).decode(errors="replace") if member.name.endswith(".gz") \
                else handle.read().decode(errors="replace")
    pos = pd.read_csv(io.StringIO(text))
    cols = [c.lower() for c in pos.columns]
    if "barcode" not in cols:
        pos = pd.read_csv(io.StringIO(text), header=None)
        pos.columns = ["barcode", "in_tissue", "array_row", "array_col", "pxl_row", "pxl_col"][: pos.shape[1]]
    else:
        rename = {}
        for c in pos.columns:
            lc = c.lower()
            if "barcode" in lc: rename[c] = "barcode"
            elif lc in ("in_tissue", "in tissue"): rename[c] = "in_tissue"
            elif "array_row" in lc or lc == "row": rename[c] = "array_row"
            elif "array_col" in lc or lc == "col": rename[c] = "array_col"
            elif "pxl_row" in lc or "pixel_row" in lc or lc == "y": rename[c] = "pxl_row"
            elif "pxl_col" in lc or "pixel_col" in lc or lc == "x": rename[c] = "pxl_col"
        pos = pos.rename(columns=rename)
    if not {"barcode", "pxl_row", "pxl_col"}.issubset(pos.columns):
        raise ValueError(f"unrecognized position columns: {list(pos.columns)}")
    if "in_tissue" in pos.columns:
        pos = pos[pd.to_numeric(pos["in_tissue"], errors="coerce") == 1]
    return pos


def moran_i(coords: np.ndarray, values: np.ndarray, k: int = 6) -> float:
    if len(coords) <= k + 1:
        return np.nan
    tree = cKDTree(coords)
    _, idx = tree.query(coords, k=k + 1)
    neigh = idx[:, 1:]
    n = len(values)
    z = values - values.mean()
    denom = np.sum(z ** 2)
    if denom == 0:
        return np.nan
    w = n / (n * k)
    num = 0.0
    for i in range(n):
        num += np.sum(z[neigh[i]] * z[i])
    return w * num / denom


def main() -> None:
    pilot = json.loads((META / "kpmp_spatial_pilot_files.json").read_text())
    signatures = load_signatures()
    per_spot = []
    sample_rows = []

    for patient, stage in pilot["pilot"].items():
        files = [f for f in pilot["files"] if f["patient"] == patient]
        expr_zip = next((SPATIAL / patient / f["file_name"] for f in files if "Expression Matrix" in str(f["workflow_type"])), None)
        spatial_zip = next((SPATIAL / patient / f["file_name"] for f in files if "Spatial Imaging Data" in str(f["workflow_type"])), None)
        if not expr_zip or not expr_zip.exists() or not spatial_zip or not spatial_zip.exists():
            print(f"skip {patient}: missing expression or spatial zip")
            continue
        try:
            genes, barcodes, matrix = read_visium(expr_zip)
            positions = read_positions(spatial_zip)
        except Exception as exc:
            print(f"skip {patient}: {exc}")
            continue

        lib = np.asarray(matrix.sum(axis=0)).ravel()
        scale = 1e6 / np.maximum(lib, 1)
        logcpm = matrix.multiply(scale).tocsr()
        logcpm.data = np.log2(logcpm.data + 1)
        gene_index = {g: i for i, g in enumerate(genes)}
        keep_barcodes = [b for b in positions["barcode"] if b in set(barcodes)]
        if len(keep_barcodes) < 50:
            print(f"skip {patient}: only {len(keep_barcodes)} matched barcodes")
            continue
        bc_index = {b: i for i, b in enumerate(barcodes)}
        cols = [bc_index[b] for b in keep_barcodes]
        pos = positions.set_index("barcode").loc[keep_barcodes]

        scores = {}
        for sig in SIGNATURES:
            present = [gene_index[g] for g in signatures[sig] if g in gene_index]
            if len(present) < 8:
                scores[sig] = np.full(len(cols), np.nan)
                continue
            sub = logcpm[present][:, cols]
            scores[sig] = np.asarray(sub.mean(axis=0)).ravel()

        coords = pos[["pxl_row", "pxl_col"]].to_numpy(dtype=float)
        marker_scores = {}
        for name, genes in MARKERS.items():
            present = [gene_index[g] for g in genes if g in gene_index]
            marker_scores[name] = (np.asarray(logcpm[present][:, cols].mean(axis=0)).ravel()
                                   if len(present) >= 3 else np.full(len(cols), np.nan))
        for j, b in enumerate(keep_barcodes):
            row = {"patient": patient, "stage": stage, "barcode": b,
                   "pxl_row": coords[j, 0], "pxl_col": coords[j, 1]}
            row.update({sig: scores[sig][j] for sig in SIGNATURES})
            row.update({name: marker_scores[name][j] for name in MARKERS})
            per_spot.append(row)

        sample_row = {"patient": patient, "stage": stage, "n_spots": len(keep_barcodes)}
        for sig in SIGNATURES:
            vals = scores[sig]
            z = (vals - np.nanmean(vals)) / (np.nanstd(vals) if np.nanstd(vals) else 1)
            sample_row[f"mean_{sig}"] = float(np.nanmean(vals))
            sample_row[f"moran_{sig}"] = moran_i(coords, z)
        sample_rows.append(sample_row)
        print(f"{patient} ({stage}): {len(keep_barcodes)} spots, signatures scored")

    spot_df = pd.DataFrame(per_spot)
    sample_df = pd.DataFrame(sample_rows)
    spot_df.to_csv(RES / "spatial_pilot_spot_scores.csv.gz", index=False, compression="gzip")
    sample_df.to_csv(RES / "spatial_pilot_sample_scores.csv", index=False)
    print("\nSample-level scores:")
    print(sample_df.to_string(index=False))

    # Spot-level co-localization between repair/injury signatures and cell-type markers
    coloc_rows = []
    for patient, group in spot_df.groupby("patient"):
        for sig in ["injury_stress", "repair_progenitor", "cycling", "reference_PT"]:
            for marker in MARKERS:
                rho, p = stats.spearmanr(group[sig], group[marker], nan_policy="omit")
                coloc_rows.append({"patient": patient, "stage": group["stage"].iloc[0],
                                   "signature": sig, "marker": marker, "rho": rho, "p": p})
    coloc = pd.DataFrame(coloc_rows)
    coloc.to_csv(RES / "spatial_pilot_colocalization.csv", index=False)
    print("\nSpot-level co-localization (median rho across samples):")
    print(coloc.groupby(["signature", "marker"])["rho"].median().unstack().round(3).to_string())

    # Stage trend across all downloaded sections
    stage_num = pd.to_numeric(sample_df["stage"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
    trend_rows = []
    for sig in SIGNATURES:
        col = f"mean_{sig}"
        if col in sample_df:
            rho, p = stats.spearmanr(stage_num, sample_df[col], nan_policy="omit")
            trend_rows.append({"signature": sig, "n_samples": len(sample_df),
                               "rho_stage": rho, "p_stage": p})
    pd.DataFrame(trend_rows).to_csv(RES / "spatial_pilot_stage_trend.csv", index=False)
    print(f"\nSpatial stage trend (n={len(sample_df)} sections):")
    print(pd.DataFrame(trend_rows).to_string(index=False))

    # Spatial maps: rows = patients, cols = signatures.
    # A 16-row grid is unreadable; keep the two largest sections per stage.
    map_patients = (sample_df.sort_values("n_spots", ascending=False)
                    .groupby("stage", group_keys=False).head(2)["patient"].tolist())
    patients = map_patients if map_patients else sample_df["patient"].tolist()
    if patients:
        fig, axes = plt.subplots(len(patients), len(SIGNATURES),
                                 figsize=(3.0 * len(SIGNATURES), 2.7 * len(patients)),
                                 squeeze=False)
        for i, patient in enumerate(patients):
            sub = spot_df[spot_df["patient"] == patient]
            for j, sig in enumerate(SIGNATURES):
                ax = axes[i, j]
                sc = ax.scatter(sub["pxl_col"], -sub["pxl_row"], c=sub[sig], s=2, cmap="RdBu_r",
                                vmin=np.nanpercentile(sub[sig], 5), vmax=np.nanpercentile(sub[sig], 95))
                ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
                if i == 0:
                    ax.set_title(LABELS[sig], fontsize=9)
                if j == 0:
                    ax.set_ylabel(f"{patient}\n{sub['stage'].iloc[0]}", fontsize=8)
                plt.colorbar(sc, ax=ax, fraction=0.046, pad=0.02)
        fig.suptitle("KPMP Visium pilot: spatial distribution of injury/repair signatures", y=1.0)
        fig.tight_layout()
        fig.savefig(FIG / "Fig_spatial_pilot_signatures.png", dpi=250, bbox_inches="tight")
        fig.savefig(FIG / "Fig_spatial_pilot_signatures.pdf", bbox_inches="tight")
        plt.close(fig)
        print("saved figures/Fig_spatial_pilot_signatures.png/.pdf")

    # Cross-modal check against single-cell pseudobulk for the same patients.
    # Prefer the PT-level table (composition-adjusted); fall back to whole-library.
    pt_table = RES / "KPMP_sc_PT_pseudobulk_patient.csv"
    if pt_table.exists():
        sc_df = pd.read_csv(pt_table)[["participant"] + SIGNATURES].rename(
            columns={"participant": "patient"})
        source = "PT pseudobulk"
    else:
        sc = pd.read_csv(RES / "KPMP_sc_pseudobulk_signatures.csv")
        sc["stage_num"] = pd.to_numeric(sc["stage"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
        sc_rows = []
        for participant, group in sc.dropna(subset=["stage_num"]).groupby("participant"):
            w = group["n_cells"].astype(float)
            row = {"patient": participant}
            for sig in SIGNATURES:
                col = f"{sig}_score"
                if col in group:
                    vals = pd.to_numeric(group[col], errors="coerce")
                    row[sig] = np.average(vals[vals.notna()], weights=w[vals.notna()]) if vals.notna().any() else np.nan
            sc_rows.append(row)
        sc_df = pd.DataFrame(sc_rows)
        source = "whole-library pseudobulk"
    merged = sample_df.merge(sc_df, on="patient", suffixes=("_spatial", "_sc"))
    if len(merged) >= 3:
        print(f"\nCross-modal correlation (spatial mean vs {source}, n=%d):" % len(merged))
        for sig in SIGNATURES:
            if f"mean_{sig}" in merged and sig in merged:
                rho, p = stats.spearmanr(merged[f"mean_{sig}"], merged[sig], nan_policy="omit")
                print(f"  {sig:20s} rho={rho:+.3f} p={p:.3f}")
        merged.to_csv(RES / "spatial_vs_sc_pilot.csv", index=False)


if __name__ == "__main__":
    main()
