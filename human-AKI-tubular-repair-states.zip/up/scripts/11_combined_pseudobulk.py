#!/usr/bin/env python3
"""Gene-level pseudobulk comparison of KPMP AKI vs Healthy Reference samples."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
FIG = ROOT / "figures"

# Load helpers from script 09.
spec = importlib.util.spec_from_file_location("pb", ROOT / "scripts/09_kpmp_pseudobulk.py")
pb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pb)

SIGNATURES = ["cycling", "injury_stress", "repair_progenitor", "reference_PT"]
LABELS = {
    "cycling": "Cycling",
    "injury_stress": "Injury / stress",
    "repair_progenitor": "Repair / progenitor",
    "reference_PT": "Reference PT",
}


def locate(directory: Path, file_id: str) -> Path | None:
    matches = sorted(directory.glob(f"{file_id}*.zip"))
    matches = [m for m in matches if m.name not in ("ref.zip", "ref2.zip")]
    return min(matches, key=lambda p: len(p.name)) if matches else None


def collect_samples() -> list[dict]:
    samples = []
    manifest = pd.read_csv(ROOT / "metadata/KPMP_open_AKI_single_sample_matrices.csv")
    manifest = manifest[manifest["experimental_strategy"].str.contains("Single-cell RNA-Seq", na=False)]
    for _, row in manifest.iterrows():
        path = locate(ROOT / "data/KPMP/sc", row["file_id"])
        if path:
            samples.append({
                "group": "AKI", "file_id": row["file_id"], "path": path,
                "participant": row["participants"], "stage": row["KDIGO Stage"],
            })
    ref_meta = json.loads((ROOT / "metadata/kpmp_reference_sc_files.json").read_text())["rows"]
    for row in ref_meta:
        path = locate(ROOT / "data/KPMP/ref", row["file_id"])
        if path:
            samples.append({
                "group": "Reference", "file_id": row["file_id"], "path": path,
                "participant": "/".join(row.get("redcap_id") or []), "stage": None,
            })
    return samples


def main() -> None:
    signatures = pb.load_signatures()
    signatures["cycling"] = pb.CYCLING
    samples = collect_samples()
    print(f"samples with matrices: {len(samples)} (AKI {sum(s['group']=='AKI' for s in samples)}, "
          f"Reference {sum(s['group']=='Reference' for s in samples)})")

    rows = []
    for i, sample in enumerate(samples, 1):
        try:
            genes, matrix, n_cells = pb.read_zip(sample["path"])
            bulk = pb.pseudobulk(genes, matrix)
        except Exception as exc:
            print(f"skip {sample['path'].name}: {exc}")
            continue
        record = {k: v for k, v in sample.items() if k != "path"}
        record.update({"n_cells": n_cells, "n_genes": len(bulk)})
        for name, gene_list in signatures.items():
            present = [g for g in gene_list if g in bulk.index]
            record[f"{name}_score"] = bulk.loc[present].mean() if len(present) >= 8 else np.nan
            record[f"{name}_n_genes"] = len(present)
        rows.append(record)
        if i % 20 == 0:
            print(f"processed {i}/{len(samples)}")

    table = pd.DataFrame(rows)
    table.to_csv(RES / "KPMP_combined_pseudobulk_signatures.csv", index=False)

    stats_rows = []
    for name in SIGNATURES:
        col = f"{name}_score"
        aki = table.loc[table["group"] == "AKI", col].dropna()
        ref = table.loc[table["group"] == "Reference", col].dropna()
        if len(aki) < 3 or len(ref) < 3:
            continue
        u = stats.mannwhitneyu(aki, ref, alternative="greater")
        auc = u.statistic / (len(aki) * len(ref))
        stats_rows.append({
            "signature": name, "n_AKI": len(aki), "n_Reference": len(ref),
            "mean_AKI": aki.mean(), "mean_Reference": ref.mean(),
            "median_AKI": aki.median(), "median_Reference": ref.median(),
            "mannwhitney_p_greater": u.pvalue, "auc_AKI_vs_Reference": auc,
        })
    stats_table = pd.DataFrame(stats_rows)
    if not stats_table.empty:
        from statsmodels.stats.multitest import multipletests
        stats_table["fdr"] = multipletests(stats_table["mannwhitney_p_greater"], method="fdr_bh")[1]
    stats_table.to_csv(RES / "KPMP_pseudobulk_AKI_vs_Ref_stats.csv", index=False)

    # Stage trend within AKI
    stage_num = pd.to_numeric(table["stage"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
    aki_mask = table["group"] == "AKI"
    trend_rows = []
    for name in SIGNATURES:
        col = f"{name}_score"
        x, y = stage_num[aki_mask], table.loc[aki_mask, col]
        valid = x.notna() & y.notna()
        if valid.sum() >= 5:
            rho, p = stats.spearmanr(x[valid], y[valid])
            trend_rows.append({"signature": name, "n_staged_AKI": int(valid.sum()), "rho_stage": rho, "p_stage": p})
    pd.DataFrame(trend_rows).to_csv(RES / "KPMP_pseudobulk_stage_trends.csv", index=False)

    # Figure
    fig, axes = plt.subplots(1, 4, figsize=(13, 3.6))
    for ax, name in zip(axes, SIGNATURES):
        col = f"{name}_score"
        data = [table.loc[table["group"] == "AKI", col].dropna(),
                table.loc[table["group"] == "Reference", col].dropna()]
        ax.boxplot(data, labels=["AKI", "Reference"], widths=0.6, patch_artist=True,
                   boxprops=dict(facecolor="#AED6F1"), medianprops=dict(color="black"))
        for pos, vals, color in [(1, data[0], "#C0392B"), (2, data[1], "#2874A6")]:
            ax.scatter(np.ones(len(vals)) * pos + np.random.uniform(-0.08, 0.08, len(vals)),
                       vals, s=8, color=color, alpha=0.6)
        row = stats_table[stats_table["signature"] == name]
        title = LABELS[name]
        if not row.empty:
            title += f"\nAUC={row.iloc[0]['auc_AKI_vs_Reference']:.2f}, p={row.iloc[0]['mannwhitney_p_greater']:.3g}"
        ax.set_title(title, fontsize=9)
        ax.set_ylabel("Pseudobulk score (mean log2 CPM)")
    fig.suptitle("Gene-level pseudobulk signatures: KPMP AKI vs Healthy Reference", y=1.04)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_pseudobulk_AKI_vs_Ref.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_pseudobulk_AKI_vs_Ref.pdf", bbox_inches="tight")
    plt.close(fig)

    print("\nAKI vs Reference:")
    print(stats_table.to_string(index=False))
    print("\nStage trends within AKI:")
    print(pd.DataFrame(trend_rows).to_string(index=False))


if __name__ == "__main__":
    main()
