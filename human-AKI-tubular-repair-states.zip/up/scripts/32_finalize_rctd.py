#!/usr/bin/env python3
"""Wait for the four RCTD batches, then run the downstream steps and finalise.

Steps: poll for completion of the batch processes -> run 30_rctd_downstream.py ->
write reports/RCTD_RESULTS.md -> refresh file checksums.
"""

from __future__ import annotations

import hashlib
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RESULTS = ROOT / "results"
REPORTS = ROOT / "reports"
EXPECTED = 16
POLL_SECONDS = 120
MAX_HOURS = 8


def running_batches() -> int:
    result = subprocess.run(["pgrep", "-f", "scripts/21c_rctd_visium.R --args"],
                            capture_output=True, text=True)
    return len([line for line in result.stdout.split() if line.strip()])


def counts() -> int:
    return len(list(RESULTS.glob("rctd_weights_*.csv")))


def wait_for_rctd() -> None:
    started = time.time()
    while True:
        active, done = running_batches(), counts()
        print(f"[{time.strftime('%H:%M:%S')}] rctd weights files: {done}/{EXPECTED}, "
              f"active batch processes: {active}", flush=True)
        if done >= EXPECTED or (active == 0 and done > 0):
            if active == 0:
                print("all RCTD batches finished", flush=True)
                return
        if time.time() - started > MAX_HOURS * 3600:
            print("timeout waiting for RCTD", flush=True)
            return
        time.sleep(POLL_SECONDS)


def run(script: str) -> None:
    print(f"running {script}", flush=True)
    subprocess.run([sys.executable, "-I", str(ROOT / script)], cwd=ROOT, check=False)


def write_rctd_report() -> None:
    import pandas as pd

    samples = pd.read_csv(RESULTS / "spatial_rctd_sample_table.csv")
    trend = pd.read_csv(RESULTS / "spatial_rctd_stage_trends.csv")
    spot_corr = pd.read_csv(RESULTS / "spatial_rctd_spot_correlations.csv")

    lines = ["# RCTD 解卷积结果（自动生成）", "",
             "参考：GSE210622，9,185 细胞 × 12 细胞类型（对照 + 非 COVID AKI + COVID AKI）。",
             "RCTD full 模式会丢弃 UMI < 100 的 spot，因此每例参与解卷积的 spot 数少于导出 spot 数。", "",
             "**解释注意**：参考来自另一平台（snRNA-seq 的 GSE210622）而空间数据为 KPMP Visium，",
             "跨平台参考不保证比例定标，因此 compartment 比例按**相对值**解释（例：免疫比例最高的样本是 AIN 病理的 30-11080）；",
             "各 compartment 之和可能小于 1（低质量 spot 的权重不足 1）。可用的内部一致性检验是通过的：",
             "reference-PT 签名与解卷积得到的 PT 比例在 spot 水平高度相关。", "",
             "## 每例组成与签名均值", "",
             "| 患者 | 分期 | 解卷积 spot | 丢弃 spot | PT | TAL | 远端小管 | 内皮 | 免疫 | 足细胞 | injury | repair | cycling | reference |",
             "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for _, r in samples.sort_values(["stage_num", "patient"]).iterrows():
        lines.append(
            f"| {r['patient']} | {r['stage']} | {int(r['n_spots'])} | {int(r['n_spots_dropped_low_umi'])} | "
            f"{r['frac_PT']:.3f} | {r['frac_TAL']:.3f} | {r['frac_distal']:.3f} | {r['frac_endothelium']:.3f} | "
            f"{r['frac_immune']:.3f} | {r['frac_podocyte']:.3f} | {r['score_injury_stress']:+.3f} | "
            f"{r['score_repair_progenitor']:+.3f} | {r['score_cycling']:+.3f} | {r['score_reference_PT']:+.3f} |")

    lines += ["", "## spot 水平：签名与细胞组成的相关（Spearman rho）", ""]
    pivot = spot_corr.pivot(index="score", columns="compartment", values="rho")
    lines.append("| 签名 | " + " | ".join(pivot.columns) + " |")
    lines.append("|---" * (len(pivot.columns) + 1) + "|")
    for score, row in pivot.iterrows():
        lines.append(f"| {score} | " + " | ".join(f"{v:+.3f}" for v in row) + " |")

    lines += ["", "## 分期趋势（样本水平，Spearman）", ""]
    if len(trend):
        from statsmodels.stats.multitest import multipletests
        fdr = multipletests(trend["p"].clip(lower=1e-300), method="fdr_bh")[1]
        trend = trend.assign(fdr=fdr)
        lines += ["| 特征 | rho | p | FDR | n |", "|---|---:|---:|---:|---:|"]
        for _, r in trend.iterrows():
            lines.append(f"| {r['feature']} | {r['rho']:+.3f} | {r['p']:.4f} | {r['fdr']:.3f} | {int(r['n'])} |")
        sig = trend[trend["fdr"] < 0.05]
        if len(sig):
            lines += ["", "通过 BH FDR<0.05 的趋势：" + "；".join(
                f"{r['feature']}（rho={r['rho']:+.3f}, FDR={r['fdr']:.3f}）" for _, r in sig.iterrows())]
        else:
            best = trend.iloc[0]
            lines += ["", f"无特征通过 BH FDR<0.05；最接近的是 {best['feature']}"
                          f"（rho={best['rho']:+.3f}, FDR={best['fdr']:.3f}）。"
                          "样本量 16、病理类型混杂，该结果只作描述。"]
    else:
        lines.append("样本量不足，未做检验。")

    (REPORTS / "RCTD_RESULTS.md").write_text("\n".join(lines) + "\n")
    print("wrote reports/RCTD_RESULTS.md", flush=True)


def refresh_checksums() -> None:
    targets = []
    for folder in ("results", "figures", "reports", "scripts", "metadata"):
        for path in sorted((ROOT / folder).rglob("*")):
            if path.is_file():
                targets.append(path)
    out = REPORTS / "file_checksums.sha256"
    lines = []
    for path in targets:
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b""):
                digest.update(chunk)
        lines.append(f"{digest.hexdigest()}  {path.relative_to(ROOT)}")
    out.write_text("\n".join(lines) + "\n")
    print(f"updated {out} ({len(lines)} files)", flush=True)


def main() -> None:
    wait_for_rctd()
    run("scripts/30_rctd_downstream.py")
    write_rctd_report()
    refresh_checksums()
    print("finalisation complete", flush=True)


if __name__ == "__main__":
    main()
