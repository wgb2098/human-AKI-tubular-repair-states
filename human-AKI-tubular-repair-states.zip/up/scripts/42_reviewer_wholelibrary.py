#!/usr/bin/env python3
"""Whole-library pseudobulk for the annotated patient subset, and its adjustment for PT content.

The published whole-library comparison used every library of the KPMP repository,
including many without cell-level annotation. Here we recompute whole-library
scores for the subset that does have annotations (12 AKI + 18 reference
patients), so the same subset supports both the whole-library view and the
PT-only view, and the effect of adjusting for the annotated PT fraction can be
quantified directly.
"""

from __future__ import annotations

import gzip
import io
import re
import zipfile
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
META = ROOT / "metadata"
CELL_META = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"

CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]
SIGNATURES = ["injury_stress", "repair_progenitor", "cycling", "reference_PT"]
G = {}


def worker(job: tuple[str, str, str, str]) -> dict | None:
    file_id, participant, directory, group = job
    matches = sorted(ROOT.glob(f"{directory}/{file_id}*.zip"))
    if not matches:
        return None
    path = matches[0]
    cells = G["cells"].get(participant)
    if not cells:
        return None
    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()

            def read(name: str) -> bytes:
                with zf.open(name) as handle:
                    data = handle.read()
                return gzip.decompress(data) if name.endswith(".gz") else data

            matrix_name = next(n for n in names if "matrix" in n.lower() and ".mtx" in n.lower())
            feature_name = next(n for n in names if "features" in n.lower() or "genes" in n.lower())
            barcode_name = next(n for n in names if "barcode" in n.lower())
            whitelist = read(barcode_name).decode(errors="replace").split()
            body = read(matrix_name).split(b"\n", 3)[3]
            features = pd.read_csv(io.BytesIO(read(feature_name)), sep="\t", header=None)
        genes = (features.iloc[:, 1].astype(str).tolist() if features.shape[1] > 1
                 else features.iloc[:, 0].astype(str).tolist())
        genes = [re.sub(r"^[A-Za-z0-9]+_{4}", "", g) for g in genes]
        index = {b: i + 1 for i, b in enumerate(whitelist)}
        positions = {index[b] for b in cells if b in index}
        if len(positions) < 50:
            return {"file_id": file_id, "participant": participant,
                    "error": f"only {len(positions)} annotated barcodes matched of {len(cells)}"}
        df = pd.read_csv(io.BytesIO(body), sep=" ", header=None, names=["g", "c", "v"],
                         dtype={"g": np.int32, "c": np.int32, "v": np.float32}, engine="c")
        df = df[df["c"].isin(positions)]
        counts = np.bincount(df["g"].to_numpy() - 1, weights=df["v"].to_numpy(), minlength=len(genes))
    except Exception as exc:
        return {"file_id": file_id, "participant": participant, "error": str(exc)}
    lib = counts.sum()
    if lib <= 0:
        return None
    logcpm = np.log2(counts / lib * 1e6 + 1)
    series = pd.Series(logcpm, index=genes)
    series = series[~series.index.duplicated(keep="first")]
    z = (series - series.mean()) / (series.std() if series.std() else 1)
    row = {"file_id": file_id, "participant": participant, "group": group,
           "n_cells": len(positions), "UMI": int(lib)}
    for signature in SIGNATURES:
        present = [g for g in G["signatures"][signature] if g in z.index]
        row[f"{signature}_score"] = z.loc[present].mean() if len(present) >= 8 else np.nan
    return row


def main() -> None:
    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    meta = meta[meta["condition.l2"].isin(["AKI", "Ref"])].copy()
    meta["barcode"] = meta.index.str.split("_", n=1).str[1]
    cells = {str(p): set(g["barcode"]) for p, g in meta.groupby("patient")}
    pt_fraction = (meta.assign(is_pt=meta["subclass.l1"] == "PT").groupby("patient")["is_pt"].mean()
                   .rename("pt_fraction").to_dict())
    print("annotated patients:", len(cells))

    signatures = {name: list(g["gene"].astype(str))
                  for name, g in pd.read_csv(RES / "Klocke_signature_genes.csv").groupby("signature")}
    signatures["cycling"] = CYCLING
    G.update({"cells": cells, "signatures": signatures})

    jobs = []
    aki = pd.read_csv(META / "KPMP_open_AKI_single_sample_matrices.csv")
    aki = aki[aki["experimental_strategy"].str.contains("Single-cell RNA-Seq", na=False)]
    for _, row in aki.iterrows():
        if str(row["participants"]) in cells:
            jobs.append((str(row["file_id"]), str(row["participants"]), "data/KPMP/sc", "AKI"))
    ref = pd.read_csv(META / "KPMP_open_Ref_single_sample_matrices.csv")
    for _, row in ref.iterrows():
        if str(row["participants"]) in cells:
            jobs.append((str(row["file_id"]), str(row["participants"]), "data/KPMP/sc_ref", "Ref"))
    print("jobs:", len(jobs))

    with Pool(6) as pool:
        rows = [r for r in pool.map(worker, jobs) if r]
    table = pd.DataFrame(rows)
    if "error" in table.columns:
        bad = table[table["error"].notna()]
        if len(bad):
            print("errors:\n", bad[["participant", "error"]].to_string(index=False))
        table = table[table["error"].isna()].drop(columns=["error"])
    table["pt_fraction"] = table["participant"].map(pt_fraction)
    table.to_csv(RES / "reviewer_wholelibrary_annotated_subset.csv", index=False)

    patient = (table.groupby(["group", "participant"], as_index=False)
               .agg({f"{s}_score": "median" for s in SIGNATURES} | {"pt_fraction": "first"}))
    print(f"\nlibraries: {len(table)}, patients: {len(patient)} "
          f"({patient['group'].value_counts().to_dict()})")

    print("\nLibrary-level: whole-library scores vs annotated PT fraction")
    for signature in SIGNATURES:
        rho, p = stats.spearmanr(table[f"{signature}_score"], table["pt_fraction"], nan_policy="omit")
        print(f"  {signature:20s} rho={rho:+.3f} p={p:.2e}")

    print("\nPatient level, whole-library scores: PT-fraction-adjusted group effect")
    rows = []
    for signature in SIGNATURES:
        subset = patient[["group", "pt_fraction", f"{signature}_score"]].dropna()
        subset["rank_score"] = subset[f"{signature}_score"].rank(pct=True)
        plain = sm.add_constant(pd.DataFrame({"group_AKI": (subset["group"] == "AKI").astype(float)}))
        model_plain = sm.OLS(subset["rank_score"], plain).fit(cov_type="HC3")
        design = sm.add_constant(pd.DataFrame({
            "group_AKI": (subset["group"] == "AKI").astype(float),
            "pt_fraction": subset["pt_fraction"].astype(float)}))
        model_adj = sm.OLS(subset["rank_score"], design).fit(cov_type="HC3")
        rows.append({
            "signature": signature, "n_AKI": int((subset["group"] == "AKI").sum()),
            "n_Ref": int((subset["group"] == "Ref").sum()),
            "median_AKI": subset.loc[subset["group"] == "AKI", f"{signature}_score"].median(),
            "median_Ref": subset.loc[subset["group"] == "Ref", f"{signature}_score"].median(),
            "p_unadjusted": model_plain.pvalues["group_AKI"],
            "p_adjusted_PTfraction": model_adj.pvalues["group_AKI"],
        })
    adjusted = pd.DataFrame(rows)
    from statsmodels.stats.multitest import multipletests
    adjusted["fdr_unadjusted"] = multipletests(adjusted["p_unadjusted"], method="fdr_bh")[1]
    adjusted["fdr_adjusted"] = multipletests(adjusted["p_adjusted_PTfraction"], method="fdr_bh")[1]
    adjusted.to_csv(RES / "reviewer_wholelibrary_annotated_tests.csv", index=False)
    print(adjusted.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
