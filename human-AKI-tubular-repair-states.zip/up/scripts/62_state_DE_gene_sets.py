#!/usr/bin/env python3
"""Gene-set level tests on the state-specific DE tables.

Competitive test (Wilcoxon rank-sum of the set's logFC against all other genes)
for each PT state and contrast, using the Klocke signatures plus curated
proliferation / fibrosis / inflammation / metabolism / senescence sets.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
STATE_DIR = ROOT / "data/state_pseudobulk"
REPORTS = ROOT / "reports"

CYCLING_12 = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20",
              "TPX2", "CENPF", "CCNA2", "AURKB"]
CELL_CYCLE_BROAD = ["PCNA", "MCM2", "MCM3", "MCM4", "MCM5", "MCM6", "MCM7", "MCM10", "CDC6", "CDC45",
                    "CDT1", "ORC1", "ORC6", "GINS1", "GINS2", "TIPIN", "RPA1", "RPA2", "RPA3", "RFC3",
                    "RFC4", "RFC5", "POLA1", "POLA2", "POLD1", "POLD2", "POLD3", "POLE", "POLE2",
                    "FEN1", "LIG1", "RRM1", "RRM2", "TYMS", "DTYMK", "TK1", "GMNN", "E2F1", "SLBP",
                    "UHRF1", "HELLS", "WDHD1", "CHAF1A", "CHAF1B", "ASF1B", "MYBL2",
                    "CDK1", "CCNB1", "CCNB2", "CENPA", "CENPE", "CENPF", "BUB1", "BUB1B", "AURKA",
                    "AURKB", "PLK1", "TOP2A", "MKI67", "NDC80", "NUF2", "SPC24", "SPC25", "KIF11",
                    "KIF23", "KIF2C", "KIF15", "ANLN", "PRC1", "NUSAP1", "TACC3", "TPX2", "UBE2C",
                    "UBE2S", "CKS1B", "CKS2", "PTTG1", "BIRC5", "CCNA2", "NEK2", "TTK", "ESCO2",
                    "RAD21", "SMC4", "CCNF", "CEP55", "ECT2", "RACGAP1", "KIF20A", "DLGAP5", "ASPM",
                    "CIT", "INCENP", "CDCA8"]
FIBROSIS_ECM = ["COL1A1", "COL1A2", "COL3A1", "COL4A1", "COL4A2", "COL5A1", "COL6A1", "COL6A2",
                "COL6A3", "COL8A1", "FN1", "SPARC", "POSTN", "THBS1", "THBS2", "TIMP1", "TIMP3",
                "LOX", "LOXL1", "LOXL2", "SERPINE1", "FBN1", "ELN", "MMP2", "MMP14", "TGFB1",
                "TGFBR1", "TGFBR2", "ACTA2", "TAGLN", "VIM", "CDH2", "SNAI1", "SNAI2", "TWIST1",
                "ZEB1", "ZEB2", "ITGB1", "ITGB6", "INHBA"]
INFLAMMATION = ["CCL2", "CXCL1", "CXCL2", "CXCL8", "CXCL10", "CXCL12", "IL6", "IL1B", "TNF",
                "NFKB1", "NFKB2", "NFKBIA", "TNFAIP3", "SOCS3", "ICAM1", "VCAM1", "CX3CL1",
                "CCL20", "CCL5", "TNFSF10", "BIRC3", "RELB", "REL", "TRAF1"]
FAO_METABOLISM = ["CPT1A", "CPT2", "ACADM", "ACADVL", "HADHA", "HADHB", "PPARA", "PPARGC1A",
                  "ACOX1", "EHHADH", "ACAA2", "ETFA", "ETFB", "IDH2", "OGDH", "SDHA", "SDHB",
                  "CS", "ACO2", "MDH2"]
SENESCENCE = ["CDKN1A", "CDKN2A", "TP53", "GLB1", "SERPINE1", "IL6", "CXCL8", "IGFBP7", "GDF15"]
APOPTOSIS = ["BAX", "BAK1", "BID", "CASP3", "CASP7", "CASP8", "CASP9", "BCL2", "BCL2L1", "PMAIP1",
             "BBC3", "FAS", "TNFRSF10B", "DIABLO", "APAF1"]
HYPOXIA = ["VEGFA", "SLC2A1", "LDHA", "PGK1", "ENO1", "HK2", "BNIP3", "NDRG1", "ANKRD37",
           "P4HA1", "ADM", "HILPDA", "MIF", "DDIT4"]


def load_signatures() -> dict[str, list[str]]:
    sig = pd.read_csv(RES / "Klocke_signature_genes.csv")
    sets = {name: sorted(set(g["gene"].astype(str))) for name, g in sig.groupby("signature")}
    sets["cycling_12"] = CYCLING_12
    sets["cell_cycle_broad"] = sorted(set(CELL_CYCLE_BROAD))
    sets["fibrosis_ECM"] = FIBROSIS_ECM
    sets["inflammation_NFkB"] = INFLAMMATION
    sets["FAO_OXPHOS"] = FAO_METABOLISM
    sets["senescence"] = SENESCENCE
    sets["apoptosis"] = APOPTOSIS
    sets["hypoxia_targets"] = HYPOXIA
    return sets


def main() -> None:
    sets = load_signatures()
    rows = []
    for path in sorted(RES.glob("state_DE_*.csv")):
        if path.name == "state_DE_summary.csv":
            continue
        stem = path.stem.replace("state_DE_", "")
        state, contrast, model = None, None, "sex"
        for suffix_model, name_model in (("_sex_age", "sex_age"), ("_ageadj", "sex_age"), ("", "sex")):
            for candidate in ("AKI_vs_CKD", "AKI_vs_Ref", "CKD_vs_Ref"):
                tail = candidate + suffix_model
                if stem.endswith(tail):
                    state = stem[: -len(tail) - 1]
                    contrast, model = candidate, name_model
                    break
            if state:
                break
        if state not in {"adaptive__epi", "degenerative", "reference"}:
            continue
        de = pd.read_csv(path)
        de = de.dropna(subset=["logFC"])
        background = de["logFC"].to_numpy()
        for name, genes in sets.items():
            present = [g for g in genes if g in set(de["gene"])]
            if len(present) < 5:
                continue
            values = de.set_index("gene").loc[present, "logFC"].to_numpy()
            p = stats.mannwhitneyu(values, background, alternative="two-sided").pvalue
            rows.append({"state": state, "contrast": contrast, "model": model, "gene_set": name,
                         "n_genes_in_set": len(present),
                         "median_logFC_set": float(np.median(values)),
                         "mean_logFC_set": float(values.mean()),
                         "median_logFC_background": float(np.median(background)),
                         "p": p})
    table = pd.DataFrame(rows)
    table["fdr"] = np.nan
    for key, group in table.groupby(["state", "contrast", "model"] if "model" in table else ["state", "contrast"]):
        mask = (table["state"] == key[0]) & (table["contrast"] == key[1])
        table.loc[mask, "fdr"] = multipletests(table.loc[mask, "p"], method="fdr_bh")[1]
    table = table.sort_values(["state", "contrast", "p"])
    table.to_csv(RES / "state_DE_gene_set_tests.csv", index=False)

    pd.set_option("display.width", 200)
    for (state, contrast), group in table.groupby(["state", "contrast"]):
        print(f"\n=== {state} / {contrast} ===")
        show = group[group["p"] < 0.05]
        if len(show):
            print(show[["gene_set", "n_genes_in_set", "median_logFC_set", "p", "fdr"]].round(4).to_string(index=False))
        else:
            print("  无基因集显著（p<0.05）")

    # 重点：AKI vs CKD 对比（第 ① 项的正面回答）
    aki_ckd = table[(table["contrast"] == "AKI_vs_CKD")]
    print("\n=== 结论性检查：adaptive 状态 AKI vs CKD 是否存在协同位移 ===")
    for _, r in aki_ckd[aki_ckd.state == "adaptive__epi"].iterrows():
        print(f"  {r['gene_set']:22s} 中位 logFC {r['median_logFC_set']:+.3f}  p={r['p']:.3f}")
    aki_ckd.to_csv(RES / "state_DE_gene_set_tests_AKI_vs_CKD.csv", index=False)


if __name__ == "__main__":
    main()
