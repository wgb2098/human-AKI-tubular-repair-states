#!/usr/bin/env python3
"""Query the public KPMP Atlas repository for open clinical and transcriptomic files."""

from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"
META.mkdir(parents=True, exist_ok=True)

API = "https://atlas.kpmp.org/spatial-viewer/search/api/as/v1/engines/atlas-repository/search.json"
KEY = "search-vwz67uj2sf8h83h4y8i8j6g3"


def search(filters: list[dict], size: int = 500, max_pages: int = 20) -> list[dict]:
    rows: list[dict] = []
    for page in range(1, max_pages + 1):
        body = {"query": "", "page": {"size": size, "current": page}, "filters": {"all": filters}}
        cmd = [
            "curl", "--http1.1", "-L", "--silent", "--show-error", "--fail",
            "--connect-timeout", "20", "--max-time", "120",
            "--retry", "3", "--retry-delay", "2", "--retry-all-errors",
            "--request", "POST", API,
            "--header", f"Authorization: Bearer {KEY}",
            "--header", "Content-Type: application/json",
            "--header", "Origin: https://atlas.kpmp.org",
            "--header", "Referer: https://atlas.kpmp.org/repository/",
            "--user-agent", "Mozilla/5.0",
            "--data", json.dumps(body),
        ]
        result = subprocess.run(cmd, capture_output=True)
        if result.returncode != 0:
            raise RuntimeError(result.stderr.decode("utf-8", errors="replace"))
        payload = json.loads(result.stdout)
        results = payload.get("results", [])
        for item in results:
            raw = item.get("raw", item)
            rows.append({k: (v.get("raw") if isinstance(v, dict) and "raw" in v else v) for k, v in raw.items()})
        meta = payload.get("meta", {}).get("page", {})
        total_pages = meta.get("total_pages", 1)
        total = meta.get("total_results", len(rows))
        print(f"page {page}/{total_pages}: collected {len(rows)}/{total} ({len(results)} this page)")
        if page >= total_pages or not results:
            break
        time.sleep(0.5)
    return rows


def compact(rows: list[dict]) -> list[dict]:
    keys = ["file_id", "file_name", "package_id", "access", "data_category", "data_type",
            "experimental_strategy", "workflow_type", "data_format", "file_size",
            "redcap_id", "enrollment_category", "kdigo_stage", "primary_adjudicated_category",
            "sex", "age_binned"]
    out = []
    for row in rows:
        out.append({k: row.get(k) for k in keys})
    return out


def main() -> None:
    queries = {
        "clinical_open": [{"data_category": "Clinical"}, {"access": "open"}],
        "transcriptomics_open_aki": [{"data_category": "Molecular"}, {"data_type": "Transcriptomics"},
                                     {"access": "open"}, {"enrollment_category": "AKI"}],
        "transcriptomics_open_reference": [{"data_category": "Molecular"}, {"data_type": "Transcriptomics"},
                                           {"access": "open"}, {"enrollment_category": "Reference"}],
    }
    for name, filters in queries.items():
        rows = search(filters)
        payload = {"filters": filters, "n": len(rows), "rows": compact(rows)}
        (META / f"kpmp_{name}.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False))
        print(f"\n=== {name}: {len(rows)} files ===")
        for row in compact(rows):
            print(" | ".join(str(row.get(k)) for k in [
                "file_name", "file_size", "experimental_strategy", "workflow_type",
                "enrollment_category", "redcap_id", "kdigo_stage"]))


if __name__ == "__main__":
    main()
