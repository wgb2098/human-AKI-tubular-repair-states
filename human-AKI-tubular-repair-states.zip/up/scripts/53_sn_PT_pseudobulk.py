#!/usr/bin/env python3
"""PT-level pseudobulk for the KPMP snRNA-seq atlas (GSE183277) samples.

Third PT-level dataset, alongside KPMP scRNA-seq and GSE210622. Reuses the
worker and aggregation of script 22 so the pipeline is identical across cohorts.
"""

from __future__ import annotations

import importlib.util
import sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
META = ROOT / "metadata"
CELL_META = ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz"
SN_DIR = "data/KPMP/sn"

spec = importlib.util.spec_from_file_location("pt22", ROOT / "scripts/22_PT_pseudobulk.py")
pt22 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pt22)
sys.modules["pt22"] = pt22      # 让子进程能按名字反序列化 pt22.worker（fork 下继承 sys.modules）

SIGNATURES = pt22.SIGNATURES
CYCLING = pt22.CYCLING
APT = pt22.APT_MARKERS
HYPOXIA = pt22.HYPOXIA_TARGETS
GROUPS = {"AKI": "AKI", "COV-AKI": "AKI", "DKD": "CKD", "H-CKD": "CKD", "Ref": "Ref"}


def main() -> None:
    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    pt_all = meta[meta["subclass.l1"] == "PT"].copy()
    pt_all["barcode"] = pt_all.index.str.split("_", n=1).str[1]
    pt_barcodes = {str(p): set(g["barcode"]) for p, g in pt_all.groupby("patient")}
    print("patients with PT annotations:", len(pt_barcodes))

    signatures = {name: list(g["gene"].astype(str))
                  for name, g in pd.read_csv(RES / "Klocke_signature_genes.csv").groupby("signature")}
    signatures["cycling"] = CYCLING
    signatures["aPT_markers"] = APT
    signatures["hypoxia_targets"] = HYPOXIA

    manifest = pd.read_csv(META / "KPMP_open_sn_single_sample_matrices.csv")
    jobs = []
    for _, row in manifest.iterrows():
        participant = str(row["participants"])
        if participant in pt_barcodes:
            jobs.append((str(row["file_id"]), participant, SN_DIR, str(row["condition"])))
    print("matrix jobs:", len(jobs))

    pt22.G.update({"pt_barcodes": pt_barcodes, "signatures": signatures})
    with Pool(6) as pool:
        rows = [r for r in pool.map(pt22.worker, jobs) if r]
    table = pd.DataFrame(rows)
    if "error" in table.columns:
        bad = table[table["error"].notna()]
        if len(bad):
            print("errors:\n", bad[["participant", "error"]].to_string(index=False))
        table = table[table["error"].isna()].drop(columns=["error"]).reset_index(drop=True)
    if table.empty:
        print("no data yet (download still running?)")
        return
    table.to_csv(RES / "KPMP_sn_PT_pseudobulk.csv", index=False)

    agg = pt22.weighted_patient_table(table)
    agg["study_group"] = agg["group"].map(GROUPS)
    state_frac = (pt_all.assign(is_ref=pt_all["state.l2"] == "reference")
                  .groupby("patient")["is_ref"].mean())
    cyc_frac = (pt_all.assign(is_cyc=pt_all["state.l2"] == "cycling")
                .groupby("patient")["is_cyc"].mean())
    agg["reference_state_frac"] = agg["participant"].map(state_frac)
    agg["cycling_state_frac"] = agg["participant"].map(cyc_frac)
    agg.to_csv(RES / "KPMP_sn_PT_pseudobulk_patient.csv", index=False)

    pd.set_option("display.width", 200)
    print("\nPT pseudobulk per patient (sn):")
    print(agg.round(3).to_string(index=False))

    rows = []
    for label, group_a, group_b in (("AKI_vs_Ref", "AKI", "Ref"), ("AKI_vs_CKD", "AKI", "CKD"),
                                    ("CKD_vs_Ref", "CKD", "Ref")):
        for feature in SIGNATURES + ["reference_state_frac", "cycling_state_frac"]:
            a = agg.loc[agg["study_group"] == group_a, feature].dropna()
            b = agg.loc[agg["study_group"] == group_b, feature].dropna()
            if len(a) >= 3 and len(b) >= 3:
                rows.append({"contrast": label, "feature": feature, "n_a": len(a), "n_b": len(b),
                             "median_a": a.median(), "median_b": b.median(),
                             "p": stats.mannwhitneyu(a, b).pvalue})
    tests = pd.DataFrame(rows)
    if len(tests):
        tests["fdr"] = np.nan
        for label in tests["contrast"].unique():
            mask = tests["contrast"] == label
            tests.loc[mask, "fdr"] = multipletests(tests.loc[mask, "p"], method="fdr_bh")[1]
        tests.to_csv(RES / "KPMP_sn_PT_pseudobulk_three_group.csv", index=False)
        print("\nsn PT pseudobulk, patient-level tests:")
        print(tests.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
