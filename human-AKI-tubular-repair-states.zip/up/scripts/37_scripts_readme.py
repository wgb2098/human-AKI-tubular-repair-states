#!/usr/bin/env python3
"""Regenerate scripts/README.md from the scripts' own docstrings."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
SCRIPTS = ROOT / "scripts"
ORDER = [
    ("数据与图谱", ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11"]),
    ("感染相关与严重度", ["12", "13", "15", "16", "17", "18"]),
    ("空间转录组", ["19", "20", "21", "30", "35", "36"]),
    ("PT 层验证", ["22", "23", "24", "25", "26", "27", "28", "29"]),
    ("收尾与交付", ["31", "32", "33", "34"]),
]


def first_line(path: Path) -> str:
    text = path.read_text(errors="replace").splitlines()
    for i, line in enumerate(text[:8]):
        if i == 0 and line.startswith("#!"):
            continue
        stripped = line.strip().strip('"').strip("'")
        if stripped and not stripped.startswith("#"):
            return stripped
        if stripped.startswith("#") and len(stripped) > 3:
            return stripped.lstrip("# ").strip()
    return ""


def main() -> None:
    files = sorted(p for p in SCRIPTS.iterdir() if p.suffix in {".py", ".R", ".sh"})
    assigned = set()
    from datetime import date as _date
    lines = ["# scripts 目录导航", f"生成时间：{_date.today().isoformat()}", "",
             "按执行顺序与主题分组；每个脚本的用途取自其文件头注释。", ""]
    for group, prefixes in ORDER:
        lines.append(f"## {group}")
        lines.append("")
        for path in files:
            if path.name in assigned:
                continue
            if any(path.name.startswith(p) for p in prefixes):
                lines.append(f"- `{path.name}` — {first_line(path)}")
                assigned.add(path.name)
        lines.append("")
    leftovers = [p for p in files if p.name not in assigned]
    if leftovers:
        lines.append("## 其他")
        lines.append("")
        for path in leftovers:
            lines.append(f"- `{path.name}` — {first_line(path)}")
        lines.append("")
    (SCRIPTS / "README.md").write_text("\n".join(lines) + "\n")
    print(f"wrote scripts/README.md ({len(files)} scripts)")


if __name__ == "__main__":
    main()
