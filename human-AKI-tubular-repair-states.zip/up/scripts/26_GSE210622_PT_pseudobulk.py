#!/usr/bin/env python3
"""Independent PT-level replication in GSE210622 (human AKI snRNA-seq).

Control kidneys (tumour nephrectomy, post-mortem 15/60/120 min) vs AKI biopsies
and COVID-AKI. PT cells come from the published annotations; the AKI file names
(AKI1..AKI8) are resolved to metadata sample names by per-cell UMI matching.
"""

from __future__ import annotations

import gzip
import io
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.io import mmread
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
EXTRACTED = ROOT / "data/GSE210622/extracted"
RES = ROOT / "results"
SIGS = RES / "Klocke_signature_genes.csv"

CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]
SIGNATURES = ["injury_stress", "repair_progenitor", "cycling", "reference_PT"]


def files_for(sample: str) -> dict[str, Path]:
    out = {}
    for p in EXTRACTED.glob("*.gz"):
        m = re.match(r"GSM\d+_(.+)\.(barcodes|features|matrix)\.(tsv|mtx)\.gz$", p.name)
        if m and m.group(1) == sample:
            out[m.group(2)] = p
    return out


def main() -> None:
    cells = pd.read_csv(ROOT / "metadata/GSE210622_cells.csv")
    cells["barcode"] = cells["cell"].str.split("_", n=1).str[1]
    mapping = json.loads((ROOT / "metadata/GSE210622_AKI_file_map.json").read_text())
    cells["file_sample"] = cells["sample"].map({v: k for k, v in mapping.items()}).fillna(cells["sample"])

    sig_table = pd.read_csv(SIGS)
    signatures = {name: list(g["gene"].astype(str)) for name, g in sig_table.groupby("signature")}
    signatures["cycling"] = CYCLING

    pt = cells[cells["celltype"] == "PT"]
    rows = []
    for file_sample, group_df in pt.groupby("file_sample"):
        files = files_for(str(file_sample))
        if len(files) < 3:
            print("skip", file_sample, "files missing")
            continue
        features = pd.read_csv(io.BytesIO(gzip.decompress(files["features"].read_bytes())),
                               sep="\t", header=None)
        genes = (features.iloc[:, 1] if features.shape[1] > 1 else features.iloc[:, 0]).astype(str).tolist()
        barcodes = gzip.decompress(files["barcodes"].read_bytes()).decode().split()
        index = {b: i for i, b in enumerate(barcodes)}
        chosen = [b for b in group_df["barcode"] if b in index]
        positions = sorted(index[b] for b in chosen)
        if len(positions) < 20:
            print("skip", file_sample, f"only {len(positions)} PT barcodes matched")
            continue
        matrix = mmread(io.BytesIO(gzip.decompress(files["matrix"].read_bytes()))).tocsc()
        counts = np.asarray(matrix[:, positions].sum(axis=1)).ravel()
        lib = counts.sum()
        logcpm = np.log2(counts / lib * 1e6 + 1)
        series = pd.Series(logcpm, index=genes)
        series = series[~series.index.duplicated(keep="first")]
        z = (series - series.mean()) / (series.std() if series.std() else 1)
        record = {
            "file_sample": file_sample,
            "sample": group_df["sample"].iloc[0],
            "group": group_df["group"].iloc[0],
            "n_PT_cells": len(positions),
            "PT_UMI": int(lib),
        }
        for name in SIGNATURES:
            present = [g for g in signatures[name] if g in z.index]
            record[name] = z.loc[present].mean() if len(present) >= 8 else np.nan
        rows.append(record)
        print(f"{file_sample:6s} {record['sample']:9s} {record['group']:8s} PT={len(positions):5d} "
              f"injury={record['injury_stress']:+.3f} repair={record['repair_progenitor']:+.3f} "
              f"cycling={record['cycling']:+.3f} ref={record['reference_PT']:+.3f}")

    table = pd.DataFrame(rows)
    table.to_csv(RES / "GSE210622_PT_pseudobulk.csv", index=False)

    print("\nAKI vs Control (sample level, Mann-Whitney):")
    tests = []
    for name in SIGNATURES:
        aki = table.loc[table["group"] != "Control", name].dropna()
        ctrl = table.loc[table["group"] == "Control", name].dropna()
        if len(aki) >= 3 and len(ctrl) >= 3:
            p = stats.mannwhitneyu(aki, ctrl).pvalue
            tests.append({"feature": name, "n_AKI": len(aki), "n_Control": len(ctrl),
                          "median_AKI": aki.median(), "median_Control": ctrl.median(), "p": p})
            print(f"  {name:20s} n={len(aki)}/{len(ctrl)} median {aki.median():+.3f} vs "
                  f"{ctrl.median():+.3f}  p={p:.4f}")
    tests = pd.DataFrame(tests)
    if len(tests):
        tests["fdr"] = multipletests(tests["p"], method="fdr_bh")[1]
    tests.to_csv(RES / "GSE210622_PT_pseudobulk_tests.csv", index=False)

    print("\nCOVID-AKI vs non-COVID AKI (exploratory):")
    covid_samples = {"P1cov", "P2cov", "P4cov", "P13cov", "P15cov"}
    covid = table[table["sample"].isin(covid_samples)]
    other = table[(table["group"] != "Control") & (~table["sample"].isin(covid_samples))]
    for name in SIGNATURES:
        a, b = covid[name].dropna(), other[name].dropna()
        if len(a) >= 2 and len(b) >= 2:
            print(f"  {name:20s} median {a.median():+.3f} vs {b.median():+.3f} "
                  f"(n={len(a)}/{len(b)}, p={stats.mannwhitneyu(a, b).pvalue:.3f})")


if __name__ == "__main__":
    main()
