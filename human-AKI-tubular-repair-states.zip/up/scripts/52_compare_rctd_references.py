#!/usr/bin/env python3
"""Compare the two RCTD references (GSE210622 vs KPMP sn) on the same 16 sections.

Reports sample-level compartment fractions under both references, their
agreement, the internal sanity check (reference-PT signature vs deconvolved PT
fraction) and KDIGO-stage trends, so the manuscript can state whether the choice
of reference changes any conclusion.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
REPORTS = ROOT / "reports"

COMPARTMENTS = {
    "PT": ["PT"],
    "TAL": ["TAL"],
    "distal": ["DCT", "CNT", "CD-PC", "CD-IC-A", "CD-IC-B", "tL", "IntC"],
    "endothelium": ["EC"],
    "immune": ["Leuk", "IMM", "Immune"],
    "fibroblast": ["FIB", "Fib"],
    "podocyte": ["Podo", "POD"],
}


def summarise(prefix: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    samples, spots = [], []
    for path in sorted(RES.glob(f"rctd_{prefix}weights_*.csv")):
        patient = path.stem.split("weights_")[-1]
        weights = pd.read_csv(path, index_col=0)
        compartments = pd.DataFrame(index=weights.index)
        for name, members in COMPARTMENTS.items():
            present = [c for c in members if c in weights.columns]
            if present:
                compartments[name] = weights[present].sum(axis=1)
        compartments["barcode"] = compartments.index
        compartments["patient"] = patient
        spots.append(compartments)
        row = {"patient": patient, "n_spots": len(weights)}
        for name in COMPARTMENTS:
            if name in compartments:
                row[name] = compartments[name].mean()
        samples.append(row)
    return pd.DataFrame(samples), pd.concat(spots, ignore_index=True)


def main() -> None:
    if not list(RES.glob("rctd_KPMPref_weights_*.csv")):
        print("KPMP-reference RCTD outputs not available yet")
        return

    gse_samples, gse_spots = summarise("")
    kpmp_samples, kpmp_spots = summarise("KPMPref_")
    pilot = json.loads((ROOT / "metadata/kpmp_spatial_pilot_files.json").read_text())
    stages = pilot["pilot"]
    for frame in (gse_samples, kpmp_samples, gse_spots, kpmp_spots):
        frame["stage"] = frame["patient"].map(stages)
        frame["stage_num"] = pd.to_numeric(frame["stage"].astype(str).str.extract(r"(\d)")[0],
                                           errors="coerce")

    merged = gse_samples.merge(kpmp_samples, on=["patient", "stage", "stage_num"],
                               suffixes=("_gse", "_kpmp"))
    rows = []
    for name in COMPARTMENTS:
        a, b = merged.get(f"{name}_gse"), merged.get(f"{name}_kpmp")
        if a is None or b is None:
            continue
        rho, p = stats.spearmanr(a, b, nan_policy="omit")
        rows.append({"compartment": name, "rho_between_references": rho, "p": p,
                     "median_gse": a.median(), "median_kpmp": b.median(),
                     "n_sections": int(a.notna().sum())})
    agreement = pd.DataFrame(rows)
    agreement.to_csv(RES / "spatial_rctd_reference_agreement.csv", index=False)
    merged.to_csv(RES / "spatial_rctd_reference_sample_table.csv", index=False)

    print("Sample-level agreement between the two references:")
    print(agreement.round(4).to_string(index=False))

    # spot-level concordance
    spot_merge = gse_spots.merge(kpmp_spots, on=["patient", "barcode"], suffixes=("_gse", "_kpmp"))
    spot_rows = []
    for name in COMPARTMENTS:
        a, b = spot_merge.get(f"{name}_gse"), spot_merge.get(f"{name}_kpmp")
        if a is None or b is None:
            continue
        rho, p = stats.spearmanr(a, b, nan_policy="omit")
        spot_rows.append({"compartment": name, "spot_level_rho": rho, "p": p,
                          "n_spots": int(a.notna().sum())})
    spot_agreement = pd.DataFrame(spot_rows)
    spot_agreement.to_csv(RES / "spatial_rctd_reference_agreement_spots.csv", index=False)
    print("\nSpot-level agreement:")
    print(spot_agreement.round(4).to_string(index=False))

    # stage trends under each reference
    trend_rows = []
    for label, frame in (("GSE210622", gse_samples), ("KPMP_sn", kpmp_samples)):
        for name in list(COMPARTMENTS) + ["n_spots"]:
            if name not in frame:
                continue
            x, y = frame["stage_num"], frame[name]
            valid = x.notna() & y.notna()
            if valid.sum() >= 6 and x[valid].nunique() >= 2:
                rho, p = stats.spearmanr(x[valid], y[valid])
                trend_rows.append({"reference": label, "feature": name, "rho": rho, "p": p,
                                   "n": int(valid.sum())})
    trends = pd.DataFrame(trend_rows)
    if len(trends):
        trends["fdr"] = np.nan
        for label in trends["reference"].unique():
            mask = trends["reference"] == label
            trends.loc[mask, "fdr"] = multipletests(trends.loc[mask, "p"].fillna(1), method="fdr_bh")[1]
    trends.to_csv(RES / "spatial_rctd_stage_trends_by_reference.csv", index=False)
    print("\nKDIGO-stage trends by reference (sample level):")
    print(trends.round(4).to_string(index=False))

    lines = ["# RCTD 参考选择对比：GSE210622 vs KPMP sn", "",
             "同一 16 例 Visium，唯一变量是解卷积参考。GSE210622 参考缺成纤维细胞；",
             "KPMP sn 参考与 Visium 同队列、同组织来源，并含 FIB。", "",
             "## 样本水平一致性（compartment 比例，Spearman）", "",
             "| compartment | rho | p | 中位(GSE210622) | 中位(KPMP sn) |", "|---|---:|---:|---:|---:|"]
    for _, row in agreement.iterrows():
        lines.append(f"| {row['compartment']} | {row['rho_between_references']:+.3f} | "
                     f"{row['p']:.2g} | {row['median_gse']:.3f} | {row['median_kpmp']:.3f} |")
    lines += ["", "## spot 水平一致性", "", "| compartment | rho | n spot |", "|---|---:|---:|"]
    for _, row in spot_agreement.iterrows():
        lines.append(f"| {row['compartment']} | {row['spot_level_rho']:+.3f} | {row['n_spots']} |")
    lines += ["", "## 分期趋势（样本水平）", ""]
    if len(trends):
        lines += ["| reference | feature | rho | p | FDR | n |", "|---|---|---:|---:|---:|---:|"]
        for _, row in trends.iterrows():
            lines.append(f"| {row['reference']} | {row['feature']} | {row['rho']:+.3f} | {row['p']:.4f} | "
                         f"{row['fdr']:.3f} | {row['n']} |")
    lines += ["", "完整表：`results/spatial_rctd_reference_agreement*.csv`、"
                  "`spatial_rctd_reference_sample_table.csv`、`spatial_rctd_stage_trends_by_reference.csv`。"]
    (REPORTS / "RCTD_REFERENCE_COMPARISON.md").write_text("\n".join(lines) + "\n")
    print("\nwrote reports/RCTD_REFERENCE_COMPARISON.md")


if __name__ == "__main__":
    main()
