#!/usr/bin/env python3
"""Follow-up pipeline after the first KPMP-reference RCTD pass.

1. wait until the 16 KPMP-reference deconvolutions exist;
2. wait for the sn download to go idle (or time out);
3. if the download brought in enough additional annotated samples, rebuild the
   reference and rerun the deconvolution (otherwise keep the first pass);
4. run the sn PT pseudobulk (script 53), refresh the final numbers table
   (script 47) and the checksums.
"""

from __future__ import annotations

import gzip
import hashlib
import re
import subprocess
import sys
import time
import zipfile
from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
LOGS = ROOT / "logs"
RES = ROOT / "results"
SN = ROOT / "data/KPMP/sn"
CELL_META = ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz"
PATIENTS = ["34-10184", "34-10729", "34-10666", "30-11084", "34-11066", "34-11025", "936-10217",
            "30-11072", "30-10868", "34-10187", "30-11080", "30-11141", "34-10306", "34-10331",
            "30-10018", "34-11042"]
REBUILD_THRESHOLD = 12  # matched samples needed to justify a second RCTD pass


def run(command: list[str], log: str) -> None:
    with open(LOGS / log, "a") as handle:
        subprocess.run(command, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT)


def counts() -> tuple[int, bool]:
    weights = len(list(RES.glob("rctd_KPMPref_weights_*.csv")))
    active = bool(subprocess.run(["pgrep", "-f", "rctd_visium_kpmp_reference.R"],
                                 capture_output=True, text=True).stdout.strip())
    return weights, active


def download_active() -> bool:
    out = subprocess.run(["pgrep", "-f", "kpmp_sn_missing_"], capture_output=True, text=True)
    return bool(out.stdout.strip())


def matched_samples() -> int:
    """Samples in the downloaded set whose barcodes overlap the atlas annotations."""
    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False, usecols=["patient"])
    meta["patient"] = meta["patient"].astype(str)
    meta["barcode"] = meta.index.astype(str).str.split("_", n=1).str[1]
    by_patient = {p: set(g["barcode"]) for p, g in meta.groupby("patient")}
    manifest = pd.read_csv(ROOT / "metadata/KPMP_open_sn_single_sample_matrices.csv")
    seen, matched = set(), 0
    for _, row in manifest.iterrows():
        patient = str(row["participants"])
        if patient in seen:
            continue
        seen.add(patient)
        paths = sorted(SN.glob(f"{row['file_id']}*.zip"))
        if not paths:
            continue
        try:
            with zipfile.ZipFile(paths[0]) as zf:
                name = next(n for n in zf.namelist() if "barcode" in n.lower())
                with zf.open(name) as handle:
                    data = handle.read()
                if name.endswith(".gz"):
                    data = gzip.decompress(data)
                barcodes = set(re.findall(r"ACGT[ACGT-]+-\d+", data.decode(errors="replace")))
        except Exception:
            continue
        annotated = by_patient.get(patient, set())
        if annotated and len(annotated & barcodes) / max(len(annotated), 1) > 0.5:
            matched += 1
    return matched


def refresh_checksums() -> None:
    targets = []
    for folder in ("results", "figures", "reports", "scripts", "metadata"):
        targets += sorted(p for p in (ROOT / folder).rglob("*") if p.is_file() and p.suffix != ".pyc")
    lines = []
    for path in targets:
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b""):
                digest.update(chunk)
        lines.append(f"{digest.hexdigest()}  {path.relative_to(ROOT)}")
    (ROOT / "reports/file_checksums.sha256").write_text("\n".join(lines) + "\n")
    print(f"checksums refreshed ({len(lines)} files)", flush=True)


def main() -> None:
    start = time.time()
    while True:
        weights, active = counts()
        print(f"[{time.strftime('%H:%M:%S')}] KPMP-ref deconvolutions: {weights}/16 "
              f"(RCTD active: {active})", flush=True)
        if (weights >= 16 and not active) or (not active and weights > 0 and time.time() - start > 1800):
            break
        if time.time() - start > 6 * 3600:
            print("timeout waiting for RCTD", flush=True)
            return
        time.sleep(180)

    run([sys.executable, "-I", "scripts/52_compare_rctd_references.py"], "rctd_kpmp_compare.log")
    print("first-pass comparison written", flush=True)

    # wait for the download to settle
    while download_active() and time.time() - start < 12 * 3600:
        have = len(list(SN.glob("*.zip")))
        print(f"[{time.strftime('%H:%M:%S')}] waiting for sn download ({have} files complete)", flush=True)
        time.sleep(300)

    matched = matched_samples()
    print(f"matched annotated samples in the current download: {matched} "
          f"(threshold for a second RCTD pass: {REBUILD_THRESHOLD})", flush=True)
    if matched >= REBUILD_THRESHOLD:
        print("rebuilding the reference and rerunning the deconvolution", flush=True)
        run([sys.executable, "-I", "scripts/49_build_rctd_reference_kpmp.py"], "rctd_kpmp_reference.log")
        batches = [PATIENTS[i::4] for i in range(4)]
        processes = []
        for index, batch in enumerate(batches):
            handle = open(LOGS / f"rctd_kpmp_batch_{index}.log", "a")
            processes.append(subprocess.Popen(
                ["Rscript", "scripts/50_rctd_visium_kpmp_reference.R", ",".join(batch)],
                cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True))
        for process in processes:
            process.wait()
        run([sys.executable, "-I", "scripts/52_compare_rctd_references.py"], "rctd_kpmp_compare.log")
        print("second-pass comparison written", flush=True)

    run([sys.executable, "-I", "scripts/53_sn_PT_pseudobulk.py"], "sn_pt_pseudobulk.log")
    run([sys.executable, "-I", "scripts/47_final_numbers.py"], "final_numbers.log")
    refresh_checksums()
    print("follow-up pipeline complete", flush=True)


if __name__ == "__main__":
    main()
