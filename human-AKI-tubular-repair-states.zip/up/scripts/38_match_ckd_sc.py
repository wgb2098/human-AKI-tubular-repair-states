#!/usr/bin/env python3
"""Match the atlas CKD patients (DKD / H-CKD) to KPMP repository matrices.

The atlas cell metadata identifies CKD patients by their redcap participant id
(e.g. 29-10006) while the repository exposes the same ids, so the matching is by
participant id; barcode overlap is verified after download.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
META = ROOT / "metadata"
BASE = "https://atlas.kpmp.org/api/v1/file/download"
CELL_META = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def main() -> None:
    rows = json.loads((META / "KPMP_sc_all_open_files.json").read_text())
    matrices = []
    for r in rows:
        name = str(r["file_name"])
        if "matrix" not in name.lower() or not name.endswith(".zip"):
            continue
        rid = r["redcap_id"]
        rid = rid[0] if isinstance(rid, list) and rid else (rid if isinstance(rid, str) else "")
        enrollment = r["enrollment_category"]
        enrollment = enrollment if isinstance(enrollment, list) else [enrollment]
        matrices.append({
            "file_id": r["file_id"], "file_name": name, "package_id": r["package_id"],
            "file_size": float(r["file_size"] or 0), "redcap": rid,
            "enrollment": ",".join(str(e) for e in enrollment if e),
            "sample_type": (r["sample_type"] or [""])[0] if isinstance(r["sample_type"], list) else str(r["sample_type"]),
        })

    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    ckd = meta[meta["condition.l2"].isin(["DKD", "H-CKD"])]
    patients = sorted(ckd["patient"].astype(str).unique())
    print("CKD atlas patients:", len(patients))

    manifest, downloads, unmatched = [], [], []
    for patient in patients:
        target = norm(patient)
        hits = [m for m in matrices if norm(m["redcap"]) == target]
        if not hits:
            hits = [m for m in matrices if m["redcap"] and target in norm(m["redcap"])]
        if not hits:
            unmatched.append(patient)
            continue
        libraries = sorted(ckd.loc[ckd["patient"].astype(str) == patient, "library"].unique())
        condition = ckd.loc[ckd["patient"].astype(str) == patient, "condition.l2"].iloc[0]
        for m in hits:
            manifest.append({
                "file_id": m["file_id"], "participants": patient, "condition": condition,
                "libraries": ";".join(libraries), "file_name": m["file_name"],
                "data_url": f"{BASE}/{m['package_id']}/{m['file_name']}",
                "file_size": m["file_size"], "sample_type": m["sample_type"],
                "enrollment": m["enrollment"],
                "experimental_strategy": "Single-cell RNA-Seq",
            })
            downloads.append(f"{BASE}/{m['package_id']}/{m['file_name']}|"
                             f"data/KPMP/sc_ckd/{m['file_id']}_{m['file_name']}|{int(m['file_size'])}")

    table = pd.DataFrame(manifest)
    table.to_csv(META / "KPMP_open_CKD_single_sample_matrices.csv", index=False)
    Path("/tmp/kpmp_ckd_download_list.txt").write_text("\n".join(downloads) + "\n")
    print(f"matched {table['participants'].nunique()} patients / {len(table)} matrices, "
          f"total {table['file_size'].sum()/1048576:.0f} MB")
    if unmatched:
        print("unmatched:", unmatched)
    print("\nper patient:")
    for patient, group in table.groupby("participants"):
        print(f"  {patient:10s} {group['condition'].iloc[0]:6s} {len(group)} matrix(es) "
              f"libraries={group['libraries'].iloc[0][:40]}")


if __name__ == "__main__":
    main()
