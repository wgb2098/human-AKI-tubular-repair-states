#!/usr/bin/env python3
"""Infection-associated vs non-infectious AKI in KPMP sn data and urine cohort."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
FIG = ROOT / "figures"
SN = ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz"
URINE = ROOT / "data/UrineAKI_github"

plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "font.size": 9})

KEY_FEATURES = [
    "frac_state_adaptive - epi", "frac_state_cycling", "frac_state_reference",
    "frac_state_degenerative", "frac_sub_IMM", "frac_sub_FIB",
    "mean_aEpi.score", "mean_degen.score", "mean_cyc.score", "mean_matrisome.score",
]
LABELS = {
    "frac_state_adaptive - epi": "Adaptive epithelial",
    "frac_state_cycling": "Cycling",
    "frac_state_reference": "Reference epithelial",
    "frac_state_degenerative": "Degenerative",
    "frac_sub_IMM": "Immune cells",
    "frac_sub_FIB": "Fibroblasts",
    "mean_aEpi.score": "aEpi score",
    "mean_degen.score": "Degenerative score",
    "mean_cyc.score": "Cycling score",
    "mean_matrisome.score": "Matrisome score",
}


def sn_composition() -> tuple[pd.DataFrame, pd.DataFrame]:
    meta = pd.read_csv(SN, sep="\t", index_col=0, low_memory=False)
    meta = meta[meta["condition.l2"].isin(["Ref", "AKI", "COV-AKI"])].copy()
    rows = []
    for (patient, sample, condition), group in meta.groupby(["patient", "library", "condition.l2"], dropna=False):
        row = {
            "patient": patient, "sample": sample, "group": condition, "n_cells": len(group),
            "frac_state_adaptive - epi": (group["state.l2"] == "adaptive - epi").mean(),
            "frac_state_cycling": (group["state.l2"] == "cycling").mean(),
            "frac_state_reference": (group["state.l2"] == "reference").mean(),
            "frac_state_degenerative": (group["state.l2"] == "degenerative").mean(),
            "frac_sub_IMM": (group["subclass.l1"] == "IMM").mean(),
            "frac_sub_FIB": (group["subclass.l1"] == "FIB").mean(),
            "frac_sub_PT": (group["subclass.l1"] == "PT").mean(),
        }
        for score in ["aEpi.score", "degen.score", "cyc.score", "matrisome.score"]:
            row[f"mean_{score}"] = pd.to_numeric(group[score], errors="coerce").mean()
        rows.append(row)
    table = pd.DataFrame(rows)

    tests = []
    for feature in KEY_FEATURES:
        cov = table.loc[table["group"] == "COV-AKI", feature].dropna()
        aki = table.loc[table["group"] == "AKI", feature].dropna()
        ref = table.loc[table["group"] == "Ref", feature].dropna()
        if len(cov) >= 3 and len(aki) >= 3:
            p_inf = stats.mannwhitneyu(cov, aki).pvalue
        else:
            p_inf = np.nan
        p_ref = stats.mannwhitneyu(cov, ref).pvalue if len(ref) >= 3 else np.nan
        tests.append({
            "feature": feature, "n_COV": len(cov), "n_AKI": len(aki), "n_Ref": len(ref),
            "mean_COV": cov.mean(), "mean_AKI": aki.mean(), "mean_Ref": ref.mean(),
            "p_COV_vs_AKI": p_inf, "p_COV_vs_Ref": p_ref,
        })
    tests = pd.DataFrame(tests)
    tests["fdr_COV_vs_AKI"] = multipletests(tests["p_COV_vs_AKI"].fillna(1), method="fdr_bh")[1]
    tests["fdr_COV_vs_Ref"] = multipletests(tests["p_COV_vs_Ref"].fillna(1), method="fdr_bh")[1]
    table.to_csv(RES / "infection_AKI_sn_sample_composition.csv", index=False)
    tests.to_csv(RES / "infection_AKI_sn_tests.csv", index=False)
    return table, tests


def sn_figure(table: pd.DataFrame, tests: pd.DataFrame) -> None:
    features = [f for f in KEY_FEATURES if f in table.columns]
    fig, axes = plt.subplots(2, 5, figsize=(16, 6.5))
    order = ["Ref", "AKI", "COV-AKI"]
    colors = {"Ref": "#7F8C8D", "AKI": "#2874A6", "COV-AKI": "#C0392B"}
    for ax, feature in zip(axes.ravel(), features):
        data = [table.loc[table["group"] == g, feature].dropna() for g in order]
        bp = ax.boxplot(data, labels=order, widths=0.6, patch_artist=True)
        for patch, g in zip(bp["boxes"], order):
            patch.set_facecolor(colors[g]); patch.set_alpha(0.5)
        for pos, (vals, g) in enumerate(zip(data, order), 1):
            ax.scatter(np.ones(len(vals)) * pos + np.random.uniform(-0.07, 0.07, len(vals)),
                       vals, s=10, color=colors[g])
        row = tests[tests["feature"] == feature]
        if not row.empty:
            p = row.iloc[0]["p_COV_vs_AKI"]
            ax.set_title(f"{LABELS[feature]}\nP(COV vs AKI)={p:.3f}", fontsize=8)
        else:
            ax.set_title(LABELS[feature], fontsize=8)
        ax.tick_params(axis="x", labelsize=7)
    fig.suptitle("Infection-associated (COVID) vs non-infectious AKI: KPMP snRNA-seq", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_infection_AKI_sn.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_infection_AKI_sn.pdf", bbox_inches="tight")
    plt.close(fig)


def urine_analysis() -> pd.DataFrame:
    patients = pd.read_csv(URINE / "Urine_AKI_patient_data.csv", sep=";")
    patients.columns = [c.strip() for c in patients.columns]
    patients = patients.loc[:, ~patients.columns.duplicated()]
    patients["patient_base"] = patients["patient"].astype(str).str.replace(r"\.\d+$", "", regex=True)
    patients = patients[~patients["patient_base"].str.lower().str.startswith("pool")].copy()
    patients = patients[patients["AKI.type"].astype(str).str.lower() != "no aki"].copy()
    patients = patients.drop_duplicates("patient_base").copy()
    patients["infection"] = np.where(
        (patients["AKI.type"].astype(str).str.lower() == "pneumonia")
        | (patients["COVID19_infection"].astype(str).str.lower() == "yes"),
        "Infection-associated", "Non-infectious")
    patients["KDIGO_num"] = pd.to_numeric(patients["KDIGO_AKI_stage"], errors="coerce")
    patients["outcome"] = patients["outcome_after_ninety_daysme.fine"].astype(str)
    patients.to_csv(RES / "infection_AKI_urine_patient.csv", index=False)

    rows = []
    inf = patients[patients["infection"] == "Infection-associated"]
    non = patients[patients["infection"] == "Non-infectious"]
    for feature, kind in [("KDIGO_num", "numeric"), ("age", "numeric")]:
        a = pd.to_numeric(inf[feature], errors="coerce").dropna()
        b = pd.to_numeric(non[feature], errors="coerce").dropna()
        if len(a) >= 3 and len(b) >= 3:
            rows.append({"feature": feature, "n_infection": len(a), "n_non": len(b),
                         "median_infection": a.median(), "median_non": b.median(),
                         "p": stats.mannwhitneyu(a, b).pvalue})
    for feature in ["RRT", "outcome"]:
        ct = pd.crosstab(patients["infection"], patients[feature])
        if ct.shape[1] >= 2:
            try:
                p_value = stats.chi2_contingency(ct)[1]
            except ValueError:
                p_value = np.nan
            rows.append({"feature": feature, "n_infection": len(inf), "n_non": len(non),
                         "median_infection": np.nan, "median_non": np.nan,
                         "p": p_value})
    tests = pd.DataFrame(rows)
    tests.to_csv(RES / "infection_AKI_urine_tests.csv", index=False)

    # Longitudinal trajectories for the 6 patients with infection labels.
    urine = pd.read_csv(URINE / "Urine_AKI_urine_output_crea_data.csv", sep=";")
    urine.columns = [c.strip() for c in urine.columns]
    urine = urine.loc[:, ~urine.columns.duplicated()]
    mapping = dict(zip(patients["patient_base"].astype(str), patients["infection"]))
    colors = {"Infection-associated": "#C0392B", "Non-infectious": "#2874A6"}
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for patient, group in urine.groupby("patient"):
        status = mapping.get(str(patient))
        color = colors.get(status, "grey")
        x = pd.to_numeric(group["day"], errors="coerce").to_numpy(dtype=float)
        y = pd.to_numeric(group["serum_creatinine"], errors="coerce").to_numpy(dtype=float)
        u = pd.to_numeric(group["urinary_output"], errors="coerce").to_numpy(dtype=float)
        axes[0].plot(x, y, color=color, alpha=0.8, marker="o", ms=2)
        axes[1].plot(x, u, color=color, alpha=0.8, marker="o", ms=2)
    axes[0].set(xlabel="Day", ylabel="Serum creatinine (mg/dL)", title="Creatinine trajectories")
    axes[1].set(xlabel="Day", ylabel="Urine output (mL/day)", title="Urine-output trajectories")
    handles = [plt.Line2D([0], [0], color=c, label=k) for k, c in colors.items()]
    axes[1].legend(handles=handles, frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_infection_AKI_urine_trajectories.png", dpi=300)
    fig.savefig(FIG / "Fig_infection_AKI_urine_trajectories.pdf")
    plt.close(fig)

    # KDIGO stage and outcome distribution figure.
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    stage_ct = pd.crosstab(patients["infection"], patients["KDIGO_num"])
    stage_ct.plot(kind="bar", stacked=True, ax=axes[0], color=["#AED6F1", "#F5B041", "#C0392B"])
    axes[0].set_title("KDIGO stage distribution"); axes[0].set_xlabel("")
    outcome_ct = pd.crosstab(patients["infection"], patients["outcome"])
    palette = ["#AED6F1", "#F5B041", "#C0392B", "#7D3C98", "#58D68D"]
    outcome_ct.plot(kind="bar", stacked=True, ax=axes[1], color=palette[: outcome_ct.shape[1]])
    axes[1].set_title("90-day outcome"); axes[1].set_xlabel("")
    axes[1].legend(loc="center left", bbox_to_anchor=(1.0, 0.5), frameon=False, fontsize=8)
    axes[0].legend(loc="best", frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_infection_AKI_urine_clinical.png", dpi=300)
    fig.savefig(FIG / "Fig_infection_AKI_urine_clinical.pdf")
    plt.close(fig)
    return tests


def main() -> None:
    sn_table, sn_tests = sn_composition()
    sn_figure(sn_table, sn_tests)
    urine_tests = urine_analysis()
    print("sn group sizes:")
    print(sn_table["group"].value_counts().to_string())
    print("\nCOV-AKI vs non-COVID AKI (sn):")
    print(sn_tests[["feature", "n_COV", "n_AKI", "mean_COV", "mean_AKI", "p_COV_vs_AKI", "fdr_COV_vs_AKI"]]
          .to_string(index=False))
    print("\nUrine cohort infection vs non-infectious:")
    print(urine_tests.to_string(index=False))


if __name__ == "__main__":
    main()
