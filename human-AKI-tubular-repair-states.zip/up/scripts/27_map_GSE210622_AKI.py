#!/usr/bin/env python3
"""Resolve which AKI file (AKI1..AKI8) belongs to which metadata sample.

The AKI matrices ship the full 6.79M-barcode whitelist, so the mapping is
recovered by matching per-cell UMI totals: for each candidate sample a set of
metadata barcodes is looked up in each file and compared against nCount_RNA.
"""

from __future__ import annotations

import gzip
import io
import json
import re
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.io import mmread

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
EXTRACTED = ROOT / "data/GSE210622/extracted"
CELLS = ROOT / "metadata/GSE210622_cells.csv"
N_TEST = 60


def files_for(sample: str) -> dict[str, Path]:
    out = {}
    for p in EXTRACTED.glob("*.gz"):
        m = re.match(r"GSM\d+_(.+)\.(barcodes|features|matrix)\.(tsv|mtx)\.gz$", p.name)
        if m and m.group(1) == sample:
            out[m.group(2)] = p
    return out


def worker(sample: str) -> dict:
    files = files_for(sample)
    barcodes = gzip.decompress(files["barcodes"].read_bytes()).decode().split()
    index = {b: i for i, b in enumerate(barcodes)}
    matrix = mmread(io.BytesIO(gzip.decompress(files["matrix"].read_bytes()))).tocsc()
    cells = pd.read_csv(CELLS)
    cells["barcode"] = cells["cell"].str.split("_", n=1).str[1]
    candidates = sorted(cells["sample"].unique())
    result = {"file_sample": sample, "matches": {}}
    for candidate in candidates:
        sub = cells[cells["sample"] == candidate]
        if len(sub) < N_TEST:
            continue
        bcs = sub["barcode"].tolist()
        step = max(1, len(bcs) // N_TEST)
        chosen = bcs[::step][:N_TEST]
        cols = [index[b] for b in chosen if b in index]
        if len(cols) < N_TEST * 0.8:
            continue
        sums = np.asarray(matrix[:, cols].sum(axis=0)).ravel()
        expected = sub.set_index("barcode").loc[[b for b in chosen if b in index], "nCount"].to_numpy()
        denom = np.maximum(expected, 1)
        rel = np.abs(sums - expected) / denom
        result["matches"][candidate] = {"n": len(cols), "median_rel_err": float(np.median(rel)),
                                        "frac_exact": float((rel < 0.005).mean())}
    return result


def main() -> None:
    samples = [f"AKI{i}" for i in range(1, 9)]
    with Pool(4) as pool:
        results = pool.map(worker, samples)
    mapping = {}
    for r in results:
        scored = sorted(r["matches"].items(), key=lambda kv: (-kv[1]["frac_exact"], kv[1]["median_rel_err"]))
        print(f"{r['file_sample']}:")
        for candidate, stats in scored[:3]:
            print(f"   {candidate:10s} exact={stats['frac_exact']:.2f} med_err={stats['median_rel_err']:.4f} n={stats['n']}")
        if scored:
            mapping[r["file_sample"]] = scored[0][0]
    print("\nresolved mapping:", mapping)
    (ROOT / "metadata/GSE210622_AKI_file_map.json").write_text(json.dumps(mapping, indent=2))


if __name__ == "__main__":
    main()
