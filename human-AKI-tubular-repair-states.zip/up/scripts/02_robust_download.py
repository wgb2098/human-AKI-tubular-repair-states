#!/usr/bin/env python3
"""Robust resumable downloader for flaky NCBI FTP connections.

Downloads in small byte ranges, retrying each range and resuming from the
current offset when the server closes the connection early.
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import requests

HEADERS = {"User-Agent": "Mozilla/5.0"}


def total_size(url: str, retries: int = 20) -> int:
    for attempt in range(retries):
        try:
            response = requests.head(url, headers=HEADERS, allow_redirects=True, timeout=30)
            if response.status_code in (200, 206) and "Content-Length" in response.headers:
                return int(response.headers["Content-Length"])
        except requests.RequestException:
            pass
        time.sleep(min(2 ** min(attempt, 5), 30))
    raise RuntimeError(f"Could not determine size for {url}")


def download(url: str, target: Path, chunk: int = 4 * 1024 * 1024, max_attempts: int = 200) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_suffix(target.suffix + ".part")
    expected = total_size(url)
    print(f"expected size: {expected} bytes")

    attempts = 0
    while True:
        current = part.stat().st_size if part.exists() else 0
        if current >= expected:
            break
        end = min(current + chunk - 1, expected - 1)
        headers = dict(HEADERS, Range=f"bytes={current}-{end}")
        try:
            with requests.get(url, headers=headers, stream=True, timeout=(20, 120), allow_redirects=True) as response:
                if response.status_code == 403:
                    raise requests.RequestException("403")
                response.raise_for_status()
                if response.status_code == 200:
                    # Server ignored the range: skip bytes up to the current offset.
                    remaining_skip = current
                    with part.open("ab") as handle:
                        for block in response.iter_content(1024 * 1024):
                            if remaining_skip >= len(block):
                                remaining_skip -= len(block)
                                continue
                            handle.write(block[remaining_skip:])
                            remaining_skip = 0
                else:
                    with part.open("ab") as handle:
                        for block in response.iter_content(1024 * 1024):
                            handle.write(block)
            attempts = 0
        except requests.RequestException as exc:
            attempts += 1
            if attempts > max_attempts:
                raise RuntimeError(f"Giving up after {attempts} attempts: {exc}") from exc
            wait = min(1.5 ** min(attempts, 8), 60)
            print(f"retry {attempts}: {exc}; waiting {wait:.1f}s (have {part.stat().st_size if part.exists() else 0}/{expected})")
            time.sleep(wait)

        if part.exists():
            print(f"progress: {part.stat().st_size}/{expected}")

    part.replace(target)
    print(f"downloaded {target} ({target.stat().st_size} bytes)")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("url")
    parser.add_argument("output")
    parser.add_argument("--chunk-mb", type=int, default=4)
    args = parser.parse_args()
    download(args.url, Path(args.output), chunk=args.chunk_mb * 1024 * 1024)


if __name__ == "__main__":
    main()
