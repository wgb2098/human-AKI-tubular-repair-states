# scripts 目录导航
生成时间：2026-11-06

按执行顺序与主题分组；每个脚本的用途取自其文件头注释。

## 数据与图谱

- `00_kpmp_query.py` — Query the public KPMP Atlas repository for open clinical and transcriptomic files.
- `01_kpmp_manifest.py` — Build the KPMP AKI clinical table and open-transcriptomics file manifest.
- `02_robust_download.py` — Robust resumable downloader for flaky NCBI FTP connections.
- `03_kpmp_analysis.py` — Cell-type composition and injury/repair scores by KDIGO severity in KPMP atlas.
- `04_adjusted_models_clinical.py` — Adjusted severity models, ATI/AIN comparison and urine-cohort clinical validation.
- `05_PT_state_analysis.py` — PT-specific state analysis and composite repair index across KDIGO severity.
- `06_download_kpmp_sc.sh` — set -u
- `06b_download_kpmp_reference.sh` — set -u
- `07_signature_validation.py` — External validation of injury/repair signatures in bulk kidney and blood cohorts.
- `08_key_findings_figures.py` — Assemble key findings and summary figures for the AKI repair direction.
- `09_kpmp_pseudobulk.py` — Pseudobulk signature scores from downloaded KPMP single-cell matrices.
- `10_pseudobulk_figure.py` — Pseudobulk signature scores versus KDIGO stage (all downloaded AKI samples).
- `11_combined_pseudobulk.py` — Gene-level pseudobulk comparison of KPMP AKI vs Healthy Reference samples.

## 感染相关与严重度

- `12_infection_AKI.py` — Infection-associated vs non-infectious AKI in KPMP sn data and urine cohort.
- `13_GSE122274_sepsis.py` — Sepsis vs non-sepsis human kidney biopsies (GSE122274): signatures and DE.
- `15_GSE210622_composition.py` — Independent cell-composition validation in GSE210622 (Control / Non-COVID AKI / COVID AKI).
- `16_GSE210622_signatures.py` — Independent gene-level validation in GSE210622.
- `17_GSE210622_fast.py` — Fast parallel gene-level validation for GSE210622 (extracted raw matrices).
- `18_severity_meta.py` — Cross-cohort KDIGO stage-trend meta-analysis (patient-level).
- `18a_GSE67401_cycling.R` — Add cycling signature scores to GSE67401 blood cohort (for severity meta-analysis).

## 空间转录组

- `19_prepare_spatial_pilot.py` — Select KPMP Visium files for the 6-sample spatial pilot.
- `19b_download_spatial_pilot.sh` — set -u
- `19c_download_spatial_robust.sh` — set -u
- `19d_verify_spatial_downloads.py` — Verify downloaded KPMP spatial pilot files and remove truncated/corrupt ones.
- `19e_parallel_download_spatial.py` — Parallel downloader for the KPMP spatial pilot files.
- `20_spatial_pilot_analysis.py` — KPMP Visium spatial pilot: signature scores, spatial maps and Moran's I.
- `21a_build_rctd_reference.py` — Build a subsampled single-cell reference for RCTD from GSE210622.
- `21b_export_rctd_inputs.py` — Export Visium counts and coordinates for RCTD (MatrixMarket + CSV).
- `21c_rctd_visium.R` — RCTD deconvolution of KPMP Visium samples using the GSE210622 reference.
- `30_rctd_downstream.py` — Downstream analysis of the RCTD deconvolution of KPMP Visium samples.
- `35_spatial_neighborhood.py` — Neighbourhood enrichment in the Visium sections.
- `36_spatial_neighborhood_depthadj.py` — Depth-adjusted neighbourhood enrichment in the Visium sections.

## PT 层验证

- `22_PT_pseudobulk.py` — PT-only pseudobulk from KPMP sc matrices, AKI vs Reference patients.
- `23_query_ref_sc.py` — Query KPMP for open single-cell matrices of Reference (healthy) participants.
- `24_match_ref_sc.py` — Match KPMP repository single-cell matrices to Reference (healthy) libraries.
- `25_PT_pseudobulk_figure.py` — Figure and summary table for the patient-level PT pseudobulk comparison.
- `26_GSE210622_PT_pseudobulk.py` — Independent PT-level replication in GSE210622 (human AKI snRNA-seq).
- `27_map_GSE210622_AKI.py` — Resolve which AKI file (AKI1..AKI8) belongs to which metadata sample.
- `28_PT_two_cohorts_figure.py` — Combined PT-level figure: KPMP scRNA-seq and GSE210622 snRNA-seq.
- `29_update_key_findings.py` — Append PT-level pseudobulk results to the key-findings table.

## 收尾与交付

- `31_cohort_table.py` — Build the cohort characteristics table used in the manuscript (Table 1).
- `32_finalize_rctd.py` — Wait for the four RCTD batches, then run the downstream steps and finalise.
- `33_study_design_figure.py` — Study-design schematic (Figure 1) for the AKI repair manuscript.
- `34_package_deliverable.py` — Build the deliverable archive (code, results, figures, reports; no raw data).

## 其他

- `37_scripts_readme.py` — Regenerate scripts/README.md from the scripts' own docstrings.
- `38_match_ckd_sc.py` — Match the atlas CKD patients (DKD / H-CKD) to KPMP repository matrices.
- `39_reviewer_patient_level.py` — Reviewer-response analyses on the KPMP atlas tables (patients as the unit).
- `40_reviewer_baseline_adjusted.py` — Baseline characteristics and covariate-adjusted main contrasts (reviewer request 6).
- `41_reviewer_pseudobulk.py` — Reviewer requests 1 and 4: patient-level and composition-adjusted whole-library pseudobulk.
- `42_reviewer_wholelibrary.py` — Whole-library pseudobulk for the annotated patient subset, and its adjustment for PT content.
- `43_reviewer_umap.py` — PT-cell UMAP across AKI, CKD and reference patients (reviewer minor request).
- `44_three_group_figure.py` — Three-group figure (AKI vs CKD vs reference) for the reviewer revision.
- `45_consolidate_demographics.py` — Consolidated patient-level demographics for the KPMP atlas cohorts.
- `46_match_sn_sc.py` — Match GSE183277 sn atlas patients to KPMP repository single-nucleus matrices.
- `47_final_numbers.py` — Compile the single authoritative numbers table used by the manuscript.
- `48_cycling_sensitivity.py` — Sensitivity of the cycling result in GSE210622 to the cell-cycle gene set.
- `49_build_rctd_reference_kpmp.py` — Build a KPMP snRNA-seq (GSE183277 atlas) reference for RCTD.
- `50_rctd_visium_kpmp_reference.R` — RCTD deconvolution of the 16 Visium sections using the KPMP sn reference.
- `51_run_kpmp_reference_rctd.py` — Wait for the sn download, then build the KPMP sn reference and rerun RCTD.
- `52_compare_rctd_references.py` — Compare the two RCTD references (GSE210622 vs KPMP sn) on the same 16 sections.
- `53_sn_PT_pseudobulk.py` — PT-level pseudobulk for the KPMP snRNA-seq atlas (GSE183277) samples.
- `54_staged_kpmp_pipeline.py` — Staged pipeline for the KPMP-reference RCTD run.
- `55_build_release.py` — Assemble the code/data-availability release bundle (Zenodo/GitHub ready).
- `56_followup_pipeline.py` — Follow-up pipeline after the first KPMP-reference RCTD pass.
- `57_verify_sn_downloads.py` — Verify the KPMP sn matrices on disk against the manifest (size + zip integrity).
- `60_export_state_pseudobulk.py` — Per-patient pseudobulk counts for PT cell states (adaptive / degenerative / reference).
- `61_state_DE.R` — State-specific differential expression (patient-level pseudobulk): AKI vs CKD,
- `62_state_DE_gene_sets.py` — Gene-set level tests on the state-specific DE tables.
- `63_export_celltype_pseudobulk.py` — 按 cell subclass 导出患者级 pseudobulk（用于③的配体-受体分析：PT/免疫/成纤维）。
- `64_parallel_fetch.sh` — 通用 8 路并行 Range 下载器（用于本机限速但服务端支持 Range 的场景）
- `65_urine_signature_bridge.py` — ② 尿液桥梁：在尿液肾小管上皮细胞中量化同一套损伤/修复程序，并关联临床。
- `65b_urine_bridge_v2.py` — ② 尿液桥梁（v2）：用数据集自身的簇标记判定细胞类型/状态，量化同一套程序并关联临床。
- `66_focused_ligand_receptor.py` — ③ 聚焦版细胞互作：PT 来源配体 → 免疫细胞受体（AKI vs CKD vs Reference）。

