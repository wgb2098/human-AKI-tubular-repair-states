#!/usr/bin/env python3
"""Query KPMP for open single-cell matrices of Reference (healthy) participants."""

from __future__ import annotations

import json
import subprocess
import time
from collections import Counter
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
API = "https://atlas.kpmp.org/spatial-viewer/search/api/as/v1/engines/atlas-repository/search.json"
KEY = "search-vwz67uj2sf8h83h4y8i8j6g3"


def g(raw: dict, key: str):
    value = raw.get(key)
    return value.get("raw") if isinstance(value, dict) and "raw" in value else value


def query(page: int, size: int = 100) -> dict | None:
    body = {
        "query": "",
        "page": {"size": size, "current": page},
        "filters": {"all": [
            {"data_category": "Molecular"},
            {"data_type": "Transcriptomics"},
            {"access": "open"},
            {"experimental_strategy": "Single-cell RNA-Seq"},
        ]},
    }
    cmd = [
        "curl", "--http1.1", "-L", "--silent", "--show-error", "--fail",
        "--connect-timeout", "20", "--max-time", "120",
        "--request", "POST", API,
        "--header", f"Authorization: Bearer {KEY}",
        "--header", "Content-Type: application/json",
        "--header", "Origin: https://atlas.kpmp.org",
        "--header", "Referer: https://atlas.kpmp.org/repository/",
        "--user-agent", "Mozilla/5.0",
        "--data", json.dumps(body),
    ]
    for attempt in range(5):
        result = subprocess.run(cmd, capture_output=True)
        if result.returncode == 0 and result.stdout.strip():
            try:
                return json.loads(result.stdout)
            except json.JSONDecodeError:
                pass
        time.sleep(2 + 2 * attempt)
    return None


def main() -> None:
    rows: list[dict] = []
    page, total_pages = 1, 1
    while page <= total_pages:
        payload = query(page)
        if payload is None:
            print(f"page {page} failed permanently")
            break
        total_pages = payload["meta"]["page"]["total_pages"]
        for item in payload["results"]:
            raw = item.get("raw", item)
            rows.append({k: g(raw, k) for k in
                         ("file_id", "file_name", "file_size", "package_id", "workflow_type",
                          "enrollment_category", "sample_type", "participants", "redcap_id",
                          "kdigo_stage", "platform", "data_format")})
        print(f"page {page}/{total_pages}: {len(payload['results'])} files")
        page += 1
        time.sleep(0.4)

    cats = Counter(str(r["enrollment_category"]) for r in rows)
    print("\nenrollment_category counts:", dict(cats))
    matrix = [r for r in rows if "expression_matrix" in str(r["file_name"]).lower()
              or "matrix" in str(r["workflow_type"]).lower()]
    ref = [r for r in matrix if "reference" in str(r["enrollment_category"]).lower()
           or "reference" in str(r["sample_type"]).lower()
           or "ref" in str(r["sample_type"]).lower()]
    print("matrix files:", len(matrix), "reference-like:", len(ref))
    out = ROOT / "metadata/KPMP_sc_all_open_files.json"
    out.write_text(json.dumps(rows, indent=2, ensure_ascii=False))
    print("saved", out)
    for r in ref[:40]:
        print(f"  {str(r['redcap_id']):12s} {str(r['kdigo_stage']):8s} {str(r['sample_type']):22s} "
              f"{float(r['file_size'] or 0)/1048576:7.1f} MB {str(r['file_name'])[:60]}")


if __name__ == "__main__":
    main()
