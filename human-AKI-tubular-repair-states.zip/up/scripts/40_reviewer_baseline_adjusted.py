#!/usr/bin/env python3
"""Baseline characteristics and covariate-adjusted main contrasts (reviewer request 6).

Builds a patient-level baseline table for the KPMP atlas (sex/race from the cell
metadata; age bin, KDIGO stage, baseline eGFR, diabetes/hypertension history from
the open clinical table), tests whether AKI and reference patients are
comparable, and re-runs the main contrasts with adjustment for the available
covariates (rank-based ANCOVA with HC3 robust standard errors).
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
META = ROOT / "metadata"

AGE_MIDPOINT = {"10-19 Years": 14.5, "20-29 Years": 24.5, "30-39 Years": 34.5, "40-49 Years": 44.5,
                "50-59 Years": 54.5, "60-69 Years": 64.5, "70-79 Years": 74.5, "80-89 Years": 84.5}

FEATURES = {
    "sc": ("results/KPMP_sc_sample_composition_scores.csv",
           "results/KPMP_sc_PT_state_table.csv",
           ["frac_state_adaptive - epi", "frac_state_reference", "frac_state_cycling", "frac_sub_IMM",
            "frac_adaptive", "frac_reference", "frac_cycling", "repair_index"]),
    "sn": ("results/KPMP_sn_sample_composition_scores.csv",
           "results/KPMP_sn_PT_state_table.csv",
           ["frac_state_adaptive - epi", "frac_state_reference", "frac_state_cycling", "frac_sub_IMM",
            "frac_adaptive", "frac_reference", "frac_cycling", "repair_index"]),
}


def load_clinical() -> pd.DataFrame:
    cl = pd.read_csv(META / "20260930_OpenAccessClinicalData.csv", low_memory=False)
    cl["pid"] = cl["Participant ID"].astype(str).str.strip()
    cl["key"] = cl["pid"].map(lambda s: re.sub(r"[^a-z0-9]", "", s.lower()))
    cl["age_num"] = cl["Age (Years) (Binned)"].map(AGE_MIDPOINT)
    cl["egfr"] = pd.to_numeric(cl["Baseline eGFR (ml/min/1.73m2)"], errors="coerce")
    cl["clinical_sex"] = cl["Sex"].map({"Female": "F", "Male": "M"})
    keep = ["pid", "key", "clinical_sex", "age_num", "egfr", "KDIGO Stage", "Diabetes History",
            "Hypertension History", "Primary Adjudicated Category", "Enrollment Category"]
    return cl[keep].drop_duplicates("pid")


def patient_demographics(cohort: str) -> pd.DataFrame:
    """Patient-level demographics from the consolidated multi-source table.

    Built by scripts/45_consolidate_demographics.py: the open clinical table is
    the primary source (participant-curated), the KPMP repository index fills
    gaps, and the published cell metadata supplies sex/race.
    """
    table = pd.read_csv(META / "patient_demographics_consolidated.csv")
    table = table[table["cohort"] == cohort].copy()
    table["patient"] = table["patient"].astype(str)
    table["clinical_match"] = np.where(table["age_source"].str.startswith("none"), "none", "matched")
    table["kdigo_clinical"] = table.get("kdigo")
    return table[["patient", "sex", "race", "age_num", "egfr", "diabetes", "hypertension",
                  "clinical_match", "sex_conflict", "age_source", "kdigo_clinical"]]


def patient_table(cohort: str) -> pd.DataFrame:
    tissue_path, pt_path, features = FEATURES[cohort]
    tissue = pd.read_csv(ROOT / tissue_path)
    pt = pd.read_csv(ROOT / pt_path)
    base = tissue[["cohort", "patient", "condition"]].drop_duplicates("patient")
    base = base.merge(patient_demographics(cohort), on="patient", how="left")
    frames = []
    for frame, columns in ((tissue, [f for f in features if f in tissue.columns]),
                           (pt, [f for f in features if f in pt.columns])):
        if not columns:
            continue
        agg = frame.groupby("patient", as_index=False)[columns].median()
        frames.append(agg)
    merged = base
    for frame in frames:
        merged = merged.merge(frame, on="patient", how="outer")
    merged["study_group"] = np.where(merged["condition"].isin(["AKI", "COV-AKI"]), "AKI",
                             np.where(merged["condition"].isin(["DKD", "H-CKD", "CKD"]), "CKD", "Ref"))
    return merged


def group_term_of(design: pd.DataFrame) -> str | None:
    """Name of the group dummy column, if the design contains exactly one."""
    terms = [c for c in design.columns if str(c).startswith("grp_")]
    return terms[0] if len(terms) == 1 else None


def stage_num(frame: pd.DataFrame) -> pd.Series:
    """KDIGO stage as a number, taken from the clinical table where available."""
    clinical = pd.to_numeric(frame.get("kdigo_clinical", pd.Series(index=frame.index,
                                                                dtype=object)
                                                         ).astype(str).str.extract(r"(\d)")[0],
                             errors="coerce")
    atlas = pd.to_numeric(frame.get("stage", pd.Series(index=frame.index, dtype=object)
                                   ).astype(str).str.extract(r"(\d)")[0], errors="coerce")
    return clinical.fillna(atlas)


def main() -> None:
    clinical = load_clinical()
    for cohort in ("sc", "sn"):
        patients = patient_table(cohort)
        features = [f for f in FEATURES[cohort][2] if f in patients.columns]

        # ---------- baseline table ----------
        rows = []
        for group, sub in patients.groupby("study_group"):
            rows.append({
                "cohort": cohort, "group": group, "n_patients": len(sub),
                "sex_female": int((sub["sex"] == "F").sum()), "sex_male": int((sub["sex"] == "M").sum()),
                "sex_unknown": int(sub["sex"].isna().sum()),
                "age_median": sub["age_num"].median(),
                "egfr_median": sub["egfr"].median(), "egfr_available": int(sub["egfr"].notna().sum()),
                "age_available": int(sub["age_num"].notna().sum()),
                "diabetes_yes": int((sub["diabetes"].astype(str).str.lower() == "yes").sum()),
                "hypertension_yes": int((sub["hypertension"].astype(str).str.lower() == "yes").sum()),
                "kdigo_1": int((stage_num(sub) == 1).sum()),
                "kdigo_2": int((stage_num(sub) == 2).sum()),
                "kdigo_3": int((stage_num(sub) == 3).sum()),
                "kdigo_known": int(stage_num(sub).notna().sum()),
                "clinical_match": int((sub["clinical_match"] == "matched").sum()),
            })
        baseline = pd.DataFrame(rows)
        baseline.to_csv(RES / f"reviewer_{cohort}_baseline_table.csv", index=False)

        # ---------- comparability tests ----------
        tests = []
        aki = patients[patients["study_group"] == "AKI"]
        ref = patients[patients["study_group"] == "Ref"]
        ckd = patients[patients["study_group"] == "CKD"]
        for label, other in (("Ref", ref), ("CKD", ckd)):
            table = pd.crosstab(patients["study_group"].isin(["AKI"]), patients["sex"])
            try:
                p_sex = stats.fisher_exact(pd.crosstab(
                    [patients["study_group"].isin(["AKI"]) & patients["sex"].notna(),
                     patients["sex"].fillna("NA")]))[1]
            except Exception:
                p_sex = np.nan
            a = aki["age_num"].dropna()
            b = other["age_num"].dropna()
            p_age = stats.mannwhitneyu(a, b).pvalue if len(a) >= 3 and len(b) >= 3 else np.nan
            a_e = aki["egfr"].dropna()
            b_e = other["egfr"].dropna()
            p_egfr = stats.mannwhitneyu(a_e, b_e).pvalue if len(a_e) >= 3 and len(b_e) >= 3 else np.nan
            tests.append({"cohort": cohort, "contrast": f"AKI_vs_{label}",
                          "n_AKI_age": len(a), "n_other_age": len(b), "p_age": p_age,
                          "n_AKI_egfr": len(a_e), "n_other_egfr": len(b_e), "p_egfr": p_egfr,
                          "p_sex": p_sex})
        pd.DataFrame(tests).to_csv(RES / f"reviewer_{cohort}_baseline_tests.csv", index=False)

        # ---------- adjusted contrasts ----------
        adj_rows = []
        for feature in features:
            data = patients[["study_group", "sex", "age_num", "egfr", feature]].copy()
            data["feature_rank"] = data[feature].rank(pct=True)
            for contrast_name, group_other in (("AKI_vs_Ref", "Ref"), ("AKI_vs_CKD", "CKD")):
                subset = data[data["study_group"].isin(["AKI", group_other])].dropna(subset=["feature_rank"])
                if subset["study_group"].nunique() != 2:
                    continue
                mw = (stats.mannwhitneyu(subset.loc[subset["study_group"] == "AKI", feature],
                                         subset.loc[subset["study_group"] == group_other, feature]).pvalue
                      if subset["study_group"].value_counts().min() >= 3 else np.nan)
                # sex-adjusted (complete for all groups)
                design = pd.get_dummies(subset["study_group"], prefix="grp", drop_first=True).astype(float)
                design["sex_male"] = (subset["sex"] == "M").astype(float)
                design = sm.add_constant(design, has_constant="add")
                model = sm.OLS(subset["feature_rank"].astype(float), design).fit(cov_type="HC3")
                group_term = group_term_of(design)
                # sex + age adjusted (feasible for AKI vs Ref; eGFR is not)
                subset_age = subset.dropna(subset=["age_num"])
                if (len(subset_age) >= 8 and subset_age["study_group"].nunique() == 2
                        and subset_age["study_group"].value_counts().min() >= 5):
                    design_age = pd.get_dummies(subset_age["study_group"], prefix="grp",
                                                drop_first=True).astype(float)
                    design_age["sex_male"] = (subset_age["sex"] == "M").astype(float)
                    design_age["age"] = subset_age["age_num"].astype(float)
                    design_age = sm.add_constant(design_age, has_constant="add")
                    model_age = sm.OLS(subset_age["feature_rank"].astype(float),
                                       design_age).fit(cov_type="HC3")
                    term_age = group_term_of(design_age)
                    p_age, n_age = (model_age.pvalues[term_age] if term_age else np.nan), len(subset_age)
                else:
                    p_age, n_age = np.nan, len(subset_age)

                # sex + age + eGFR adjusted (complete cases only)
                subset2 = subset.dropna(subset=["age_num", "egfr"])
                if (len(subset2) >= 8 and subset2["study_group"].nunique() == 2
                        and subset2["study_group"].value_counts().min() >= 5):
                    design2 = pd.get_dummies(subset2["study_group"], prefix="grp", drop_first=True).astype(float)
                    design2["sex_male"] = (subset2["sex"] == "M").astype(float)
                    design2["age"] = subset2["age_num"].astype(float)
                    design2["egfr"] = subset2["egfr"].astype(float)
                    design2 = sm.add_constant(design2, has_constant="add")
                    model2 = sm.OLS(subset2["feature_rank"].astype(float), design2).fit(cov_type="HC3")
                    term_full = group_term_of(design2)
                    p_full, n_full = (model2.pvalues[term_full] if term_full else np.nan), len(subset2)
                else:
                    p_full, n_full = np.nan, len(subset2)
                adj_rows.append({
                    "cohort": cohort, "contrast": contrast_name, "feature": feature,
                    "n_AKI": int((subset["study_group"] == "AKI").sum()),
                    "n_other": int((subset["study_group"] == group_other).sum()),
                    "p_unadjusted_mannwhitney": mw,
                    "p_sex_adjusted": model.pvalues[group_term] if group_term else np.nan,
                    "p_sex_age_adjusted": p_age, "n_age_model": n_age,
                    "p_sex_age_egfr_adjusted": p_full, "n_full_model": n_full,
                })
        adjusted = pd.DataFrame(adj_rows)
        adjusted["fdr_unadjusted"] = np.nan
        for contrast in adjusted["contrast"].unique():
            mask = adjusted["contrast"] == contrast
            adjusted.loc[mask, "fdr_unadjusted"] = multipletests(
                adjusted.loc[mask, "p_unadjusted_mannwhitney"].fillna(1), method="fdr_bh")[1]
            adjusted.loc[mask, "fdr_sex_adjusted"] = multipletests(
                adjusted.loc[mask, "p_sex_adjusted"].fillna(1), method="fdr_bh")[1]
        adjusted.to_csv(RES / f"reviewer_{cohort}_adjusted_contrasts.csv", index=False)
        patients.to_csv(RES / f"reviewer_{cohort}_patient_table.csv", index=False)

        print(f"\n=== {cohort}: baseline ===")
        print(baseline.to_string(index=False))
        print(pd.DataFrame(tests).to_string(index=False))
        print(f"\n=== {cohort}: adjusted contrasts (selected) ===")
        show = adjusted[adjusted["contrast"] == "AKI_vs_Ref"][
            ["feature", "n_AKI", "n_other", "p_unadjusted_mannwhitney", "p_sex_adjusted",
             "fdr_sex_adjusted", "p_sex_age_adjusted", "n_age_model",
             "p_sex_age_egfr_adjusted", "n_full_model"]]
        print(show.round(4).to_string(index=False))

    print("\nwrote reviewer baseline and adjusted-contrast tables")


if __name__ == "__main__":
    main()
