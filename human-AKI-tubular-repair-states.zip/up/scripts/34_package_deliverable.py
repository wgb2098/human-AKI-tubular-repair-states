#!/usr/bin/env python3
"""Build the deliverable archive (code, results, figures, reports; no raw data)."""

from __future__ import annotations

import json
import subprocess
from datetime import date
from pathlib import Path

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
OUT_DIR = ROOT.parent
STAMP = date.today().isoformat()
ARCHIVE = OUT_DIR / f"aki_repair_results_{STAMP}.zip"

INCLUDE_DIRS = ["scripts", "results", "figures", "reports",
                "data/state_pseudobulk", "data/celltype_pseudobulk"]
INCLUDE_FILES = ["README.md", "未来计划.md"]
INCLUDE_METADATA = [
    "KPMP_open_AKI_single_sample_matrices.csv",
    "KPMP_open_Ref_single_sample_matrices.csv",
    "kpmp_spatial_pilot_files.json",
    "GSE210622_AKI_file_map.json",
    "spatial_download_verify.json",
    "KPMP_AKI_clinical_summary.csv",
]


def main() -> None:
    if ARCHIVE.exists():
        ARCHIVE.unlink()
    targets: list[Path] = []
    skip_suffixes = {".rds", ".pyc"}
    for folder in INCLUDE_DIRS:
        base = ROOT / folder
        if base.exists():
            targets.extend(sorted(p for p in base.rglob("*")
                                  if p.is_file() and p.suffix not in skip_suffixes))
    targets.extend(ROOT / name for name in INCLUDE_FILES if (ROOT / name).exists())
    targets.extend(ROOT / "metadata" / name for name in INCLUDE_METADATA
                   if (ROOT / "metadata" / name).exists())

    listing = OUT_DIR / f"aki_repair_results_{STAMP}_filelist.txt"
    listing.write_text("\n".join(str(p.relative_to(ROOT)) for p in targets) + "\n")

    result = subprocess.run(
        ["zip", "-q", "-9", str(ARCHIVE)] + [str(p.relative_to(ROOT)) for p in targets],
        cwd=ROOT, capture_output=True, text=True)
    if result.returncode != 0:
        print("zip failed:", result.stderr[:500])
        return
    size_mb = ARCHIVE.stat().st_size / 1048576
    print(f"archive: {ARCHIVE}  ({len(targets)} files, {size_mb:.1f} MB)")
    print(f"file list: {listing}")


if __name__ == "__main__":
    main()
