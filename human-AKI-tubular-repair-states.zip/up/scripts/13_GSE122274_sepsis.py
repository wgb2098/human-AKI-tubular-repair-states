#!/usr/bin/env python3
"""Sepsis vs non-sepsis human kidney biopsies (GSE122274): signatures and DE."""

from __future__ import annotations

import gzip
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
DATA = ROOT / "data/GSE122274"
RES = ROOT / "results"
FIG = ROOT / "figures"

COUNTS = DATA / "GSE122274_Hato_Eadon_RNAseq_Counts.csv.gz"
MATRIX = DATA / "GSE122274_series_matrix.txt.gz"
SIGS = RES / "Klocke_signature_genes.csv"
CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]

plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "font.size": 9})


def read_pheno() -> pd.DataFrame:
    fields: dict[str, list[list[str]]] = {}
    for line in gzip.open(MATRIX, "rt", errors="replace"):
        if line.startswith("!Sample_"):
            key, *vals = line.rstrip("\n").split("\t")
            fields.setdefault(key, []).append([v.strip('"') for v in vals])
    titles = fields["!Sample_title"][0]
    gsm = fields["!Sample_geo_accession"][0]
    disease = [v.split(": ", 1)[1] for v in fields["!Sample_characteristics_ch1"][1]]
    sepsis = [v.split(": ", 1)[1] for v in fields["!Sample_characteristics_ch1"][2]]
    age = [int(v.split(": ", 1)[1]) for v in fields["!Sample_characteristics_ch1"][3]]
    gender = [v.split(": ", 1)[1] for v in fields["!Sample_characteristics_ch1"][5]]
    return pd.DataFrame({
        "title": titles, "gsm": gsm, "disease": disease, "sepsis": sepsis,
        "age": age, "gender": gender,
        "sample_key": [t.split(":", 1)[0] for t in titles],
    })


def read_expression(pheno: pd.DataFrame) -> pd.DataFrame:
    counts = pd.read_csv(COUNTS, index_col="Geneid")
    keys = set(pheno["sample_key"])
    sample_cols = [c for c in counts.columns if c in keys]
    if len(sample_cols) != len(pheno):
        raise ValueError(f"sample columns mismatch: {len(sample_cols)} vs {len(pheno)}")
    counts = counts[sample_cols]
    counts = counts.apply(pd.to_numeric, errors="coerce").fillna(0)
    counts = counts[~counts.index.duplicated(keep="first")]
    cpm = counts / counts.sum(axis=0) * 1e6
    return np.log2(cpm + 1)


def signature_scores(expr: pd.DataFrame) -> pd.DataFrame:
    sets = pd.read_csv(SIGS)
    signatures = {name: list(g["gene"].astype(str)) for name, g in sets.groupby("signature")}
    signatures["cycling"] = CYCLING
    z = expr.sub(expr.mean(axis=1), axis=0).div(expr.std(axis=1).replace(0, np.nan), axis=0)
    out = pd.DataFrame(index=expr.columns)
    for name, genes in signatures.items():
        present = [g for g in genes if g in z.index]
        out[f"{name}_score"] = z.loc[present].mean(axis=0) if len(present) >= 8 else np.nan
        out[f"{name}_n_genes"] = len(present)
    return out.reset_index().rename(columns={"index": "sample_key"})


def main() -> None:
    pheno = read_pheno()
    expr = read_expression(pheno)
    scores = signature_scores(expr)
    table = pheno.merge(scores, on="sample_key")
    table.to_csv(RES / "GSE122274_sepsis_signatures.csv", index=False)

    cohort = table[table["sepsis"].isin(["Y", "N"])].copy()
    cohort["sepsis_bin"] = (cohort["sepsis"] == "Y").astype(int)
    print("sepsis crosstab by disease:")
    print(pd.crosstab(cohort["disease"], cohort["sepsis"]).to_string())

    stat_rows = []
    for name in ["cycling", "injury_stress", "repair_progenitor", "reference_PT"]:
        col = f"{name}_score"
        y = cohort.loc[cohort["sepsis"] == "Y", col].dropna()
        n = cohort.loc[cohort["sepsis"] == "N", col].dropna()
        p_mw = stats.mannwhitneyu(y, n).pvalue if len(y) >= 3 and len(n) >= 3 else np.nan
        # OLS adjusting for disease and age
        data = cohort[[col, "sepsis_bin", "disease", "age"]].dropna()
        import statsmodels.api as sm
        X = pd.get_dummies(data[["sepsis_bin", "disease", "age"]], columns=["disease"], drop_first=True).astype(float)
        X = sm.add_constant(X)
        try:
            model = sm.OLS(data[col], X).fit(cov_type="HC3")
            beta, p_adj = model.params.get("sepsis_bin", np.nan), model.pvalues.get("sepsis_bin", np.nan)
        except Exception:
            beta, p_adj = np.nan, np.nan
        stat_rows.append({
            "signature": name, "n_sepsis": len(y), "n_non_sepsis": len(n),
            "mean_sepsis": y.mean(), "mean_non_sepsis": n.mean(),
            "p_mannwhitney": p_mw, "beta_adj": beta, "p_adj_disease_age": p_adj,
        })
    stats_table = pd.DataFrame(stat_rows)
    stats_table["fdr_mannwhitney"] = multipletests(stats_table["p_mannwhitney"].fillna(1), method="fdr_bh")[1]
    stats_table.to_csv(RES / "GSE122274_sepsis_signature_tests.csv", index=False)

    # Differential expression: sepsis effect adjusted for disease, on genes expressed in >=25% samples.
    genes = expr.index[expr.gt(0).mean(axis=1) >= 0.25]
    sub = expr.loc[genes, cohort["sample_key"]]
    y_mat = sub.values
    X_design = pd.get_dummies(cohort[["sepsis_bin", "disease"]], columns=["disease"], drop_first=True).astype(float)
    X_design = sm.add_constant(X_design.values)
    beta = np.linalg.lstsq(X_design, y_mat.T, rcond=None)[0][1]
    resid = y_mat.T - X_design @ np.linalg.lstsq(X_design, y_mat.T, rcond=None)[0]
    dof = X_design.shape[0] - X_design.shape[1]
    sigma2 = (resid ** 2).sum(axis=0) / dof
    xtx_inv = np.linalg.inv(X_design.T @ X_design)
    se = np.sqrt(sigma2 * xtx_inv[1, 1])
    tval = beta / se
    pval = 2 * stats.t.sf(np.abs(tval), dof)
    de = pd.DataFrame({"gene": genes, "logFC_sepsis": beta, "t": tval, "p": pval})
    de["fdr"] = multipletests(de["p"], method="fdr_bh")[1]
    de = de.sort_values("p")
    de.to_csv(RES / "GSE122274_sepsis_DE.csv", index=False)

    fig, axes = plt.subplots(1, 4, figsize=(12, 3.2))
    for ax, name in zip(axes, ["cycling", "injury_stress", "repair_progenitor", "reference_PT"]):
        col = f"{name}_score"
        data = [cohort.loc[cohort["sepsis"] == "Y", col].dropna(),
                cohort.loc[cohort["sepsis"] == "N", col].dropna()]
        ax.boxplot(data, labels=["Sepsis", "Non-sepsis"], widths=0.6, patch_artist=True,
                   boxprops=dict(facecolor="#AED6F1"), medianprops=dict(color="black"))
        for pos, vals, color in [(1, data[0], "#C0392B"), (2, data[1], "#2874A6")]:
            ax.scatter(np.ones(len(vals)) * pos + np.random.uniform(-0.06, 0.06, len(vals)),
                       vals, s=12, color=color)
        row = stats_table[stats_table["signature"] == name]
        p = row.iloc[0]["p_mannwhitney"] if not row.empty else np.nan
        ax.set_title(f"{name.replace('_', ' ')}\nP={p:.3f}", fontsize=9)
        ax.set_ylabel("Signature score (z)")
    fig.suptitle("GSE122274 kidney biopsies: sepsis vs non-sepsis (all ATN/AIN/mixed)", y=1.04)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_GSE122274_sepsis_signatures.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_GSE122274_sepsis_signatures.pdf", bbox_inches="tight")
    plt.close(fig)

    print("\nSignature tests:")
    print(stats_table.to_string(index=False))
    print("\nTop DE genes (sepsis vs non-sepsis, disease-adjusted):")
    print(de.head(20).to_string(index=False))


if __name__ == "__main__":
    main()
