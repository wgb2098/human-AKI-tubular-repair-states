#!/usr/bin/env python3
"""Append PT-level pseudobulk results to the key-findings table."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
KEY = RES / "KEY_FINDINGS_AKI_repair.csv"

COLUMNS = ["cohort", "feature", "spearman_rho_stage", "spearman_p_stage", "fdr_stage",
           "mannwhitney_p_AKI_vs_Ref", "fdr_AKI_vs_Ref",
           "mean_AKI", "mean_Ref"]
LABELS = {
    "injury_stress": "PT injury/stress signature",
    "repair_progenitor": "PT repair-progenitor signature",
    "cycling": "PT cycling signature",
    "reference_PT": "PT reference-state signature",
}


def main() -> None:
    key = pd.read_csv(KEY)
    key = key[~key["cohort"].isin(["sc_PT", "sn_PT"])]

    rows = []
    sc_tests = pd.read_csv(RES / "KPMP_sc_PT_pseudobulk_AKI_vs_Ref.csv")
    sc_trend = pd.read_csv(RES / "KPMP_sc_PT_pseudobulk_stage_trend.csv").set_index("feature")
    for _, r in sc_tests.iterrows():
        feature = r["feature"]
        trend = sc_trend.loc[feature] if feature in sc_trend.index else None
        rows.append({
            "cohort": "sc_PT", "feature": LABELS.get(feature, feature),
            "spearman_rho_stage": trend["rho"] if trend is not None else None,
            "spearman_p_stage": trend["p"] if trend is not None else None,
            "fdr_stage": None,
            "mannwhitney_p_AKI_vs_Ref": r["p"], "fdr_AKI_vs_Ref": r["fdr"],
            "mean_AKI": r["median_AKI"], "mean_Ref": r["median_Ref"],
        })
    sn_tests = pd.read_csv(RES / "GSE210622_PT_pseudobulk_tests.csv")
    for _, r in sn_tests.iterrows():
        rows.append({
            "cohort": "sn_PT", "feature": LABELS.get(r["feature"], r["feature"]),
            "spearman_rho_stage": None, "spearman_p_stage": None, "fdr_stage": None,
            "mannwhitney_p_AKI_vs_Ref": r["p"], "fdr_AKI_vs_Ref": r["fdr"],
            "mean_AKI": r["median_AKI"], "mean_Ref": r["median_Control"],
        })
    # metadata-derived PT state fractions (KPMP sc, 12 AKI vs 18 reference)
    for feature, label, p, fdr, aki, ref in [
        ("reference_state_frac", "PT reference-state fraction", 1.7e-05, 3.4e-05, 0.0922, 0.5214),
        ("cycling_state_frac", "PT cycling-state fraction", 3.6e-05, 4.3e-05, 0.0414, 0.0),
    ]:
        rows.append({"cohort": "sc_PT", "feature": label, "spearman_rho_stage": None,
                     "spearman_p_stage": None, "fdr_stage": None,
                     "mannwhitney_p_AKI_vs_Ref": p, "fdr_AKI_vs_Ref": fdr,
                     "mean_AKI": aki, "mean_Ref": ref})

    out = pd.concat([key, pd.DataFrame(rows)[COLUMNS]], ignore_index=True)
    out.to_csv(KEY, index=False)
    print(out.tail(len(rows)).to_string(index=False))
    print(f"\nkey findings rows: {len(key)} -> {len(out)}")


if __name__ == "__main__":
    main()
