#!/usr/bin/env python3
"""PT-cell UMAP across AKI, CKD and reference patients (reviewer minor request).

Reads the downloaded KPMP matrices, keeps annotated PT cells (state labels come
from the published GSE183276 metadata), concatenates them, and computes a
PCA/UMAP embedding. Two panels: PT state and study group; plus marker overlays.
"""

from __future__ import annotations

import gzip
import io
import re
import zipfile
from multiprocessing import Pool
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.decomposition import PCA

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
FIG = ROOT / "figures"
META = ROOT / "metadata"
CELL_META = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"

MARKERS = ["VCAM1", "SPP1", "MKI67", "SLC34A1"]
G = {}


def worker(job: tuple[str, str, str]) -> dict | None:
    file_id, participant, directory = job
    matches = sorted(ROOT.glob(f"{directory}/{file_id}*.zip"))
    if not matches:
        return None
    cells = G["pt"].get(participant)
    if not cells:
        return None
    try:
        with zipfile.ZipFile(matches[0]) as zf:
            names = zf.namelist()

            def read(name: str) -> bytes:
                with zf.open(name) as handle:
                    data = handle.read()
                return gzip.decompress(data) if name.endswith(".gz") else data

            matrix_name = next(n for n in names if "matrix" in n.lower() and ".mtx" in n.lower())
            feature_name = next(n for n in names if "features" in n.lower() or "genes" in n.lower())
            barcode_name = next(n for n in names if "barcode" in n.lower())
            whitelist = read(barcode_name).decode(errors="replace").split()
            body = read(matrix_name).split(b"\n", 3)[3]
            features = pd.read_csv(io.BytesIO(read(feature_name)), sep="\t", header=None)
        genes = (features.iloc[:, 1].astype(str).tolist() if features.shape[1] > 1
                 else features.iloc[:, 0].astype(str).tolist())
        genes = [re.sub(r"^[A-Za-z0-9]+_{4}", "", g) for g in genes]
        index = {b: i + 1 for i, b in enumerate(whitelist)}
        kept = [b for b in cells if b in index]
        positions = [index[b] for b in kept]
        if len(positions) < 20:
            return None
        df = pd.read_csv(io.BytesIO(body), sep=" ", header=None, names=["g", "c", "v"],
                         dtype={"g": np.int32, "c": np.int32, "v": np.float32}, engine="c")
        df = df[df["c"].isin(set(positions))]
        col_map = {p: i for i, p in enumerate(positions)}
        cols = df["c"].map(col_map).to_numpy()
        mat = sparse.coo_matrix((df["v"].to_numpy(), (df["g"].to_numpy() - 1, cols)),
                                shape=(len(genes), len(positions))).tocsc()
    except Exception as exc:
        print("skip", file_id, exc)
        return None
    return {"file_id": file_id, "participant": participant, "genes": genes,
            "barcodes": kept, "matrix": mat}


def main() -> None:
    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    pt = meta[meta["subclass.l1"] == "PT"].copy()
    pt["barcode"] = pt.index.str.split("_", n=1).str[1]
    kept_patients = pt["patient"].astype(str).unique()
    G["pt"] = {str(p): set(g["barcode"]) for p, g in pt.groupby("patient")}

    jobs = []
    for manifest, directory in [("KPMP_open_AKI_single_sample_matrices.csv", "data/KPMP/sc"),
                                ("KPMP_open_Ref_single_sample_matrices.csv", "data/KPMP/sc_ref"),
                                ("KPMP_open_CKD_single_sample_matrices.csv", "data/KPMP/sc_ckd")]:
        frame = pd.read_csv(META / manifest)
        for _, row in frame.iterrows():
            if str(row["participants"]) in G["pt"]:
                jobs.append((str(row["file_id"]), str(row["participants"]), directory))
    print("matrix jobs:", len(jobs))

    with Pool(6) as pool:
        results = [r for r in pool.map(worker, jobs) if r]
    print("loaded matrices:", len(results))

    # ---------- concatenate on the shared gene space ----------
    gene_sets = [set(r["genes"]) for r in results]
    shared = sorted(set.intersection(*gene_sets))
    print("shared genes:", len(shared))
    blocks, cell_meta = [], []
    for r in results:
        idx = {g: i for i, g in enumerate(r["genes"])}
        rows = [idx[g] for g in shared]
        blocks.append(r["matrix"][rows, :])
        for barcode in r["barcodes"]:
            cell_meta.append({"participant": r["participant"], "barcode": barcode,
                              "file_id": r["file_id"]})
    matrix = sparse.hstack(blocks).tocsr()
    cells = pd.DataFrame(cell_meta)
    annot = pt.reset_index().rename(columns={"index": "cell_index"})
    annot["cell_prefix"] = annot["cell_index"].astype(str).str.split("_", n=1).str[0]
    annot["barcode"] = annot["cell_index"].astype(str).str.split("_", n=1).str[1]
    annot["patient"] = annot["patient"].astype(str)
    cells["patient"] = cells["participant"].astype(str)
    keep_mask = ~cells.duplicated(["patient", "barcode"])
    matrix = matrix[:, keep_mask.to_numpy()]
    cells = cells.loc[keep_mask].reset_index(drop=True)
    cells = cells.merge(annot[["patient", "barcode", "state.l2", "condition.l2"]].drop_duplicates(
        ["patient", "barcode"]), on=["patient", "barcode"], how="left")
    cells["group"] = np.where(cells["condition.l2"].isin(["AKI", "COV-AKI"]), "AKI",
                      np.where(cells["condition.l2"].isin(["DKD", "H-CKD"]), "CKD", "Ref"))
    print("cells:", matrix.shape, cells["group"].value_counts().to_dict())
    print("states:", cells["state.l2"].value_counts(dropna=False).to_dict())

    # ---------- normalise, HVG, PCA, UMAP ----------
    counts = np.asarray(matrix.sum(axis=0)).ravel()
    nonzero = counts > 0
    matrix = matrix[:, nonzero]
    cells = cells.loc[nonzero].reset_index(drop=True)
    csc = matrix.tocsc().astype(np.float32)
    per_cell = np.repeat(counts[nonzero], np.diff(csc.indptr))
    csc.data = np.log2(csc.data / per_cell * 1e4 + 1)
    norm = csc.tocsr()
    gene_var = np.asarray(norm.power(2).mean(axis=1)).ravel() - np.asarray(norm.mean(axis=1)).ravel() ** 2
    hvg = np.argsort(gene_var)[-2000:]
    dense = norm[hvg, :].toarray().T
    dense = (dense - dense.mean(0)) / (dense.std(0) + 1e-9)
    pcs = PCA(n_components=50, random_state=0).fit_transform(dense)
    print("PCA done", pcs.shape)

    import umap

    embedding = umap.UMAP(n_neighbors=15, min_dist=0.3, random_state=0).fit_transform(pcs)
    cells["umap1"], cells["umap2"] = embedding[:, 0], embedding[:, 1]
    cells.to_csv(RES / "reviewer_PT_umap_coordinates.csv.gz", index=False, compression="gzip")

    marker_matrix = {}
    for marker in MARKERS:
        if marker in shared:
            marker_matrix[marker] = np.asarray(norm[shared.index(marker), :].todense()).ravel()

    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "font.size": 9})
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6))
    state_order = ["reference", "adaptive - epi", "degenerative", "cycling", "adaptive - str"]
    state_colors = {"reference": "#2874A6", "adaptive - epi": "#C0392B", "degenerative": "#F39C12",
                    "cycling": "#8E44AD", "adaptive - str": "#1E8449"}
    for state in state_order:
        sub = cells[cells["state.l2"] == state]
        if len(sub):
            axes[0].scatter(sub["umap1"], sub["umap2"], s=2, alpha=0.6,
                            color=state_colors.get(state, "grey"), label=f"{state} (n={len(sub)})")
    axes[0].legend(fontsize=7, markerscale=4, frameon=False)
    axes[0].set_title("PT state (published annotation)")

    group_colors = {"Ref": "#2874A6", "AKI": "#C0392B", "CKD": "#7D3C98"}
    for group in ["Ref", "AKI", "CKD"]:
        sub = cells[cells["group"] == group]
        axes[1].scatter(sub["umap1"], sub["umap2"], s=2, alpha=0.55,
                        color=group_colors[group], label=f"{group} (n={len(sub)})")
    axes[1].legend(fontsize=8, markerscale=4, frameon=False)
    axes[1].set_title("Study group")

    scatter = axes[2].scatter(cells["umap1"], cells["umap2"], s=2,
                              c=np.log1p(marker_matrix.get("VCAM1", np.zeros(len(cells)))),
                              cmap="Reds")
    axes[2].set_title("VCAM1 (log-normalised)")
    plt.colorbar(scatter, ax=axes[2], fraction=0.046, pad=0.02)
    for ax in axes:
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_xlabel("UMAP-1")
    axes[0].set_ylabel("UMAP-2")
    fig.suptitle(f"Proximal-tubule cells from {cells['participant'].nunique()} patients "
                 f"(AKI, CKD and reference kidneys)", fontsize=10)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(FIG / "Fig_UMAP_PT_states.png", dpi=300)
    fig.savefig(FIG / "Fig_UMAP_PT_states.pdf")
    plt.close(fig)
    print("saved figures/Fig_UMAP_PT_states.png/.pdf")


if __name__ == "__main__":
    main()
