#!/usr/bin/env python3
"""Independent gene-level validation in GSE210622.

The RAW matrices are raw 10x matrices over the full barcode whitelist, so the
sample assignment is determined by which metadata barcode set yields non-zero
counts for a given matrix.
"""

from __future__ import annotations

import gzip
import io
import re
import tarfile
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
TAR = ROOT / "data/GSE210622_RAW.tar"
CELLS = ROOT / "metadata/GSE210622_cells.csv"
SIGS = ROOT / "results/Klocke_signature_genes.csv"
RES = ROOT / "results"
FIG = ROOT / "figures"

CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]
plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "font.size": 9})


def tar_members() -> dict[str, dict[str, str]]:
    members: dict[str, dict[str, str]] = defaultdict(dict)
    with tarfile.open(TAR, "r:") as tar:
        for m in tar:
            if not m.isfile():
                continue
            name = m.name.split("/")[-1]
            mo = re.match(r"(GSM\d+)_(.+)\.(barcodes|features|matrix)\.(tsv|mtx)\.gz$", name)
            if mo:
                members[mo.group(2)][mo.group(3)] = m.name
    return dict(members)


def read_member(name: str) -> bytes:
    with tarfile.open(TAR, "r:") as tar:
        handle = tar.extractfile(name)
        return gzip.decompress(handle.read())


def load_metadata() -> pd.DataFrame:
    cells = pd.read_csv(CELLS)
    cells["barcode"] = cells["cell"].str.split("_", n=1).str[1]
    return cells


def main() -> None:
    members = tar_members()
    cells = load_metadata()
    samples = list(cells["sample"].unique())
    sample_info = []
    for s in samples:
        sub = cells[cells["sample"] == s]
        sample_info.append({
            "sample": s, "group": sub["group"].iloc[0], "n_cells": len(sub),
            "nCount_sum": pd.to_numeric(sub["nCount"], errors="coerce").sum(),
            "barcodes": sub["barcode"].tolist(),
            "pt_barcodes": sub.loc[sub["celltype"] == "PT", "barcode"].tolist(),
        })
    print("metadata samples:", [(x["sample"], x["group"], x["n_cells"]) for x in sample_info])

    first = next(iter(members.values()))
    whitelist = read_member(first["barcodes"]).decode(errors="replace").split()
    whitelist_index = {b: i + 1 for i, b in enumerate(whitelist)}  # mtx is 1-based
    n_barcodes = len(whitelist)
    print("whitelist barcodes:", n_barcodes)

    assign_all = np.full(n_barcodes + 1, -1, dtype=np.int8)
    assign_pt = np.full(n_barcodes + 1, -1, dtype=np.int8)
    for idx, info in enumerate(sample_info, start=1):
        for b in info["barcodes"]:
            pos = whitelist_index.get(b)
            if pos:
                assign_all[pos] = idx
        for b in info["pt_barcodes"]:
            pos = whitelist_index.get(b)
            if pos:
                assign_pt[pos] = idx

    signatures = pd.read_csv(SIGS)
    signature_sets = {name: list(g["gene"].astype(str)) for name, g in signatures.groupby("signature")}
    signature_sets["cycling"] = CYCLING

    rows = []
    for sample_name, kinds in sorted(members.items()):
        features = read_member(kinds["features"]).decode(errors="replace").splitlines()
        genes = [line.split("\t")[1] if len(line.split("\t")) > 1 else line.split("\t")[0] for line in features]
        n_genes = len(genes)
        total = np.zeros(len(sample_info) + 1, dtype=np.int64)
        gene_counts = np.zeros((len(sample_info) + 1, n_genes), dtype=np.float64)
        pt_total = np.zeros(len(sample_info) + 1, dtype=np.int64)
        pt_gene_counts = np.zeros((len(sample_info) + 1, n_genes), dtype=np.float64)

        with tarfile.open(TAR, "r:") as tar:
            handle = tar.extractfile(kinds["matrix"])
            gz = gzip.GzipFile(fileobj=handle)
            state = 0
            for line in gz:
                if state < 2:
                    if line.startswith(b"%"):
                        if line.startswith(b"%%MatrixMarket"):
                            state = 1
                        continue
                    parts = line.split()
                    if len(parts) == 3:
                        state = 2
                        continue
                parts = line.split()
                if len(parts) != 3:
                    continue
                gi = int(parts[0]) - 1
                ci = int(parts[1])
                v = float(parts[2])
                cand = assign_all[ci]
                if cand >= 0:
                    total[cand] += v
                    gene_counts[cand, gi] += v
                cand_pt = assign_pt[ci]
                if cand_pt >= 0:
                    pt_total[cand_pt] += v
                    pt_gene_counts[cand_pt, gi] += v

        matched_info = sample_info[int(np.argmax(total)) - 1] if total.max() > 0 else None
        if matched_info is None:
            print("no match for", sample_name)
            continue
        print(f"{sample_name}: matched {matched_info['sample']} ({matched_info['group']}), "
              f"assigned counts {int(total.max())} vs expected {int(matched_info['nCount_sum'])}")

        def score(counts: np.ndarray) -> dict:
            lib = counts.sum()
            if lib <= 0:
                return {}
            cpm = counts / lib * 1e6
            logcpm = np.log2(cpm + 1)
            series = pd.Series(logcpm, index=genes)
            series = series[~series.index.duplicated(keep="first")]
            z = (series - series.mean()) / (series.std() if series.std() else 1)
            out = {}
            for name, gene_list in signature_sets.items():
                present = [g for g in gene_list if g in z.index]
                out[f"{name}_score"] = z.loc[present].mean() if len(present) >= 8 else np.nan
            return out

        row = {
            "tar_sample": sample_name, "meta_sample": matched_info["sample"],
            "group": matched_info["group"], "n_cells": matched_info["n_cells"],
            "total_counts": int(total.max()), "pt_counts": int(pt_total.max()),
        }
        row.update({f"all_{k}": v for k, v in score(gene_counts[int(np.argmax(total))]).items()})
        if pt_total.max() > 0:
            row.update({f"pt_{k}": v for k, v in score(pt_gene_counts[int(np.argmax(pt_total))]).items()})
        rows.append(row)

    table = pd.DataFrame(rows)
    table.to_csv(RES / "GSE210622_signature_scores.csv", index=False)

    stat_rows = []
    for level in ["all", "pt"]:
        for sig in ["cycling", "injury_stress", "repair_progenitor", "reference_PT"]:
            col = f"{level}_{sig}_score"
            if col not in table:
                continue
            control = table.loc[table["group"] == "Control", col].dropna()
            noncov = table.loc[table["group"] == "Non-COVID", col].dropna()
            cov = table.loc[table["group"] == "COVID", col].dropna()
            aki = pd.concat([noncov, cov])
            stat_rows.append({
                "level": level, "signature": sig,
                "n_control": len(control), "n_nonCOVID": len(noncov), "n_COVID": len(cov),
                "mean_control": control.mean(), "mean_nonCOVID": noncov.mean(), "mean_COVID": cov.mean(),
                "p_control_vs_AKI": stats.mannwhitneyu(control, aki).pvalue if len(control) >= 3 and len(aki) >= 3 else np.nan,
                "p_nonCOVID_vs_COVID": stats.mannwhitneyu(noncov, cov).pvalue if len(noncov) >= 3 and len(cov) >= 3 else np.nan,
            })
    stats_table = pd.DataFrame(stat_rows)
    stats_table["fdr_control_vs_AKI"] = multipletests(stats_table["p_control_vs_AKI"].fillna(1), method="fdr_bh")[1]
    stats_table["fdr_nonCOVID_vs_COVID"] = multipletests(stats_table["p_nonCOVID_vs_COVID"].fillna(1), method="fdr_bh")[1]
    stats_table.to_csv(RES / "GSE210622_signature_tests.csv", index=False)

    fig, axes = plt.subplots(2, 4, figsize=(14, 6.5))
    order = ["Control", "Non-COVID", "COVID"]
    colors = {"Control": "#7F8C8D", "Non-COVID": "#2874A6", "COVID": "#C0392B"}
    for row_i, level in enumerate(["all", "pt"]):
        for col_i, sig in enumerate(["cycling", "injury_stress", "repair_progenitor", "reference_PT"]):
            ax = axes[row_i, col_i]
            col = f"{level}_{sig}_score"
            for pos, group in enumerate(order, 1):
                vals = table.loc[table["group"] == group, col].dropna()
                ax.scatter(np.ones(len(vals)) * pos + np.random.uniform(-0.1, 0.1, len(vals)),
                           vals, s=18, color=colors[group])
                if len(vals):
                    ax.hlines(vals.mean(), pos - 0.25, pos + 0.25, color=colors[group], lw=2)
            ax.set_xticks([1, 2, 3]); ax.set_xticklabels(order, fontsize=7)
            ax.set_title(f"{level.upper()} {sig.replace('_', ' ')}", fontsize=8)
    fig.suptitle("Independent validation GSE210622: signatures by group (top = all cells, bottom = PT cells)", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_GSE210622_signature_validation.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_GSE210622_signature_validation.pdf", bbox_inches="tight")
    plt.close(fig)

    print("\nSignature tests:")
    print(stats_table.to_string(index=False))


if __name__ == "__main__":
    main()
