#!/usr/bin/env python3
"""② 尿液桥梁（v2）：用数据集自身的簇标记判定细胞类型/状态，量化同一套程序并关联临床。

要点：
- 细胞类型与 PT 状态由原论文的簇标记（`results/urine_cluster_markers.csv`，23 簇）打分确定；
- 池化样本按 4 个 hashing 标签去卷积到患者（`Urine_AKI_barcode_list.csv`）；
- 每患者输出 PT 样细胞的状态比例（PCT=reference、TEC_dmg/TEC_MMP7=损伤、TEC_prlf/TEC_prg*=修复-增殖）、
  四个签名的中位分值、细胞数；
- 与 KDIGO 分期 / 90 天结局 / RRT / COVID 关联，并对多次采样患者给出纵向轨迹。

循环性声明：签名源自本数据集，本分析不作"独立验证"主张，只回答"能否在尿液中量化并与临床同步"。
"""

from __future__ import annotations

import gzip
import io
import re
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.io import mmread
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
GEO = ROOT / "data/UrineAKI_GEO"
GITHUB = ROOT / "data/UrineAKI_github"
RES = ROOT / "results"

MIN_UMI, MIN_GENES, MIN_CLUSTER_SCORE = 200, 100, 0.0
TOP_MARKERS = 25
CYCLING_12 = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20",
              "TPX2", "CENPF", "CCNA2", "AURKB"]
APT_MARKERS = ["VCAM1", "SPP1", "LTF", "MMP7", "HAVCR1", "CD24", "PROM1", "SOX9", "KRT7", "KRT19"]
SIGNATURES = ["injury_stress", "repair_progenitor", "reference_PT", "cycling", "aPT_markers"]
TAGS = ["CD298B0251", "CD298B0252", "CD298B0253", "CD298B0254"]
PT_STATE_CLUSTERS = {
    "reference": ["PCT"],
    "injury": ["TEC_dmg", "TEC_MMP7", "TEC_IL32", "TEC_LIF", "TEC_IFIT"],
    "repair_prolif": ["TEC_prlf", "TEC_prg1", "TEC_prg2", "TEC_prg3", "TEC_prg4"],
    "other_TEC": ["TEC_GCLM", "TEC_MT", "TEC_TXNRD1"],
}
NON_PT_KIDNEY = ["TAL", "TAL/DCT", "DTL", "CNT/CD", "CD-IC", "CD-PC", "ATL", "PDC", "PDC_inj"]
G: dict = {}


def read_gz(path: Path) -> bytes:
    data = path.read_bytes()
    return gzip.decompress(data) if path.name.endswith(".gz") else data


def worker(sample: str) -> pd.DataFrame | None:
    files = {}
    for path in GEO.glob("GSM*_*.gz"):
        m = G["pattern"].match(path.name)
        if m and m.group(1) == sample:
            files[m.group(2)] = path
    if len(files) < 3:
        return None
    try:
        features = pd.read_csv(io.BytesIO(read_gz(files["features"])), sep="\t", header=None)
        genes = (features.iloc[:, 1].astype(str).tolist() if features.shape[1] > 1
                 else features.iloc[:, 0].astype(str).tolist())
        barcodes = read_gz(files["barcodes"]).decode(errors="replace").split()
        mat = mmread(io.BytesIO(read_gz(files["matrix"]))).tocsr()
    except Exception as exc:
        print("skip", sample, exc)
        return None
    if mat.shape[0] != len(genes):
        genes = genes[: mat.shape[0]]
    totals = np.asarray(mat.sum(axis=0)).ravel()
    ngenes = np.asarray((mat > 0).sum(axis=0)).ravel()
    keep = (totals >= MIN_UMI) & (ngenes >= MIN_GENES)
    mat, barcodes = mat[:, keep], [b for b, k in zip(barcodes, keep) if k]
    if mat.shape[1] < 30:
        return None

    lib = np.asarray(mat.sum(axis=0)).ravel()
    norm = mat.astype(np.float32).tocsc()
    norm.data = np.log2(norm.data / np.repeat(lib, np.diff(norm.indptr)) * 1e4 + 1)
    norm = norm.tocsr()
    gene_index = {}
    for i, g in enumerate(genes):
        gene_index.setdefault(g, i)
    mean = np.asarray(norm.mean(axis=1)).ravel()
    sq = np.asarray(norm.multiply(norm).mean(axis=1)).ravel()
    sd = np.sqrt(np.maximum(sq - mean ** 2, 0))
    z = norm.tocsr(copy=True)
    z.data = (z.data - np.repeat(mean, np.diff(z.indptr))) / np.maximum(np.repeat(sd, np.diff(z.indptr)), 1e-9)
    z = z.tocsc()

    def score(gene_list) -> np.ndarray:
        rows = [gene_index[g] for g in gene_list if g in gene_index]
        if len(rows) < 5:
            return np.zeros(z.shape[1])
        return np.asarray(z[rows, :].mean(axis=0)).ravel()

    cluster_scores = np.vstack([score(gl) for gl in G["cluster_markers"]])
    best = cluster_scores.argmax(axis=0)
    best_score = cluster_scores.max(axis=0)
    clusters = [G["cluster_names"][b] if s > MIN_CLUSTER_SCORE else None
                for b, s in zip(best, best_score)]

    out = pd.DataFrame({"sample": sample, "barcode": barcodes, "umi": lib, "cluster": clusters})
    for name in SIGNATURES:
        out[name] = score(G["signatures"][name])
    for group, members in PT_STATE_CLUSTERS.items():
        idx = [G["cluster_names"].index(c) for c in members if c in G["cluster_names"]]
        out[f"state_{group}"] = cluster_scores[idx, :].max(axis=0) if idx else np.nan
    non_pt_idx = [G["cluster_names"].index(c) for c in NON_PT_KIDNEY if c in G["cluster_names"]]
    out["state_nonPT_kidney"] = cluster_scores[non_pt_idx, :].max(axis=0) if non_pt_idx else np.nan

    if sample.startswith("UR_AKI_Pool"):
        tag_rows = [gene_index[t] for t in TAGS if t in gene_index]
        if len(tag_rows) == 4:
            raw = np.asarray(mat[tag_rows, :].todense())
            frac = raw / np.maximum(raw.sum(axis=0, keepdims=True), 1)
            assign = frac.argmax(axis=0)
            ok = frac.max(axis=0) >= 0.5
            out["tag"] = [TAGS[a] if o else None for a, o in zip(assign, ok)]
        else:
            out["tag"] = None
    return out


def main() -> None:
    sig = pd.read_csv(RES / "Klocke_signature_genes.csv")
    signatures = {name: sorted(set(g["gene"].astype(str))) for name, g in sig.groupby("signature")}
    signatures["cycling"] = CYCLING_12
    signatures["aPT_markers"] = APT_MARKERS
    G["signatures"] = signatures

    markers = pd.read_csv(RES / "urine_cluster_markers.csv")
    markers = markers[(markers["p_val_adj"] < 0.05) & (markers["avg_log2FC"] > 0.25)]
    cluster_markers, cluster_names = [], []
    for cluster, group in markers.groupby("cluster"):
        genes_top = (group.sort_values("avg_log2FC", ascending=False)["gene"]
                     .astype(str).head(TOP_MARKERS).tolist())
        if len(genes_top) >= 5:
            cluster_markers.append(genes_top)
            cluster_names.append(str(cluster))
    G["cluster_markers"], G["cluster_names"] = cluster_markers, cluster_names
    print("簇标记集:", len(cluster_names), "个簇，平均", int(np.mean([len(c) for c in cluster_markers])), "基因")

    G["pattern"] = re.compile(r"GSM\d+_(.+)[._](barcodes|features|matrix)\.(tsv|mtx)\.gz$")
    samples = sorted({m.group(1) for p in GEO.glob("GSM*_*.gz") for m in [G["pattern"].match(p.name)] if m})
    print("样本数:", len(samples))
    with Pool(6) as pool:
        frames = [f for f in pool.map(worker, samples) if f is not None]
    cells = pd.concat(frames, ignore_index=True)

    barcode_list = pd.read_csv(GITHUB / "Urine_AKI_barcode_list.csv", sep=";")
    barcode_list.columns = [c.strip() for c in barcode_list.columns]
    pool_map = {}
    for _, row in barcode_list.iterrows():
        pool = str(row.iloc[0]).strip()
        for tag in TAGS:
            if tag in row.index and pd.notna(row[tag]):
                pool_map[(pool, tag)] = str(row[tag]).strip()

    def resolve(row):
        sample = row["sample"]
        pool_match = re.search(r"(Pool\d)", sample)
        if pool_match:
            tag = row.get("tag")
            return pool_map.get((pool_match.group(1), tag)) if isinstance(tag, str) else None
        return sample

    cells["patient_sample"] = cells.apply(resolve, axis=1)
    pt_clusters = [c for members in PT_STATE_CLUSTERS.values() for c in members]
    cells["is_pt"] = cells["cluster"].isin(pt_clusters)
    pooled_mask = cells["sample"].str.contains("Pool", na=False)
    print("细胞总数:", len(cells), "| PT 样:", int(cells.is_pt.sum()),
          "| 池化细胞可归属:", int(cells.loc[pooled_mask, "patient_sample"].notna().sum()), "/", int(pooled_mask.sum()))

    pt = cells[cells.is_pt & cells.patient_sample.notna()].copy()
    agg = pt.groupby("patient_sample").agg(
        n_pt_cells=("barcode", "size"),
        **{name: (name, "median") for name in SIGNATURES}).reset_index()
    for group in PT_STATE_CLUSTERS:
        agg[f"frac_{group}"] = agg["patient_sample"].map(
            pt.groupby("patient_sample")["cluster"].apply(
                lambda s, members=PT_STATE_CLUSTERS[group]: float(s.isin(members).mean())))
    agg["patient"] = agg["patient_sample"].str.replace(r"\.\d+$", "", regex=True)

    clinical = pd.read_csv(GITHUB / "Urine_AKI_patient_data.csv", sep=";")
    clinical.columns = [c.strip() for c in clinical.columns]
    agg = agg.merge(clinical, left_on="patient_sample", right_on="sample.pseudonym",
                    how="left", suffixes=("", "_clin"))
    missing = agg["sample.pseudonym"].isna()
    if missing.any():
        fallback = clinical.drop_duplicates("patient").set_index("patient")
        for col in ["KDIGO_AKI_stage", "outcome_after_ninety_daysme.fine", "RRT",
                    "AKI.type", "COVID19_infection"]:
            if col in fallback and col in agg.columns:
                agg.loc[missing, col] = agg.loc[missing, "patient"].map(fallback[col])
    agg.to_csv(RES / "urine_signature_scores.csv", index=False)
    cells.to_csv(RES / "urine_cell_clusters.csv.gz", index=False, compression="gzip")

    features = [f"frac_{g}" for g in PT_STATE_CLUSTERS] + SIGNATURES
    print(f"\n可分析样本 {len(agg)}（患者 {agg['patient'].nunique()}）| KDIGO 可得 "
          f"{int(pd.to_numeric(agg.get('KDIGO_AKI_stage'), errors='coerce').notna().sum())}")
    print(agg[["patient_sample", "n_pt_cells"] + features[:6]].round(3).head(12).to_string(index=False))

    rows = []
    stage = pd.to_numeric(agg.get("KDIGO_AKI_stage"), errors="coerce")
    for feature in features:
        valid = stage.notna() & agg[feature].notna()
        if valid.sum() >= 6:
            rho, p = stats.spearmanr(stage[valid], agg.loc[valid, feature])
            rows.append({"feature": feature, "comparison": "KDIGO_stage", "n": int(valid.sum()),
                         "statistic": round(float(rho), 3), "test": "Spearman", "p": p})
        out_col = "outcome_after_ninety_daysme.fine"
        if out_col in agg:
            sub = agg.dropna(subset=[feature, out_col])
            groups = sub.groupby(out_col)[feature]
            if len(groups) >= 2 and min(len(g) for _, g in groups) >= 4:
                rows.append({"feature": feature, "comparison": "90d_outcome", "n": int(len(sub)),
                             "statistic": np.nan, "test": "Kruskal-Wallis",
                             "p": stats.kruskal(*[g.values for _, g in groups]).pvalue})
        if "RRT" in agg:
            a = agg.loc[agg["RRT"].astype(str).str.lower().isin(["yes", "y", "1"]), feature].dropna()
            b = agg.loc[agg["RRT"].astype(str).str.lower().isin(["no", "n", "0"]), feature].dropna()
            if len(a) >= 4 and len(b) >= 4:
                rows.append({"feature": feature, "comparison": "RRT_yes_vs_no", "n": len(a) + len(b),
                             "statistic": np.nan, "test": "Mann-Whitney",
                             "p": stats.mannwhitneyu(a, b).pvalue})
        if "COVID19_infection" in agg:
            covid = agg["COVID19_infection"].astype(str).str.lower()
            a = agg.loc[covid.isin(["yes", "y", "1"]), feature].dropna()
            b = agg.loc[covid.isin(["no", "n", "0"]), feature].dropna()
            if len(a) >= 4 and len(b) >= 4:
                rows.append({"feature": feature, "comparison": "COVID_yes_vs_no", "n": len(a) + len(b),
                             "statistic": np.nan, "test": "Mann-Whitney",
                             "p": stats.mannwhitneyu(a, b).pvalue})
    tests = pd.DataFrame(rows)
    if len(tests):
        tests["fdr"] = multipletests(tests["p"], method="fdr_bh")[1]
    tests.to_csv(RES / "urine_signature_clinical.csv", index=False)
    print("\n临床关联（探索性）:")
    print(tests.round(4).to_string(index=False) if len(tests) else "  样本不足")

    serial = agg[agg["patient_sample"].str.contains(r"\.\d+$", regex=True, na=False)].sort_values("patient_sample")
    serial.to_csv(RES / "urine_signature_longitudinal.csv", index=False)
    print(f"\n纵向样本 {len(serial)} 个 / {serial['patient'].nunique()} 名患者")
    if len(serial):
        print(serial[["patient_sample", "n_pt_cells", "frac_injury", "frac_repair_prolif",
                      "frac_reference", "injury_stress", "repair_progenitor"]].round(3).to_string(index=False))


if __name__ == "__main__":
    main()
