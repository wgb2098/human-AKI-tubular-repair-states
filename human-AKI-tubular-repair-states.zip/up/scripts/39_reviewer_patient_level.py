#!/usr/bin/env python3
"""Reviewer-response analyses on the KPMP atlas tables (patients as the unit).

Covers four requests from the peer-review comments:
  1. de-pseudoreplication: patient-level aggregation (median over libraries) with
     a side-by-side sample-level vs patient-level comparison;
  2. CKD control: AKI vs CKD (DKD + H-CKD) vs Reference, including the direct
     AKI vs CKD contrast;
  3. FDR strategy: feature families defined explicitly, plus a global-FDR
     sensitivity analysis showing which calls flip;
  4. repair index: leave-one-out and alternative-weight sensitivity analyses.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
OUT = ROOT / "reports"

FAMILIES = {
    "epithelial_state_fraction": ["frac_state_adaptive - epi", "frac_state_adaptive - str",
                                  "frac_state_degenerative", "frac_state_reference", "frac_state_cycling",
                                  "frac_state_transitioning"],
    "subclass_fraction": ["frac_sub_PT", "frac_sub_TAL", "frac_sub_DTL", "frac_sub_ATL", "frac_sub_CNT",
                          "frac_sub_DCT", "frac_sub_IC", "frac_sub_PC", "frac_sub_EC", "frac_sub_VSM/P",
                          "frac_sub_POD", "frac_sub_PEC", "frac_sub_FIB", "frac_sub_IMM", "frac_sub_NEU",
                          "frac_sub_PapE"],
    "module_score": ["mean_aEpi.score", "mean_degen.score", "mean_cyc.score", "mean_aStr.score",
                     "mean_matrisome.score", "mean_collagen.score", "mean_glycoprotein.score",
                     "mean_proteoglycan.score", "mean_aEpi", "mean_degen", "mean_cyc"],
    "qc": ["mean_percent.mt", "mean_nFeature_RNA"],
    "pt_state_fraction": ["frac_adaptive", "frac_degenerative", "frac_reference", "frac_cycling",
                          "frac_transitioning", "repair_index"],
}
CKD_LABELS = {"DKD", "H-CKD", "CKD"}


def patient_level(table: pd.DataFrame, value_columns: list[str]) -> pd.DataFrame:
    agg = table.groupby(["cohort", "patient", "condition"], as_index=False)[value_columns].median()
    if "stage" in table.columns:
        stage = table.groupby("patient")["stage"].first()
        agg["stage"] = agg["patient"].map(stage)
    return agg


def contrast(frame: pd.DataFrame, feature: str, group_a: set[str], group_b: set[str]) -> tuple[float, float, int, int]:
    a = frame.loc[frame["condition"].isin(group_a), feature].dropna()
    b = frame.loc[frame["condition"].isin(group_b), feature].dropna()
    if len(a) >= 3 and len(b) >= 3:
        return stats.mannwhitneyu(a, b).pvalue, np.nan, len(a), len(b)
    return np.nan, np.nan, len(a), len(b)


def kruskal(frame: pd.DataFrame, feature: str, groups: list[set[str]]) -> tuple[float, int]:
    samples = [frame.loc[frame["condition"].isin(g), feature].dropna() for g in groups]
    samples = [s for s in samples if len(s) >= 2]
    total = sum(len(s) for s in samples)
    if len(samples) >= 3:
        try:
            return stats.kruskal(*samples).pvalue, total
        except ValueError:  # all values identical (e.g. all-zero feature)
            return np.nan, total
    return np.nan, total


def repair_index_variants(frame: pd.DataFrame) -> pd.DataFrame:
    rows = []
    base = frame.copy()
    aki = base["condition"].isin({"AKI", "COV-AKI"})
    ref = base["condition"] == "Ref"
    ckd = base["condition"].isin(CKD_LABELS)

    def z(column: str) -> pd.Series:
        values = base[column].astype(float)
        return (values - values.mean()) / (values.std() if values.std() else 1)

    adaptive, cycling, reference = z("frac_adaptive"), z("frac_cycling"), z("frac_reference")
    variants = {
        "adaptive + cycling - reference (original)": adaptive + cycling - reference,
        "adaptive + cycling (drop reference)": adaptive + cycling,
        "adaptive - reference (drop cycling)": adaptive - reference,
        "cycling - reference (drop adaptive)": cycling - reference,
        "adaptive only": adaptive,
        "cycling only": cycling,
        "reference only (negated)": -reference,
    }
    for name, values in variants.items():
        base[name] = values
        p_aki_ref = stats.mannwhitneyu(base.loc[aki, name], base.loc[ref, name]).pvalue
        p_aki_ckd = (stats.mannwhitneyu(base.loc[aki, name], base.loc[ckd, name]).pvalue
                     if ckd.sum() >= 3 else np.nan)
        rows.append({
            "variant": name,
            "median_AKI": base.loc[aki, name].median(),
            "median_Ref": base.loc[ref, name].median(),
            "median_CKD": base.loc[ckd, name].median() if ckd.any() else np.nan,
            "p_AKI_vs_Ref": p_aki_ref,
            "p_AKI_vs_CKD": p_aki_ckd,
        })
    return pd.DataFrame(rows)


def main() -> None:
    summary_rows = []
    for cohort, table_names in [
        ("sc", ("KPMP_sc_sample_composition_scores", "KPMP_sc_PT_state_table")),
        ("sn", ("KPMP_sn_sample_composition_scores", "KPMP_sn_PT_state_table")),
    ]:
        for table_name in table_names:
            raw = pd.read_csv(RES / f"{table_name}.csv")
            entity = "PT" if "PT_state" in table_name else "tissue"
            value_columns = [c for c in raw.columns
                             if c.startswith(("frac_", "mean_")) and raw[c].dtype != object]
            if "repair_index" in raw.columns:
                value_columns.append("repair_index")
            if "repair_index" not in raw.columns:
                raw["repair_index"] = (raw["frac_adaptive"] + raw["frac_cycling"] - raw["frac_reference"]
                                       if {"frac_adaptive", "frac_cycling", "frac_reference"} <= set(raw.columns)
                                       else np.nan)
            value_columns = [c for c in dict.fromkeys(value_columns)]
            assert len(set(raw.columns)) == len(raw.columns), f"duplicate columns in {table_name}"

            patients = patient_level(raw, list(dict.fromkeys(value_columns + ["repair_index"])))
            print(f"\n=== {cohort} / {entity}: {len(raw)} libraries -> {len(patients)} patients ===")
            print("   conditions:", patients["condition"].value_counts().to_dict())

            # --- 1) sample vs patient level -------------------------------------
            comparison = []
            for feature in value_columns:
                p_sample = contrast(raw, feature, {"AKI", "COV-AKI"}, {"Ref"})[0]
                p_patient = contrast(patients, feature, {"AKI", "COV-AKI"}, {"Ref"})[0]
                comparison.append({"feature": feature, "p_sample_level": p_sample,
                                   "p_patient_level": p_patient})
            comparison = pd.DataFrame(comparison)
            for column in ("p_sample_level", "p_patient_level"):
                comparison[f"fdr_{column}"] = multipletests(comparison[column].fillna(1), method="fdr_bh")[1]
            comparison.to_csv(RES / f"reviewer_{cohort}_{entity}_sample_vs_patient.csv", index=False)

            # --- 2) three-group comparison --------------------------------------
            rows = []
            for feature in value_columns:
                aki = patients.loc[patients["condition"].isin({"AKI", "COV-AKI"}), feature].dropna()
                ckd = patients.loc[patients["condition"].isin(CKD_LABELS), feature].dropna()
                ref = patients.loc[patients["condition"] == "Ref", feature].dropna()
                row = {
                    "feature": feature,
                    "n_AKI": len(aki), "n_CKD": len(ckd), "n_Ref": len(ref),
                    "median_AKI": aki.median(), "median_CKD": ckd.median(), "median_Ref": ref.median(),
                    "p_AKI_vs_Ref": (stats.mannwhitneyu(aki, ref).pvalue
                                     if len(aki) >= 3 and len(ref) >= 3 else np.nan),
                    "p_AKI_vs_CKD": (stats.mannwhitneyu(aki, ckd).pvalue
                                     if len(aki) >= 3 and len(ckd) >= 3 else np.nan),
                    "p_CKD_vs_Ref": (stats.mannwhitneyu(ckd, ref).pvalue
                                     if len(ckd) >= 3 and len(ref) >= 3 else np.nan),
                    "p_kruskal_3group": kruskal(patients, feature,
                                                [{"AKI", "COV-AKI"}, CKD_LABELS, {"Ref"}])[0],
                }
                rows.append(row)
            three = pd.DataFrame(rows)
            for column in ("p_AKI_vs_Ref", "p_AKI_vs_CKD", "p_CKD_vs_Ref", "p_kruskal_3group"):
                three[f"fdr_{column}"] = multipletests(three[column].fillna(1), method="fdr_bh")[1]
            three.to_csv(RES / f"reviewer_{cohort}_{entity}_three_group.csv", index=False)
            print(three[["feature", "median_AKI", "median_CKD", "median_Ref",
                         "p_AKI_vs_Ref", "p_AKI_vs_CKD", "p_CKD_vs_Ref"]].round(4).to_string(index=False))

            # --- 3) FDR strategy -------------------------------------------------
            def fdr_string(pvalues: pd.Series) -> str:
                if len(pvalues) == 0:
                    return "n/a (family not present in this table)"
                return ", ".join(f"{v:.4g}" for v in multipletests(pvalues.fillna(1), method="fdr_bh")[1])

            family_rows = []
            for family, features in FAMILIES.items():
                present = [f for f in features if f in three["feature"].tolist()]
                subset = three[three["feature"].isin(present)]
                family_rows.append({
                    "family": family, "features": ";".join(present), "n": len(subset),
                    "fdr_AKI_vs_Ref": fdr_string(subset["p_AKI_vs_Ref"]),
                    "fdr_AKI_vs_CKD": fdr_string(subset["p_AKI_vs_CKD"]),
                })
            family_rows.append({
                "family": "global", "features": "all evaluated features", "n": len(three),
                "fdr_AKI_vs_Ref": fdr_string(three["p_AKI_vs_Ref"]),
                "fdr_AKI_vs_CKD": fdr_string(three["p_AKI_vs_CKD"]),
            })
            pd.DataFrame(family_rows).to_csv(RES / f"reviewer_{cohort}_{entity}_fdr_strategy.csv", index=False)

            # --- 4) repair index sensitivity -------------------------------------
            if {"frac_adaptive", "frac_cycling", "frac_reference"} <= set(patients.columns):
                loo = repair_index_variants(patients)
                loo.insert(0, "entity", entity)
                loo.insert(0, "cohort", cohort)
                loo.to_csv(RES / f"reviewer_{cohort}_{entity}_repair_index_sensitivity.csv", index=False)
                print("\nrepair index sensitivity:")
                print(loo.round(4).to_string(index=False))
            else:
                print("\nrepair index sensitivity: not applicable "
                      "(no PT-state fractions in this table)")

            for _, row in comparison.iterrows():
                summary_rows.append({"cohort": cohort, "entity": entity, **row.to_dict()})

    pd.DataFrame(summary_rows).to_csv(RES / "reviewer_sample_vs_patient_all.csv", index=False)
    print("\nwrote reviewer_* result tables")


if __name__ == "__main__":
    main()
