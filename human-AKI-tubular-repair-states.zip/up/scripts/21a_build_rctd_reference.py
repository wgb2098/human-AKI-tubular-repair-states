#!/usr/bin/env python3
"""Build a subsampled single-cell reference for RCTD from GSE210622.

Uses 6 samples covering control, non-COVID AKI and COVID AKI, and keeps at
most MAX_PER_TYPE cells per (sample, cell type) to keep RCTD tractable.
"""

from __future__ import annotations

import gzip
import io
import re
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmwrite

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
EXTRACTED = ROOT / "data/GSE210622/extracted"
CELLS = ROOT / "metadata/GSE210622_cells.csv"
OUT = ROOT / "data/rctd_reference"
OUT.mkdir(parents=True, exist_ok=True)

# (file-name sample key, metadata sample name)
REF_SAMPLES = [
    ("Control-TN1", "Control-TN1"),
    ("Control-TN2", "Control-TN2"),
    ("Control-15min", "Control-15min"),
    ("AKI1", "P1cov"),
    ("AKI6", "P3sepsis"),
    ("AKI7", "Pat17"),
]
MAX_PER_TYPE = 150


def files_for(sample: str) -> dict[str, Path]:
    out = {}
    for p in EXTRACTED.glob("*.gz"):
        m = re.match(r"GSM\d+_(.+)\.(barcodes|features|matrix)\.(tsv|mtx)\.gz$", p.name)
        if m and m.group(1) == sample:
            out[m.group(2)] = p
    return out


def main() -> None:
    cells = pd.read_csv(CELLS)
    cells["barcode"] = cells["cell"].str.split("_", n=1).str[1]

    first = files_for(REF_SAMPLES[0][0])
    whitelist = gzip.decompress(first["barcodes"].read_bytes()).decode(errors="replace").split()
    index = {b: i + 1 for i, b in enumerate(whitelist)}  # mtx columns are 1-based
    n_barcodes = len(whitelist)

    features = pd.read_csv(io.BytesIO(gzip.decompress(first["features"].read_bytes())), sep="\t", header=None)
    genes = features.iloc[:, 1].astype(str).tolist()

    gene_rows, cell_cols, values = [], [], []
    cell_names, cell_types, cell_samples = [], [], []
    offset = 0
    for file_key, meta_name in REF_SAMPLES:
        files = files_for(file_key)
        if not files:
            print("skip missing sample", file_key)
            continue
        meta = cells[cells["sample"] == meta_name]
        chosen = (meta.groupby("celltype", group_keys=False)
                  .apply(lambda g: g.sample(min(len(g), MAX_PER_TYPE), random_state=0)))
        barcodes = chosen["barcode"].tolist()
        types = chosen["celltype"].tolist()
        positions = [index[b] for b in barcodes if b in index]
        keep = [b for b in barcodes if b in index]
        pos_set = set(positions)
        print(f"{file_key} -> {meta_name}: {len(keep)} cells selected")

        body = gzip.decompress(files["matrix"].read_bytes()).split(b"\n", 3)[3]
        df = pd.read_csv(io.BytesIO(body), sep=" ", header=None, names=["g", "c", "v"],
                         dtype={"g": np.int32, "c": np.int32, "v": np.float32}, engine="c")
        df = df[df["c"].isin(pos_set)]
        gene_rows.append(df["g"].to_numpy() - 1)
        cell_cols.append(df["c"].map({p: i + offset for i, p in enumerate(positions)}).to_numpy())
        values.append(df["v"].to_numpy())
        cell_names.extend(keep)
        cell_types.extend(types)
        cell_samples.extend([meta_name] * len(keep))
        offset += len(keep)

    rows = np.concatenate(gene_rows)
    cols = np.concatenate(cell_cols)
    vals = np.concatenate(values)
    mat = sparse.coo_matrix((vals, (rows, cols)), shape=(len(genes), offset)).tocsr()
    print("reference matrix:", mat.shape, "nnz", mat.nnz)

    mmwrite(OUT / "reference_counts.mtx", mat)
    (OUT / "reference_genes.txt").write_text("\n".join(genes) + "\n")
    (OUT / "reference_cells.txt").write_text("\n".join(cell_names) + "\n")
    (OUT / "reference_celltypes.txt").write_text("\n".join(cell_types) + "\n")
    pd.DataFrame({"cell": cell_names, "celltype": cell_types, "sample": cell_samples}).to_csv(
        OUT / "reference_cells_meta.csv", index=False)
    print("saved to", OUT)


if __name__ == "__main__":
    main()
