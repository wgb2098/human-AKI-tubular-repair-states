#!/usr/bin/env python3
"""Per-patient pseudobulk counts for PT cell states (adaptive / degenerative / reference).

Feeds the state-specific differential expression analysis (AKI vs CKD within the
same PT state). One pass over the matrices accumulates counts for every state.
"""

from __future__ import annotations

import gzip
import io
import re
import zipfile
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmwrite

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
OUT = ROOT / "data/state_pseudobulk"
META = ROOT / "metadata"
CELL_META = ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz"

STATES = ["adaptive - epi", "degenerative", "reference", "cycling"]
MIN_CELLS = 20
G: dict = {}


def worker(job: tuple[str, str, str]) -> dict | None:
    file_id, participant, directory = job
    matches = sorted(ROOT.glob(f"{directory}/{file_id}*.zip"))
    if not matches:
        return None
    state_barcodes = G["state_barcodes"].get(participant)
    if not state_barcodes:
        return None
    try:
        with zipfile.ZipFile(matches[0]) as zf:
            names = zf.namelist()

            def read(name: str) -> bytes:
                with zf.open(name) as handle:
                    data = handle.read()
                return gzip.decompress(data) if name.endswith(".gz") else data

            matrix_name = next(n for n in names if "matrix" in n.lower() and ".mtx" in n.lower())
            feature_name = next(n for n in names if "features" in n.lower() or "genes" in n.lower())
            barcode_name = next(n for n in names if "barcode" in n.lower())
            whitelist = read(barcode_name).decode(errors="replace").split()
            body = read(matrix_name).split(b"\n", 3)[3]
            features = pd.read_csv(io.BytesIO(read(feature_name)), sep="\t", header=None)
        genes = (features.iloc[:, 1].astype(str).tolist() if features.shape[1] > 1
                 else features.iloc[:, 0].astype(str).tolist())
        genes = [re.sub(r"^[A-Za-z0-9]+_{4}", "", g) for g in genes]
        index = {b: i + 1 for i, b in enumerate(whitelist)}

        wanted = {}
        for state, barcodes in state_barcodes.items():
            positions = {index[b] for b in barcodes if b in index}
            if len(positions) >= MIN_CELLS:
                wanted[state] = positions
        if not wanted:
            return None

        df = pd.read_csv(io.BytesIO(body), sep=" ", header=None, names=["g", "c", "v"],
                         dtype={"g": np.int32, "c": np.int32, "v": np.float32}, engine="c")
        out = {"file_id": file_id, "participant": participant, "genes": genes, "counts": {}}
        for state, positions in wanted.items():
            sub = df[df["c"].isin(positions)]
            counts = np.bincount(sub["g"].to_numpy() - 1, weights=sub["v"].to_numpy(),
                                 minlength=len(genes))
            counts = np.rint(counts).astype(np.int64)   # UMI 为整数，避免 float 累加
            out["counts"][state] = (counts, len(positions))
        return out
    except Exception as exc:
        print("skip", file_id, exc)
        return None


def main() -> None:
    meta = pd.read_csv(CELL_META, sep="\t", index_col=0, low_memory=False)
    pt = meta[meta["subclass.l1"] == "PT"].copy()
    pt["barcode"] = pt.index.str.split("_", n=1).str[1]
    pt["patient"] = pt["patient"].astype(str)
    state_barcodes = {}
    for patient, group in pt.groupby("patient"):
        mapping = {}
        for state in STATES:
            barcodes = set(group.loc[group["state.l2"] == state, "barcode"])
            if barcodes:
                mapping[state] = barcodes
        if mapping:
            state_barcodes[patient] = mapping
    G["state_barcodes"] = state_barcodes
    print("patients with annotated states:", len(state_barcodes))

    jobs = []
    for manifest, directory in [("KPMP_open_AKI_single_sample_matrices.csv", "data/KPMP/sc"),
                                ("KPMP_open_Ref_single_sample_matrices.csv", "data/KPMP/sc_ref"),
                                ("KPMP_open_CKD_single_sample_matrices.csv", "data/KPMP/sc_ckd")]:
        frame = pd.read_csv(META / manifest)
        if "experimental_strategy" in frame.columns:
            frame = frame[frame["experimental_strategy"].astype(str).str.contains("Single-cell", na=False)]
        for _, row in frame.iterrows():
            participant = str(row["participants"])
            if participant in state_barcodes:
                jobs.append((str(row["file_id"]), participant, directory))
    print("matrix jobs:", len(jobs))

    with Pool(6) as pool:
        results = [r for r in pool.map(worker, jobs) if r]
    print("loaded matrices:", len(results))

    OUT.mkdir(parents=True, exist_ok=True)
    shared = sorted(set.intersection(*[set(r["genes"]) for r in results]))
    print("shared genes:", len(shared))
    (OUT / "genes.txt").write_text("\n".join(shared) + "\n")

    summary = []
    for state in STATES:
        rows, patients, cells = [], [], []
        for r in results:
            if state not in r["counts"]:
                continue
            counts, n_cells = r["counts"][state]
            idx = {g: i for i, g in enumerate(r["genes"])}
            rows.append(counts[[idx[g] for g in shared]])
            patients.append(r["participant"])
            cells.append(n_cells)
        if not rows:
            print("no data for", state)
            continue
        # 同一患者的多个文库在患者级求和（真正的患者级 pseudobulk）
        per_patient = {}
        for patient, counts, n_cells in zip(patients, rows, cells):
            if patient in per_patient:
                per_patient[patient][0] += counts
                per_patient[patient][1] += n_cells
            else:
                per_patient[patient] = [counts.astype(np.int64), n_cells]
        pids = sorted(per_patient)
        matrix = np.vstack([per_patient[p][0] for p in pids]).T
        mmwrite(OUT / f"{state.replace(' ', '_').replace('-', '')}_counts.mtx",
                sparse.csr_matrix(matrix.astype(np.int32)))
        pd.DataFrame({"patient": pids, "n_cells": [per_patient[p][1] for p in pids]}).to_csv(
            OUT / f"{state.replace(' ', '_').replace('-', '')}_samples.csv", index=False)
        summary.append({"state": state, "patients": len(pids), "total_cells": int(sum(cells))})

    # 样本元数据（分组 / 性别 / 年龄 / 分期）
    demo = pd.read_csv(META / "patient_demographics_consolidated.csv")
    demo = demo[demo["cohort"] == "sc"].set_index("patient")
    clinical = pd.read_csv(META / "20260930_OpenAccessClinicalData.csv", low_memory=False)
    clinical["pid"] = clinical["Participant ID"].astype(str).str.strip()
    stage = clinical.drop_duplicates("pid").set_index("pid")["KDIGO Stage"]
    groups = pt.groupby("patient")["condition.l2"].first()
    rows = []
    adaptive_samples = OUT / ("adaptive - epi".replace(" ", "_").replace("-", "") + "_samples.csv")
    for _, r in pd.read_csv(adaptive_samples).iterrows():
        patient = r["patient"]
        condition = groups.get(patient, "")
        rows.append({"patient": patient, "condition": condition,
                     "group": "AKI" if condition in ("AKI", "COV-AKI") else ("CKD" if condition in ("DKD", "H-CKD") else "Ref"),
                     "sex": demo["sex"].get(patient), "age": demo["age_num"].get(patient),
                     "kdigo": stage.get(patient), "n_cells": r["n_cells"]})
    pd.DataFrame(rows).to_csv(OUT / "sample_meta.csv", index=False)
    print("\n" + pd.DataFrame(summary).to_string(index=False))
    print("\nwrote", OUT)


if __name__ == "__main__":
    main()
