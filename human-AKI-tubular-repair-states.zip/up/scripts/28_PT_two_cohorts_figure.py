#!/usr/bin/env python3
"""Combined PT-level figure: KPMP scRNA-seq and GSE210622 snRNA-seq."""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = "/media/desk16/iy16128/comorbidity_analysis/aki_repair"
RES = f"{ROOT}/results"
FIG = f"{ROOT}/figures"

FEATURES = [
    ("injury_stress", "Injury/stress"),
    ("repair_progenitor", "Repair progenitor"),
    ("cycling", "Cycling"),
    ("reference_PT", "Reference state"),
]
COLORS = {"AKI": "#C0392B", "Ref": "#2874A6", "Control": "#2874A6"}


def panel(ax, table: pd.DataFrame, label_a: str, label_b: str, color_a: str, color_b: str,
          title: str) -> None:
    all_values = []
    for i, (feature, name) in enumerate(FEATURES, start=1):
        a = table.loc[table["group"] == label_a, feature].dropna()
        b = table.loc[table["group"] == label_b, feature].dropna()
        all_values.extend([a.max(), b.max(), a.min(), b.min()])
        pos = [(i - 1) * 2.4 + 1, (i - 1) * 2.4 + 2]
        bp = ax.boxplot([b, a], positions=pos, widths=0.6, patch_artist=True,
                        medianprops={"color": "black", "lw": 1.0})
        for patch, color in zip(bp["boxes"], [color_b, color_a]):
            patch.set_facecolor(color)
            patch.set_alpha(0.45)
        rng = np.random.default_rng(0)
        for position, values, color in zip(pos, [b, a], [color_b, color_a]):
            ax.scatter(np.full(len(values), position) + rng.uniform(-0.12, 0.12, len(values)),
                       values, s=13, color=color, zorder=3, linewidths=0)
        p = stats.mannwhitneyu(a, b).pvalue
        label = f"P={p:.3f}" if p >= 0.001 else "P<0.001"
        ax.text(np.mean(pos), max(a.max(), b.max()) + 0.06, label, ha="center", fontsize=7.5)
    low, high = min(all_values), max(all_values)
    pad = (high - low) * 0.12
    ax.set_ylim(low - pad, high + pad * 3)
    ax.set_xticks([(i - 1) * 2.4 + 1.5 for i in range(1, len(FEATURES) + 1)])
    ax.set_xticklabels([name for _, name in FEATURES], fontsize=8)
    ax.set_title(title, fontsize=9)
    ax.tick_params(axis="y", labelsize=8)


def main() -> None:
    kpmp = pd.read_csv(f"{RES}/KPMP_sc_PT_pseudobulk_patient.csv")
    kpmp = kpmp[kpmp["group"].isin(["AKI", "Ref"])]
    gse = pd.read_csv(f"{RES}/GSE210622_PT_pseudobulk.csv")
    gse["group"] = np.where(gse["group"] == "Control", "Ref", "AKI")

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6), sharey=False)
    panel(axes[0], kpmp, "AKI", "Ref", COLORS["AKI"], COLORS["Ref"],
          f"KPMP scRNA-seq (12 AKI vs 18 reference patients)")
    panel(axes[1], gse, "AKI", "Ref", COLORS["AKI"], COLORS["Ref"],
          f"GSE210622 snRNA-seq (8 AKI vs 6 control samples)")
    axes[0].set_ylabel("PT pseudobulk signature (z over expressed genes)")
    fig.suptitle("Proximal-tubule pseudobulk signatures in AKI versus controls", fontsize=10.5)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(f"{FIG}/Fig_PT_pseudobulk_two_cohorts.png", dpi=300)
    fig.savefig(f"{FIG}/Fig_PT_pseudobulk_two_cohorts.pdf")
    plt.close(fig)

    # tidy combined table
    combined = pd.concat([
        kpmp.assign(cohort="KPMP scRNA-seq", n_cells=kpmp["n_PT_cells"]),
        gse.assign(cohort="GSE210622 snRNA-seq", n_cells=gse["n_PT_cells"]),
    ], ignore_index=True)
    combined.to_csv(f"{RES}/PT_pseudobulk_two_cohorts.csv", index=False)
    print(combined.groupby(["cohort", "group"])["n_cells"].agg(["count", "sum"]).to_string())


if __name__ == "__main__":
    main()
