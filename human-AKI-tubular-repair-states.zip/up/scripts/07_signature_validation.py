#!/usr/bin/env python3
"""External validation of injury/repair signatures in bulk kidney and blood cohorts."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
URINE = ROOT / "data/UrineAKI_github"
VALID = ROOT / "data/validation"
RES = ROOT / "results"
FIG = ROOT / "figures"
RES.mkdir(exist_ok=True, parents=True)
FIG.mkdir(exist_ok=True, parents=True)

CLUSTER_SIGNATURES = {
    "repair_progenitor": ["TEC_prlf", "TEC_prg1", "TEC_prg2", "TEC_prg3", "TEC_prg4"],
    "injury_stress": ["TEC_dmg", "TEC_MMP7", "TEC_IL32", "TEC_LIF"],
    "reference_PT": ["PCT"],
}


def build_signatures(top_n: int = 40) -> dict[str, list[str]]:
    import subprocess
    script = f'''
    x <- readRDS("{URINE / 'DEG_kidney_urine_cells.rds'}")
    x <- x[x$p_val_adj < 0.05 & x$avg_log2FC > 0.5, ]
    write.csv(x, "{RES / 'Klocke_DEG_filtered.csv'}", row.names = FALSE)
    '''
    subprocess.run(["/usr/local/bin/Rscript", "-e", script], check=True, capture_output=True)
    deg = pd.read_csv(RES / "Klocke_DEG_filtered.csv")
    signatures: dict[str, list[str]] = {}
    rows = []
    for name, clusters in CLUSTER_SIGNATURES.items():
        subset = deg[deg["cluster"].isin(clusters)].sort_values("avg_log2FC", ascending=False)
        genes = list(dict.fromkeys(subset["gene"].astype(str)))
        genes = [g for g in genes if g and g != "nan"][:top_n]
        signatures[name] = genes
        for cluster in clusters:
            for gene in deg.loc[deg["cluster"] == cluster, "gene"].head(top_n):
                rows.append({"signature": name, "cluster": cluster, "gene": gene})
    pd.DataFrame(rows).to_csv(RES / "Klocke_signature_genes.csv", index=False)
    return signatures


def score_matrix(expr: pd.DataFrame, signatures: dict[str, list[str]]) -> pd.DataFrame:
    expr = np.log2(expr + 1)
    z = expr.sub(expr.mean(axis=1), axis=0).div(expr.std(axis=1).replace(0, np.nan), axis=0)
    scores = {}
    for name, genes in signatures.items():
        present = [g for g in genes if g in z.index]
        scores[f"{name}_score"] = z.loc[present].mean(axis=0) if len(present) >= 10 else np.nan
        scores[f"{name}_n_genes"] = len(present)
    return pd.DataFrame(scores)


def validate_kidney(signatures: dict[str, list[str]]) -> pd.DataFrame:
    expr = pd.read_csv(VALID / "GSE139061_Eadon_processed_QN_101419.csv.gz")
    expr = expr.set_index("Geneid")
    meta = pd.read_csv(VALID / "GSE139061_sample_metadata.csv")
    sample_cols = [c for c in expr.columns if c in set(meta["sample_id"]) or c in set(meta["title"].str.extract(r"\[(.*)\]")[0])]
    # Fall back to all expression columns when the metadata sample_id uses GSM names.
    if len(sample_cols) < 10:
        sample_cols = [c for c in expr.columns]
    expr = expr[sample_cols]
    scores = score_matrix(expr, signatures)
    scores["disease"] = ["AKI" if str(c).upper().startswith("AKI") else "Reference" for c in sample_cols]
    scores.to_csv(RES / "GSE139061_signature_scores.csv")

    rows = []
    for name in signatures:
        col = f"{name}_score"
        aki = scores.loc[scores["disease"] == "AKI", col].dropna()
        ref = scores.loc[scores["disease"] != "AKI", col].dropna()
        if len(aki) < 3 or len(ref) < 3:
            continue
        rows.append({
            "cohort": "GSE139061_kidney", "signature": name,
            "n_AKI": len(aki), "n_Ref": len(ref),
            "mean_AKI": aki.mean(), "mean_Ref": ref.mean(),
            "mannwhitney_p": stats.mannwhitneyu(aki, ref, alternative="two-sided").pvalue,
            "auc": stats.mannwhitneyu(aki, ref, alternative="greater").statistic / (len(aki) * len(ref)),
        })
    out = pd.DataFrame(rows)
    out.to_csv(RES / "GSE139061_signature_validation.csv", index=False)

    fig, axes = plt.subplots(1, len(signatures), figsize=(4 * len(signatures), 4))
    if len(signatures) == 1:
        axes = [axes]
    for ax, name in zip(axes, signatures):
        col = f"{name}_score"
        data = [scores.loc[scores["disease"] == "AKI", col].dropna(),
                scores.loc[scores["disease"] != "AKI", col].dropna()]
        ax.boxplot(data, labels=["AKI", "Reference"], widths=0.6, patch_artist=True,
                   boxprops=dict(facecolor="#AED6F1"), medianprops=dict(color="black"))
        ax.scatter(np.ones(len(data[0])) + np.random.uniform(-0.08, 0.08, len(data[0])), data[0],
                   s=10, color="#C0392B", alpha=0.7)
        ax.scatter(np.ones(len(data[1])) * 2 + np.random.uniform(-0.08, 0.08, len(data[1])), data[1],
                   s=10, color="#2874A6", alpha=0.7)
        ax.set_title(name.replace("_", " "), fontsize=10)
        ax.set_ylabel("Signature score (z)")
    fig.suptitle("Human kidney bulk transcriptome (GSE139061): AKI vs reference", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_GSE139061_signature_validation.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_GSE139061_signature_validation.pdf", bbox_inches="tight")
    plt.close(fig)
    return out


def validate_blood(signatures: dict[str, list[str]]) -> pd.DataFrame:
    obj = VALID / "comorbidity_analysis_objects.rds"
    import subprocess
    out = RES / "GSE67401_signature_scores.csv"
    script = f'''
    x <- readRDS("{obj}")
    expr <- x$expr_67401
    ph <- x$pheno_67401
    z <- t(scale(t(expr)))
    z[!is.finite(z)] <- 0
    sets <- read.csv("{RES / 'Klocke_signature_genes.csv'}")
    res <- data.frame(sample_id = colnames(expr), group = ph$group, stage = ph$aki_stage)
    for (sig in unique(sets$signature)) {{
      genes <- intersect(unique(sets$gene[sets$signature == sig]), rownames(z))
      res[[paste0(sig, "_score")]] <- if (length(genes) >= 10) colMeans(z[genes, , drop = FALSE]) else NA
      res[[paste0(sig, "_n")]] <- length(genes)
    }}
    write.csv(res, "{out}", row.names = FALSE)
    '''
    subprocess.run(["/usr/local/bin/Rscript", "-e", script], check=True, capture_output=True)
    scores = pd.read_csv(out)
    rows = []
    for name in signatures:
        col = f"{name}_score"
        if col not in scores:
            continue
        aki = scores.loc[scores["group"] == "SIRS_AKI", col].dropna()
        non = scores.loc[scores["group"] == "SIRS_nonAKI", col].dropna()
        stage = scores.loc[scores["stage"].isin(["AKI1", "AKI2_3"]), "stage"].map({"AKI1": 1, "AKI2_3": 2})
        stage_scores = scores.loc[scores["stage"].isin(["AKI1", "AKI2_3"]), col]
        rho, p = stats.spearmanr(stage, stage_scores, nan_policy="omit")
        rows.append({
            "cohort": "GSE67401_blood", "signature": name,
            "mean_AKI": aki.mean(), "mean_nonAKI": non.mean(),
            "mannwhitney_p": stats.mannwhitneyu(aki, non).pvalue,
            "spearman_rho_stage": rho, "spearman_p_stage": p,
        })
    out = pd.DataFrame(rows)
    out.to_csv(RES / "GSE67401_blood_signature_validation.csv", index=False)
    return out


def main() -> None:
    signatures = build_signatures()
    print("Signature sizes:", {k: len(v) for k, v in signatures.items()})
    kidney = validate_kidney(signatures)
    blood = validate_blood(signatures)
    print("\nKidney bulk validation (GSE139061):")
    print(kidney.to_string(index=False))
    print("\nBlood validation (GSE67401):")
    print(blood.to_string(index=False))


if __name__ == "__main__":
    main()
