#!/usr/bin/env python3
"""Export Visium counts and coordinates for RCTD (MatrixMarket + CSV)."""

from __future__ import annotations

import gzip
import importlib.util
import io
import json
from pathlib import Path

from scipy.io import mmwrite

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
SPATIAL = ROOT / "data/KPMP_spatial"
META = ROOT / "metadata"

spec = importlib.util.spec_from_file_location("spatial20", ROOT / "scripts/20_spatial_pilot_analysis.py")
spatial20 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(spatial20)


def main() -> None:
    pilot = json.loads((META / "kpmp_spatial_pilot_files.json").read_text())
    for patient in pilot["pilot"]:
        files = [f for f in pilot["files"] if f["patient"] == patient]
        expr = next((SPATIAL / patient / f["file_name"] for f in files if "Expression Matrix" in str(f["workflow_type"])), None)
        spat = next((SPATIAL / patient / f["file_name"] for f in files if "Spatial Imaging Data" in str(f["workflow_type"])), None)
        if not expr or not expr.exists() or not spat or not spat.exists():
            print(f"skip {patient}: files missing")
            continue
        outdir = SPATIAL / patient / "rctd_input"
        if (outdir / "counts.mtx").exists():
            print(f"exists {patient}")
            continue
        outdir.mkdir(parents=True, exist_ok=True)
        try:
            genes, barcodes, matrix = spatial20.read_visium(expr)
            positions = spatial20.read_positions(spat)
        except Exception as exc:
            print(f"skip {patient}: {exc}")
            continue
        keep = [b for b in positions["barcode"] if b in set(barcodes)]
        idx = {b: i for i, b in enumerate(barcodes)}
        cols = [idx[b] for b in keep]
        sub = matrix[:, cols].tocsc()
        mmwrite(outdir / "counts.mtx", sub)
        (outdir / "genes.txt").write_text("\n".join(genes) + "\n")
        (outdir / "barcodes.txt").write_text("\n".join(keep) + "\n")
        pos = positions.set_index("barcode").loc[keep]
        pos[["pxl_row", "pxl_col"]].to_csv(outdir / "coords.csv")
        print(f"{patient}: exported {sub.shape[0]} genes x {sub.shape[1]} spots")


if __name__ == "__main__":
    main()
