#!/usr/bin/env Rscript
# Add cycling signature scores to GSE67401 blood cohort (for severity meta-analysis).

suppressPackageStartupMessages({})

root <- "/media/desk16/iy16128/comorbidity_analysis/aki_repair"
obj <- readRDS(file.path(root, "data/validation/comorbidity_analysis_objects.rds"))
expr <- obj$expr_67401
ph <- obj$pheno_67401
sets <- read.csv(file.path(root, "results/Klocke_signature_genes.csv"))
cycling <- c("MKI67","TOP2A","CCNB1","CDK1","PTTG1","NUSAP1","BIRC5","CDC20","TPX2","CENPF","CCNA2","AURKB")

z <- t(scale(t(expr)))
z[!is.finite(z)] <- 0
score_set <- function(genes) {
  genes <- intersect(unique(genes), rownames(z))
  if (length(genes) < 8) return(rep(NA_real_, ncol(z)))
  colMeans(z[genes, , drop = FALSE])
}

scores <- list()
for (s in unique(sets$signature)) {
  scores[[s]] <- score_set(sets$gene[sets$signature == s])
}
scores[["cycling"]] <- score_set(cycling)

out <- data.frame(sample_id = colnames(expr), group = ph$group, stage = ph$aki_stage)
out <- cbind(out, as.data.frame(scores))
write.csv(out, file.path(root, "results/GSE67401_signature_scores_with_cycling.csv"), row.names = FALSE)
cat("saved results/GSE67401_signature_scores_with_cycling.csv\n")
cat("columns:", paste(colnames(out), collapse = ", "), "\n")
