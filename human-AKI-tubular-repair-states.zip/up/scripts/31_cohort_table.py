#!/usr/bin/env python3
"""Build the cohort characteristics table used in the manuscript (Table 1)."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
META = ROOT / "metadata"


def main() -> None:
    rows = []

    # KPMP sc / sn atlas
    for name, path, condition_col in [
        ("KPMP scRNA-seq (GSE183276)", ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz", "condition.l2"),
        ("KPMP snRNA-seq (GSE183277)", ROOT / "data/GSE183/GSE183277_Kidney_Healthy-Injury_Cell_Atlas_snCv3_Metadata_03282022.txt.gz", "condition.l2"),
    ]:
        meta = pd.read_csv(path, sep="\t", index_col=0, low_memory=False)
        grp = meta[condition_col].value_counts()
        patients = meta.groupby(condition_col)["patient"].nunique()
        rows.append({
            "cohort": name,
            "platform": "10x sc/sn RNA-seq",
            "n_samples_or_libraries": meta["library"].nunique() if "library" in meta else len(meta),
            "n_cells": len(meta),
            "groups": "; ".join(f"{k}: {patients.get(k, 0)} patients / {v:,} cells" for k, v in grp.items())
                      + ("; **分析口径：AKI 组 = AKI + COV-AKI 合并（n=10）**"
                         if "COV-AKI" in grp else ""),
            "use": "discovery (AKI vs Reference, PT states, KDIGO trend)",
        })

    pt = pd.read_csv(RES / "KPMP_sc_PT_pseudobulk_patient.csv")
    rows.append({
        "cohort": "KPMP scRNA-seq, PT-level",
        "platform": "10x scRNA-seq (per-sample matrices)",
        "n_samples_or_libraries": int(pt["n_libraries"].sum()),
        "n_cells": int(pt["n_PT_cells"].sum()),
        "groups": "; ".join(
            f"{label}: {len(grp)} patients / {int(grp['n_PT_cells'].sum()):,} PT cells"
            for label, grp in
            [("AKI", pt[pt["group"] == "AKI"]),
             ("CKD (DKD + H-CKD)", pt[pt["group"].isin(["DKD", "H-CKD"])]),
             ("Reference", pt[pt["group"] == "Ref"])] if len(grp)),
        "use": "primary cell-type-resolved comparison",
    })

    gse = pd.read_csv(RES / "GSE210622_PT_pseudobulk.csv")
    rows.append({
        "cohort": "GSE210622",
        "platform": "10x snRNA-seq (human kidney)",
        "n_samples_or_libraries": len(gse),
        "n_cells": int(gse["n_PT_cells"].sum()),
        "groups": (f"control: {int((gse['group'] == 'Control').sum())} samples; "
                   f"COVID-AKI: {int((gse['group'] == 'COVID').sum())}; "
                   f"non-COVID AKI: {int((gse['group'] == 'Non-COVID').sum())}; "
                   f"**{int(gse['n_PT_cells'].sum()):,} PT 细胞用于签名打分（队列合计 106,971 细胞）**"),
        "use": "independent replication (PT injury/repair)",
    })

    spatial = pd.read_csv(RES / "spatial_pilot_sample_scores.csv")
    stage_counts = spatial["stage"].value_counts().to_dict()
    rows.append({
        "cohort": "KPMP Visium",
        "platform": "10x Visium spatial transcriptomics",
        "n_samples_or_libraries": len(spatial),
        "n_cells": int(spatial["n_spots"].sum()),
        "groups": "; ".join(f"{k}: {v}" for k, v in sorted(stage_counts.items())),
        "use": "spatial localisation of injury/repair programmes + RCTD deconvolution",
    })

    rows.append({
        "cohort": "GSE139061 (Eadon)",
        "platform": "bulk RNA-seq (kidney biopsy)",
        "n_samples_or_libraries": 48,
        "n_cells": None,
        "groups": "39 AKI vs 9 reference",
        "use": "bulk-level signature validation",
    })
    rows.append({
        "cohort": "GSE67401",
        "platform": "blood transcriptome (SIRS/AKI)",
        "n_samples_or_libraries": 53,
        "n_cells": None,
        "groups": "SIRS with/without AKI",
        "use": "tissue-specificity control and KDIGO-stage meta-analysis",
    })
    urine = pd.read_csv(RES / "infection_AKI_urine_patient.csv")
    rows.append({
        "cohort": "Urine AKI cohort (GitHub)",
        "platform": "clinical + urine output/creatinine",
        "n_samples_or_libraries": len(urine),
        "n_cells": None,
        "groups": f"KDIGO 1-3; infection-associated {int((urine['infection'] == 'Infection-associated').sum())} vs "
                  f"non-infectious {int((urine['infection'] == 'Non-infectious').sum())}",
        "use": "clinical trajectory and infection-associated subgroup (exploratory)",
    })

    table = pd.DataFrame(rows)
    table.to_csv(RES / "TABLE1_cohort_characteristics.csv", index=False)
    print(table.to_string(index=False, max_colwidth=70))

    lines = ["# Table 1. Cohorts used in this study", "",
             "| Cohort | Platform | n | Cells/spots | Groups | Use |", "|---|---|---:|---:|---|---|"]
    for _, r in table.iterrows():
        cells = f"{int(r['n_cells']):,}" if pd.notna(r["n_cells"]) else "—"
        lines.append(f"| {r['cohort']} | {r['platform']} | {r['n_samples_or_libraries']} | {cells} | "
                     f"{r['groups']} | {r['use']} |")
    lines += ["", "**脚注**", "",
              "1. `Cells/spots` 列对 sc/sn 为细胞数、对 Visium 为 spot 数、对 bulk/blood 为样本数。",
              "2. GSE210622 行的 29,534 是**用于签名打分的 PT 细胞数**（队列合计 106,971 细胞、14 个样本）。",
              "3. KPMP sn 行中 AKI 与 COV-AKI 分开列出，**所有分析中合并为 AKI 组（n=10）**。",
              "4. KPMP sc 行的条件分组与 sn 相同口径：分析时 AKI 单独成组（无 COV-AKI）。"]
    (ROOT / "reports/TABLE1_cohort_characteristics.md").write_text("\n".join(lines) + "\n")
    # 补充：图像层队列的基线人口学（来自 reviewer baseline 表）
    baseline_path = RES / "reviewer_sc_baseline_table.csv"
    if baseline_path.exists():
        baseline = pd.read_csv(baseline_path)
        lines += ["", "## KPMP scRNA-seq 患者基线（患者水平）", "",
                  "| 组 | n | 女/男 | 年龄中位（可得/总） | eGFR 中位（可得/总） | KDIGO 1/2/3 |",
                  "|---|---:|---:|---:|---:|---:|"]
        for _, row in baseline.iterrows():
            age = f"{row['age_median']:.0f} ({row['age_available']}/{row['n_patients']})" if pd.notna(row["age_median"]) else "—"
            egfr = f"{row['egfr_median']:.0f} ({row['egfr_available']}/{row['n_patients']})" if pd.notna(row["egfr_median"]) else "—"
            lines.append(f"| {row['group']} | {row['n_patients']} | {row['sex_female']}/{row['sex_male']} | "
                         f"{age} | {egfr} | {row['kdigo_1']}/{row['kdigo_2']}/{row['kdigo_3']} |")
        lines += ["", "参考供肾者的年龄/性别来自开放临床表与 KPMP 仓库索引（规范化 ID 匹配，18/18 可得），eGFR 在参考组缺失。"]
        lines += ["", "**脚注**", "",
              "1. `Cells/spots` 列对 sc/sn 为细胞数、对 Visium 为 spot 数、对 bulk/blood 为样本数。",
              "2. GSE210622 行的 29,534 是**用于签名打分的 PT 细胞数**（队列合计 106,971 细胞、14 个样本）。",
              "3. KPMP sn 行中 AKI 与 COV-AKI 分开列出，**所有分析中合并为 AKI 组（n=10）**。",
              "4. KPMP sc 行的条件分组与 sn 相同口径：分析时 AKI 单独成组（无 COV-AKI）。"]
    (ROOT / "reports/TABLE1_cohort_characteristics.md").write_text("\n".join(lines) + "\n")

    print("\nwrote reports/TABLE1_cohort_characteristics.md")


if __name__ == "__main__":
    main()
