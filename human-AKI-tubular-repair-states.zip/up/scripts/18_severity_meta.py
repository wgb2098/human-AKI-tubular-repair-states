#!/usr/bin/env python3
"""Cross-cohort KDIGO stage-trend meta-analysis (patient-level).

Cohorts:
  - KPMP sc pseudobulk (kidney tissue, staged AKI patients)
  - GSE67401 blood signatures (SIRS AKI stage 1 vs 2/3)

The KPMP sc sample-level table contains multiple libraries per patient, so
scores are aggregated to participant level before the trend test.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
FIG = ROOT / "figures"
SIGNATURES = ["cycling", "injury_stress", "repair_progenitor", "reference_PT"]
LABELS = {
    "cycling": "Cycling",
    "injury_stress": "Injury / stress",
    "repair_progenitor": "Repair / progenitor",
    "reference_PT": "Reference PT",
}


def kpmp_sc_patient_level() -> pd.DataFrame:
    table = pd.read_csv(RES / "KPMP_sc_pseudobulk_signatures.csv")
    stage = pd.to_numeric(table["stage"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
    table = table.assign(stage_num=stage)
    table = table.dropna(subset=["stage_num"])
    rows = []
    for participant, group in table.groupby("participant"):
        weights = group["n_cells"].astype(float)
        row = {"participant": participant, "stage_num": int(group["stage_num"].iloc[0]),
               "n_libraries": len(group), "n_cells": int(weights.sum())}
        for sig in SIGNATURES:
            col = f"{sig}_score"
            if col in group:
                vals = pd.to_numeric(group[col], errors="coerce")
                valid = vals.notna()
                row[sig] = np.average(vals[valid], weights=weights[valid]) if valid.any() else np.nan
        rows.append(row)
    out = pd.DataFrame(rows)
    print(f"KPMP sc: {len(table)} libraries -> {len(out)} patients")
    print(out[["participant", "stage_num", "n_libraries"]].to_string(index=False))
    return out


def blood_patient_level() -> pd.DataFrame:
    table = pd.read_csv(RES / "GSE67401_signature_scores_with_cycling.csv")
    table = table[table["stage"].isin(["AKI1", "AKI2_3"])].copy()
    table["stage_num"] = table["stage"].map({"AKI1": 1, "AKI2_3": 2})
    print(f"GSE67401 blood: {len(table)} staged samples")
    return table


def fisher_z_meta(rows: list[dict]) -> dict:
    zs, ses, weights = [], [], []
    for r in rows:
        n = r["n"]
        if n <= 3 or not np.isfinite(r["rho"]):
            continue
        z = np.arctanh(np.clip(r["rho"], -0.999, 0.999))
        zs.append(z); ses.append(1 / np.sqrt(n - 3))
    if len(zs) < 2:
        return {"pooled_rho": np.nan, "pooled_p": np.nan, "I2": np.nan}
    zs = np.asarray(zs); ses = np.asarray(ses)
    w = 1 / ses ** 2
    z_fixed = np.sum(w * zs) / np.sum(w)
    q = np.sum(w * (zs - z_fixed) ** 2)
    c = np.sum(w) - np.sum(w ** 2) / np.sum(w)
    tau2 = max(0.0, (q - (len(zs) - 1)) / c) if c > 0 else 0.0
    wr = 1 / (ses ** 2 + tau2)
    z_pool = np.sum(wr * zs) / np.sum(wr)
    se_pool = 1 / np.sqrt(np.sum(wr))
    p_pool = 2 * stats.norm.sf(abs(z_pool / se_pool))
    i2 = max(0.0, (q - (len(zs) - 1)) / q) * 100 if q > 0 else 0.0
    return {
        "pooled_rho": np.tanh(z_pool), "pooled_p": p_pool, "I2": i2,
        "z_pool": z_pool, "se_pool": se_pool, "Q": q,
    }


def main() -> None:
    sc = kpmp_sc_patient_level()
    blood = blood_patient_level()

    rows = []
    forest = []
    for sig in SIGNATURES:
        cohort_rows = []
        # KPMP sc
        if sig in sc.columns:
            data = sc[["stage_num", sig]].dropna()
            if len(data) >= 5 and data["stage_num"].nunique() >= 2:
                rho, p = stats.spearmanr(data["stage_num"], data[sig])
                cohort_rows.append({"cohort": "KPMP sc (kidney)", "signature": sig,
                                    "n": len(data), "rho": rho, "p": p})
        # GSE67401 blood
        if sig in blood.columns:
            data = blood[["stage_num", sig]].dropna()
            if len(data) >= 5 and data["stage_num"].nunique() >= 2:
                rho, p = stats.spearmanr(data["stage_num"], data[sig])
                cohort_rows.append({"cohort": "GSE67401 (blood)", "signature": sig,
                                    "n": len(data), "rho": rho, "p": p})
        meta = fisher_z_meta(cohort_rows)
        for r in cohort_rows:
            forest.append(r)
        rows.append({
            "signature": sig,
            **{f"{r['cohort']}_rho": r["rho"] for r in cohort_rows},
            **{f"{r['cohort']}_p": r["p"] for r in cohort_rows},
            **{f"{r['cohort']}_n": r["n"] for r in cohort_rows},
            "n_cohorts": len(cohort_rows),
            **meta,
        })
    result = pd.DataFrame(rows)
    result.to_csv(RES / "severity_meta_analysis.csv", index=False)

    # Forest plot
    fig, ax = plt.subplots(figsize=(8, 4.5))
    y = 0
    yticks, ylabels = [], []
    colors = {"KPMP sc (kidney)": "#2874A6", "GSE67401 (blood)": "#C0392B"}
    for sig in SIGNATURES:
        sub = [r for r in forest if r["signature"] == sig]
        for r in sub:
            ax.scatter(r["rho"], y, color=colors[r["cohort"]], s=30)
            ax.plot([r["rho"] - 0.3, r["rho"] + 0.3], [y, y], color=colors[r["cohort"]], lw=1, alpha=0.4)
            yticks.append(y); ylabels.append(f"{LABELS[sig]} | {r['cohort']}")
            y += 1
        meta = result[result["signature"] == sig].iloc[0]
        if np.isfinite(meta["pooled_rho"]):
            ax.scatter(meta["pooled_rho"], y, marker="D", color="black", s=35)
            ax.plot([meta["pooled_rho"] - 1.96 * meta["se_pool"] / 2,
                     meta["pooled_rho"] + 1.96 * meta["se_pool"] / 2], [y, y], color="black", lw=1.5)
            yticks.append(y); ylabels.append(f"{LABELS[sig]} | pooled (p={meta['pooled_p']:.3f})")
            y += 1
        y += 0.5
    ax.axvline(0, color="grey", ls="--", lw=1)
    ax.set_yticks(yticks); ax.set_yticklabels(ylabels, fontsize=8)
    ax.set_xlabel("Spearman rho (KDIGO stage trend)")
    ax.set_title("Cross-cohort KDIGO severity trend (patient level)")
    ax.set_xlim(-0.8, 0.8)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_severity_meta_forest.png", dpi=300)
    fig.savefig(FIG / "Fig_severity_meta_forest.pdf")
    plt.close(fig)

    print("\nSeverity meta-analysis:")
    print(result.to_string(index=False))

    sn_tests = pd.read_csv(RES / "KPMP_sn_PT_state_tests.csv")
    print("\nKPMP sn PT-state trends (supplementary, patient level):")
    cols = ["cohort", "feature", "n_AKI_samples", "spearman_rho_stage", "spearman_p_stage"]
    print(sn_tests[[c for c in cols if c in sn_tests.columns]].to_string(index=False))


if __name__ == "__main__":
    main()
