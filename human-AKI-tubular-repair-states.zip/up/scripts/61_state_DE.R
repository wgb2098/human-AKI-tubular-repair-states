#!/usr/bin/env Rscript
# State-specific differential expression (patient-level pseudobulk): AKI vs CKD,
# AKI vs Reference and CKD vs Reference within adaptive, degenerative and
# reference PT states. edgeR quasi-likelihood with sex as covariate.

suppressPackageStartupMessages({
  library(edgeR)
  library(Matrix)
})

root <- "/media/desk16/iy16128/comorbidity_analysis/aki_repair"
dir <- file.path(root, "data/state_pseudobulk")
out <- file.path(root, "results")

genes <- readLines(file.path(dir, "genes.txt"))
meta <- read.csv(file.path(dir, "sample_meta.csv"), stringsAsFactors = FALSE)
meta$sex <- factor(meta$sex)
states <- c("adaptive__epi", "degenerative", "reference")
contrasts <- list(AKI_vs_CKD = c("AKI", "CKD"),
                  AKI_vs_Ref = c("AKI", "Ref"),
                  CKD_vs_Ref = c("CKD", "Ref"))

summary_rows <- list()
model_compare <- list()
for (state in states) {
  counts <- as.matrix(Matrix::readMM(file.path(dir, paste0(state, "_counts.mtx"))))
  samples <- read.csv(file.path(dir, paste0(state, "_samples.csv")), stringsAsFactors = FALSE)
  rownames(counts) <- genes
  colnames(counts) <- samples$patient
  idx <- match(colnames(counts), meta$patient)
  if (any(is.na(idx))) stop("样本元数据缺失: ", paste(colnames(counts)[is.na(idx)], collapse = ","))
  md <- data.frame(patient = colnames(counts), n_cells = samples$n_cells[match(colnames(counts), samples$patient)],
                   group = meta$group[idx], sex = meta$sex[idx], age = meta$age[idx], stringsAsFactors = FALSE)
  md$sex <- factor(md$sex)
  use_sex <- !any(is.na(md$sex)) && length(unique(md$sex)) > 1
  if (!use_sex) { message("  性別信息不完整或单一，设计矩阵只用 group"); md$sex <- factor(rep("U", nrow(md))) }

  message(sprintf("\n== %s: %d patients (%s), %d genes", state, ncol(counts),
                  paste(names(table(md$group)), table(md$group), sep = "=", collapse = " "), nrow(counts)))
  if (min(table(md$group)) < 5) { message("  组样本不足，跳过"); next }

  keep <- filterByExpr(counts, group = md$group)
  dge <- DGEList(counts = counts[keep, ], group = md$group)
  dge <- calcNormFactors(dge)
  use_age <- !any(is.na(md$age)) && length(unique(md$age)) > 3
  models <- list(sex = if (use_sex) "sex" else NULL,
                 sex_age = if (use_sex && use_age) c("sex", "age") else NULL)
  results <- list()
  for (model_name in names(models)) {
    covariates <- models[[model_name]]
    if (is.null(covariates)) next
    formula <- as.formula(paste("~ 0 + group +", paste(covariates, collapse = " + ")))
    design <- model.matrix(formula, data = md)
    colnames(design) <- sub("^group", "", colnames(design))
    dge_m <- estimateDisp(dge, design)
    fit <- glmQLFit(dge_m, design, robust = TRUE)
    for (cname in names(contrasts)) {
      pair <- contrasts[[cname]]
      if (!all(pair %in% md$group)) next
      if (min(table(md$group)[pair]) < 5) next
      con <- makeContrasts(contrasts = paste(pair[1], "-", pair[2]), levels = design)
      qlf <- glmQLFTest(fit, contrast = con)
      tab <- topTags(qlf, n = Inf, sort.by = "PValue")$table
      tab$gene <- rownames(tab)
      tab <- tab[, c("gene", "logFC", "logCPM", "F", "PValue", "FDR")]
      suffix <- if (model_name == "sex") "" else paste0("_", model_name)
      write.csv(tab, file.path(out, sprintf("state_DE_%s_%s%s.csv", state, cname, suffix)), row.names = FALSE)
      results[[paste(model_name, cname)]] <- tab
      n_sig <- sum(tab$FDR < 0.05)
      n_up <- sum(tab$FDR < 0.05 & tab$logFC > 0)
      message(sprintf("  [%s] %s: %d DE genes (FDR<0.05), %d up in %s", model_name, cname, n_sig, n_up, pair[1]))
      summary_rows[[length(summary_rows) + 1]] <- data.frame(
        state = state, contrast = cname, model = model_name,
        n_patients_a = sum(md$group == pair[1]), n_patients_b = sum(md$group == pair[2]),
        n_genes_tested = nrow(tab), n_DE = n_sig, n_up_in_a = n_up,
        top_gene = tab$gene[which.min(tab$FDR)], top_logFC = tab$logFC[which.min(tab$FDR)],
        top_FDR = min(tab$FDR))
    }
  }
  # 两模型一致性
  for (cname in names(contrasts)) {
    key_sex <- paste("sex", cname); key_age <- paste("sex_age", cname)
    if (!is.null(results[[key_sex]]) && !is.null(results[[key_age]])) {
      a <- results[[key_sex]]; b <- results[[key_age]]
      merged <- merge(a[, c("gene", "logFC", "FDR")], b[, c("gene", "logFC", "FDR")],
                      by = "gene", suffixes = c("_sex", "_age"))
      rho <- cor(merged$logFC_sex, merged$logFC_age, method = "spearman")
      overlap <- length(intersect(a$gene[a$FDR < 0.05], b$gene[b$FDR < 0.05]))
      model_compare[[length(model_compare) + 1]] <- data.frame(
        state = state, contrast = cname,
        n_DE_sex = sum(a$FDR < 0.05), n_DE_sex_age = sum(b$FDR < 0.05),
        n_DE_overlap = overlap, spearman_logFC = rho,
        n_DE_sex_only = sum(a$FDR < 0.05) - overlap,
        n_DE_age_only = sum(b$FDR < 0.05) - overlap)
    }
  }
}
summary <- do.call(rbind, summary_rows)
write.csv(summary, file.path(out, "state_DE_summary.csv"), row.names = FALSE)
comp <- do.call(rbind, model_compare)
write.csv(comp, file.path(out, "state_DE_model_comparison.csv"), row.names = FALSE)
cat("\n== 汇总（含 sex 与 sex+age 两套模型）==\n")
print(summary, row.names = FALSE)
cat("\n== 两模型一致性 ==\n")
print(comp, row.names = FALSE)
