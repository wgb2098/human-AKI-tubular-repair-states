#!/usr/bin/env python3
"""③ 聚焦版细胞互作：PT 来源配体 → 免疫细胞受体（AKI vs CKD vs Reference）。

不做全库 CellChat，只检验一个预设假设：**适应性/损伤 PT 细胞分泌的配体在 AKI 中升高，
并与其免疫细胞受体的表达和免疫浸润程度同步**。全部为患者级统计。

数据：`data/celltype_pseudobulk/`（PT / IMM 患者级 pseudobulk，由 scripts/63 导出）。
空间部分复用 Visium spot 打分表（配体分 vs 免疫 marker 分的 spot 水平相关 + 邻域加权）。
"""

from __future__ import annotations

import gzip
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.io import mmread
from scipy.spatial import cKDTree
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
CELLTYPE = ROOT / "data/celltype_pseudobulk"
RES = ROOT / "results"
META = ROOT / "metadata"
REPORTS = ROOT / "reports"

# 预设配体-受体面板（配体来自 PT，受体在免疫细胞）
LR_PAIRS = [
    ("SPP1", ["CD44", "ITGB1", "ITGAV"]),
    ("MIF", ["CD74", "CXCR4", "CD44"]),
    ("ANXA1", ["FPR1", "FPR2"]),
    ("CXCL12", ["CXCR4"]),
    ("CCL2", ["CCR2"]),
    ("VEGFA", ["KDR", "FLT1"]),
    ("MDK", ["SDC4", "NCL", "PTPRZ1"]),
    ("LCN2", ["SLC22A17"]),
    # galectin-1 的经典结合伙伴：CD45(PTPRC)、β1 整合素、neuropilin-1（CD69 不是其受体，已更正）
    ("LGALS1", ["PTPRC", "ITGB1", "NRP1"]),
    ("TIMP1", ["CD63"]),
]
SIGNATURES_OF_INTEREST = ["injury_stress", "repair_progenitor", "reference_PT", "aPT_markers"]


def load_counts(name: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    genes = (CELLTYPE / "genes.txt").read_text().split("\n")
    genes = [g for g in genes if g]
    mat = mmread(CELLTYPE / f"{name}_counts.mtx").tocsr()
    samples = pd.read_csv(CELLTYPE / f"{name}_samples.csv")
    lib = np.asarray(mat.sum(axis=0)).ravel()
    cpm = np.asarray(mat.todense(), dtype=np.float64) / np.maximum(lib, 1) * 1e6
    frame = pd.DataFrame(np.log2(cpm + 1), index=genes, columns=samples["patient"].astype(str))
    frame = frame[~frame.index.duplicated(keep="first")]
    return frame, samples


def zscore(frame: pd.DataFrame) -> pd.DataFrame:
    return frame.sub(frame.mean(axis=1), axis=0).div(frame.std(axis=1).replace(0, np.nan), axis=0)


def main() -> None:
    pt, pt_samples = load_counts("PT")
    imm, imm_samples = load_counts("IMM")
    print(f"PT pseudobulk: {pt.shape[1]} 患者 | IMM: {imm.shape[1]} 患者")

    meta = pd.read_csv(ROOT / "data/state_pseudobulk/sample_meta.csv") if (ROOT / "data/state_pseudobulk/sample_meta.csv").exists() else None
    demo = pd.read_csv(META / "patient_demographics_consolidated.csv")
    demo = demo[demo["cohort"] == "sc"].set_index("patient")
    cellmeta = pd.read_csv(ROOT / "data/GSE183/GSE183276_Kidney_Healthy-Injury_Cell_Atlas_scCv3_Metadata_03282022.txt.gz",
                           sep="\t", index_col=0, low_memory=False, usecols=["patient", "condition.l2"])
    group = cellmeta.groupby("patient")["condition.l2"].first()
    groups = {p: ("AKI" if c in ("AKI", "COV-AKI") else "CKD" if c in ("DKD", "H-CKD") else "Ref")
              for p, c in group.items()}

    common = sorted(set(pt.columns) & set(imm.columns))
    print(f"两表共有患者: {len(common)}")

    pt_z, imm_z = zscore(pt[common]), zscore(imm[common])
    rows = []
    for ligand, receptors in LR_PAIRS:
        if ligand not in pt_z.index:
            continue
        present = [r for r in receptors if r in imm_z.index]
        if not present:
            continue
        lig = pt_z.loc[ligand]
        rec = imm_z.loc[present].mean(axis=0)
        score = lig * rec
        for patient in common:
            rows.append({"patient": patient, "group": groups.get(patient, "?"), "ligand": ligand,
                         "receptor_set": "+".join(present), "ligand_z": lig[patient],
                         "receptor_z": rec[patient], "LR_score": score[patient],
                         "receptor_genes_present": len(present)})
    lr = pd.DataFrame(rows)
    lr.to_csv(RES / "cellcomm_LR_scores.csv", index=False)

    # 患者级：AKI vs CKD / AKI vs Ref
    tests = []
    for (ligand, receptor_set), group_df in lr.groupby(["ligand", "receptor_set"]):
        a = group_df.loc[group_df.group == "AKI", "LR_score"].dropna()
        b = group_df.loc[group_df.group == "CKD", "LR_score"].dropna()
        c = group_df.loc[group_df.group == "Ref", "LR_score"].dropna()
        row = {"ligand": ligand, "receptor_set": receptor_set,
               "n_AKI": len(a), "n_CKD": len(b), "n_Ref": len(c),
               "median_AKI": a.median(), "median_CKD": b.median(), "median_Ref": c.median()}
        if len(a) >= 5 and len(b) >= 5:
            row["p_AKI_vs_CKD"] = stats.mannwhitneyu(a, b).pvalue
        if len(a) >= 5 and len(c) >= 5:
            row["p_AKI_vs_Ref"] = stats.mannwhitneyu(a, c).pvalue
        tests.append(row)
    tests = pd.DataFrame(tests)
    for col in ("p_AKI_vs_CKD", "p_AKI_vs_Ref"):
        if col in tests:
            tests[f"fdr_{col}"] = multipletests(tests[col].fillna(1), method="fdr_bh")[1]
    tests.to_csv(RES / "cellcomm_LR_tests.csv", index=False)
    print("\n配体-受体打分（患者级, AKI vs CKD / Ref）:")
    print(tests.round(4).to_string(index=False))

    # 与免疫浸润程度、PT 签名的一致性
    comp = pd.read_csv(RES / "KPMP_sc_sample_composition_scores.csv")
    imm_frac = (comp.groupby("patient")
                .apply(lambda g: np.average(g["frac_sub_IMM"].astype(float),
                                            weights=g["n_cells"].astype(float)))
                .rename("immune_fraction"))
    pt_sig_path = RES / "KPMP_sc_PT_pseudobulk_patient.csv"
    link_rows = []
    if pt_sig_path.exists():
        pt_sig = pd.read_csv(pt_sig_path).set_index("participant")
        for (ligand, receptor_set), group_df in lr.groupby(["ligand", "receptor_set"]):
            merged = group_df.set_index("patient").join(
                imm_frac, how="inner").join(pt_sig[["injury_stress", "repair_progenitor", "aPT_markers"]], how="inner")
            if len(merged) >= 10:
                rho_imm, p_imm = stats.spearmanr(merged["LR_score"], merged["immune_fraction"], nan_policy="omit")
                rho_inj, p_inj = stats.spearmanr(merged["LR_score"], merged["injury_stress"], nan_policy="omit")
                rho_apt, p_apt = stats.spearmanr(merged["LR_score"], merged["aPT_markers"], nan_policy="omit")
                link_rows.append({"ligand": ligand, "receptor_set": receptor_set, "n": len(merged),
                                  "rho_vs_immune_fraction": rho_imm, "p_vs_immune_fraction": p_imm,
                                  "rho_vs_PT_injury": rho_inj, "p_vs_PT_injury": p_inj,
                                  "rho_vs_aPT_markers": rho_apt, "p_vs_aPT_markers": p_apt})
    links = pd.DataFrame(link_rows)
    if len(links):
        links.to_csv(RES / "cellcomm_LR_links.csv", index=False)
        print("\nLR 分与免疫浸润 / PT 签名的一致性（患者级）:")
        print(links.round(4).to_string(index=False))

    # 空间：配体 vs 免疫 marker 的 spot 水平共定位（含邻域加权）
    spot_path = RES / "spatial_pilot_spot_scores.csv.gz"
    geom_path = ROOT / "data/KPMP_spatial"
    if spot_path.exists():
        spots = pd.read_csv(spot_path)
        spatial_rows = []
        for patient, group_df in spots.groupby("patient"):
            coords_file = geom_path / patient / "rctd_input" / "coords.csv"
            if not coords_file.exists():
                continue
            coords = pd.read_csv(coords_file, index_col=0)
            group_df = (group_df.drop(columns=[c for c in ("pxl_col", "pxl_row") if c in group_df.columns])
                        .set_index("barcode").join(coords[["pxl_col", "pxl_row"]], how="inner"))
            if len(group_df) < 50:
                continue
            tree = cKDTree(group_df[["pxl_col", "pxl_row"]].to_numpy(float))
            _, idx = tree.query(group_df[["pxl_col", "pxl_row"]].to_numpy(float), k=7)
            idx = idx[:, 1:]
            immune = group_df["marker_immune"].to_numpy(float)
            neighbour_immune = np.nanmean(immune[idx], axis=1)
            # 配体表达需要回到 Visium 矩阵（spot 表只有签名分）
            instr = geom_path / patient / "rctd_input"
            genes_file, mtx_file = instr / "genes.txt", instr / "counts.mtx"
            if not (genes_file.exists() and mtx_file.exists()):
                continue
            genes = genes_file.read_text().split()
            mat = mmread(mtx_file).tocsc()
            barcodes = (instr / "barcodes.txt").read_text().split()
            gene_index = {}
            for i, g in enumerate(genes):
                gene_index.setdefault(g, i)
            lib = np.asarray(mat.sum(axis=0)).ravel()
            order = [barcodes.index(b) for b in group_df.index if b in barcodes]
            if len(order) < 50:
                continue
            sub = mat[:, order]
            sub_lib = lib[order]
            dense_like = sub.toarray().astype(np.float64)
            lognorm = np.log2(dense_like / np.maximum(sub_lib, 1) * 1e4 + 1)
            for ligand, _ in LR_PAIRS:
                if ligand not in gene_index:
                    continue
                row = lognorm[gene_index[ligand]]
                values = (row - row.mean()) / (row.std() if row.std() else 1)
                rho, p = stats.spearmanr(values, neighbour_immune[: len(values)], nan_policy="omit")
                spatial_rows.append({"patient": patient, "stage": group_df["stage"].iloc[0],
                                     "ligand": ligand, "rho_ligand_vs_neighbour_immune": rho, "p": p})
        spatial = pd.DataFrame(spatial_rows)
        if len(spatial):
            spatial.to_csv(RES / "cellcomm_spatial_ligand_immune.csv", index=False)
            summary = (spatial.groupby("ligand")
                       .agg(n_sections=("rho_ligand_vs_neighbour_immune", "count"),
                            median_rho=("rho_ligand_vs_neighbour_immune", "median"))
                       .reset_index().sort_values("median_rho", ascending=False))
            print("\n空间：配体表达 vs 邻近 spot 免疫 marker（16 例中位 rho）:")
            print(summary.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
