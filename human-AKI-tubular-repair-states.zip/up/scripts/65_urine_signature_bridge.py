#!/usr/bin/env python3
"""② 尿液桥梁：在尿液肾小管上皮细胞中量化同一套损伤/修复程序，并关联临床。

设计（避免循环性主张）：签名源自本数据集（Klocke et al.），因此本分析**不做独立性主张**，
只回答"同一程序能否在尿液细胞中被量化，且其评分是否与临床严重度/恢复同步"。

样本：GSE199321 全部 37 套矩阵（43 例单患者样本 + 6 个池化样本，池化按 4 个 hashing 标签去卷积）。
"""

from __future__ import annotations

import gzip
import io
import re
import sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.io import mmread
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
GEO = ROOT / "data/UrineAKI_GEO"
GITHUB = ROOT / "data/UrineAKI_github"
RES = ROOT / "results"

MIN_UMI = 200
MIN_GENES = 100

PT_MARKERS = ["SLC34A1", "CUBN", "LRP2", "SLC22A8", "SLC5A12", "GPX3", "MIOX", "SLC22A6", "SLC22A12"]
TAL_MARKERS = ["UMOD", "SLC12A1", "KCNJ1", "CLDN16"]
DC_MARKERS = ["AQP2", "AQP3", "CALB1", "SLC12A3"]
IMMUNE_MARKERS = ["PTPRC", "CD3E", "MS4A1", "LYZ", "CD14"]
URO_MARKERS = ["UPK1B", "UPK2", "KRT13", "KRT5"]
CYCLING_12 = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20",
              "TPX2", "CENPF", "CCNA2", "AURKB"]
APT_MARKERS = ["VCAM1", "SPP1", "LTF", "MMP7", "HAVCR1", "CD24", "PROM1", "SOX9", "KRT7", "KRT19"]
SIGNATURES = ["injury_stress", "repair_progenitor", "reference_PT", "cycling", "aPT_markers"]
TAGS = ["CD298B0251", "CD298B0252", "CD298B0253", "CD298B0254"]
G: dict = {}


def read_gz(path: Path) -> bytes:
    data = path.read_bytes()
    return gzip.decompress(data) if path.name.endswith(".gz") else data


def sample_files(sample: str) -> dict[str, Path]:
    out = {}
    for path in GEO.glob(f"GSM*_{sample}_*.gz"):
        m = re.match(r"GSM\d+_(.+)[._](barcodes|features|matrix)\.(tsv|mtx)\.gz$", path.name)
        if m:
            out[m.group(2)] = path
    return out


def worker(sample: str) -> pd.DataFrame | None:
    files = sample_files(sample)
    if len(files) < 3:
        return None
    try:
        features = pd.read_csv(io.BytesIO(read_gz(files["features"])), sep="\t", header=None)
        genes = features.iloc[:, 1].astype(str).tolist() if features.shape[1] > 1 else features.iloc[:, 0].astype(str).tolist()
        barcodes = read_gz(files["barcodes"]).decode(errors="replace").split()
        mat = mmread(io.BytesIO(read_gz(files["matrix"]))).tocsr()
    except Exception as exc:
        print("skip", sample, exc)
        return None
    if mat.shape[0] != len(genes):
        genes = genes[: mat.shape[0]]
    totals = np.asarray(mat.sum(axis=0)).ravel()
    ngenes = np.asarray((mat > 0).sum(axis=0)).ravel()
    keep = (totals >= MIN_UMI) & (ngenes >= MIN_GENES)
    mat, barcodes = mat[:, keep], [b for b, k in zip(barcodes, keep) if k]
    if mat.shape[1] < 30:
        return None
    lib = np.asarray(mat.sum(axis=0)).ravel()
    norm = mat.astype(np.float32).tocsc()
    norm.data = np.log2(norm.data / np.repeat(lib, np.diff(norm.indptr)) * 1e4 + 1)
    norm = norm.tocsr()
    gene_index = {g: i for i, g in enumerate(genes)}
    # 每个基因在所有细胞上 z 标准化（与空间分析同一口径）
    mean = np.asarray(norm.mean(axis=1)).ravel()
    sq = np.asarray(norm.multiply(norm).mean(axis=1)).ravel()
    sd = np.sqrt(np.maximum(sq - mean ** 2, 0))
    z = norm.tocsr(copy=True)
    z.data = (z.data - np.repeat(mean, np.diff(z.indptr))) / np.maximum(np.repeat(sd, np.diff(z.indptr)), 1e-9)
    z = z.tocsc()

    def score(genes_list: list[str]) -> np.ndarray:
        rows = [gene_index[g] for g in genes_list if g in gene_index]
        if len(rows) < 5:
            return np.zeros(z.shape[1])
        return np.asarray(z[rows, :].mean(axis=0)).ravel()

    marker_scores = {
        "PT": score(PT_MARKERS), "TAL": score(TAL_MARKERS), "DC": score(DC_MARKERS),
        "IMM": score(IMMUNE_MARKERS), "URO": score(URO_MARKERS),
    }
    tube = np.vstack([marker_scores["PT"], marker_scores["TAL"], marker_scores["DC"]])
    best = tube.argmax(axis=0)
    is_tec = tube.max(axis=0) > np.maximum(marker_scores["IMM"], marker_scores["URO"]) + 0.3
    is_pt = is_tec & (best == 0)
    out = pd.DataFrame({"sample": sample, "barcode": barcodes,
                        "umi": lib, "is_tec": is_tec, "is_pt": is_pt})
    for name in SIGNATURES:
        out[name] = score(G.get("signatures")[name])
    for name, values in marker_scores.items():
        out[f"marker_{name}"] = values
    # 池化样本：按 hashing 标签分配患者
    pooled = sample.startswith("Pool")
    if pooled:
        tag_rows = [gene_index[t] for t in TAGS if t in gene_index]
        if len(tag_rows) == 4:
            raw = np.asarray(mat[tag_rows, :].todense())
            counts = raw.sum(axis=1, keepdims=True)
            frac = raw / np.maximum(counts, 1)
            assign = frac.argmax(axis=0)
            ok = frac.max(axis=0) >= 0.5
            out["tag"] = [TAGS[a] if o else None for a, o in zip(assign, ok)]
        else:
            out["tag"] = None
    return out


def main() -> None:
    sig = pd.read_csv(RES / "Klocke_signature_genes.csv")
    signatures = {name: sorted(set(g["gene"].astype(str))) for name, g in sig.groupby("signature")}
    signatures["cycling"] = CYCLING_12
    signatures["aPT_markers"] = APT_MARKERS
    G["signatures"] = signatures

    pattern = re.compile(r"GSM\d+_(.+)[._](barcodes|features|matrix)\.(tsv|mtx)\.gz$")
    samples = sorted({m.group(1) for p in GEO.glob("GSM*_*.gz")
                      for m in [pattern.match(p.name)] if m})
    print("样本数:", len(samples))
    with Pool(6) as pool:
        frames = [f for f in pool.map(worker, samples) if f is not None]
    cells = pd.concat(frames, ignore_index=True)

    # 池化样本 -> 患者映射（hashing 标签）
    barcode_list = pd.read_csv(GITHUB / "Urine_AKI_barcode_list.csv", sep=";")
    barcode_list.columns = [c.strip() for c in barcode_list.columns]
    pool_map = {}
    for _, row in barcode_list.iterrows():
        pool = row["Barcode"] if "Barcode" in row else row.iloc[0]
        for tag in TAGS:
            if tag in row and pd.notna(row[tag]):
                pool_map[(pool, tag)] = str(row[tag])
    def resolve(row):
        if not row["sample"].startswith("Pool"):
            return row["sample"]
        pool = re.match(r"(Pool\d)", row["sample"]).group(1)
        tag = row.get("tag")
        return pool_map.get((pool, tag)) if isinstance(tag, str) else None
    cells["patient_sample"] = cells.apply(resolve, axis=1)
    print("细胞总数:", len(cells), "| 肾小管上皮（TEC）:", int(cells.is_tec.sum()),
          "| PT 样:", int(cells.is_pt.sum()), "| 可归属患者:", int(cells.patient_sample.notna().sum()))

    # 样本水平聚合（仅 PT 样细胞）
    pt_cells = cells[cells.is_pt & cells.patient_sample.notna()].copy()
    agg = pt_cells.groupby("patient_sample").agg(
        n_pt_cells=("barcode", "size"),
        **{name: (name, "median") for name in SIGNATURES},
        marker_PT=("marker_PT", "median"), umi=("umi", "median")).reset_index()
    agg["patient"] = agg["patient_sample"].str.split(".").str[0]

    clinical = pd.read_csv(GITHUB / "Urine_AKI_patient_data.csv", sep=";")
    clinical.columns = [c.strip() for c in clinical.columns]
    agg = agg.merge(clinical, left_on="patient_sample", right_on="sample.pseudonym",
                    how="left", suffixes=("", "_clin"))
    # 池化患者按 patient 字段回填临床
    missing = agg["sample.pseudonym"].isna()
    if missing.any():
        fallback = clinical.drop_duplicates("patient").set_index("patient")
        for col in ["KDIGO_AKI_stage", "outcome_after_ninety_daysme.fine", "RRT", "AKI.type", "COVID19_infection"]:
            if col in fallback and col in agg.columns:
                agg.loc[missing, col] = agg.loc[missing, "patient"].map(fallback[col])
    agg.to_csv(RES / "urine_signature_scores.csv", index=False)

    print("\n可用于分析的样本:", len(agg), "| KDIGO 可得:", int(agg.get("KDIGO_AKI_stage").notna().sum()))
    print(agg[["patient_sample", "n_pt_cells"] + SIGNATURES[:4]].round(3).head(12).to_string(index=False))

    # 临床关联（探索性）
    rows = []
    stage = pd.to_numeric(agg.get("KDIGO_AKI_stage"), errors="coerce")
    for name in SIGNATURES:
        valid = stage.notna() & agg[name].notna()
        if valid.sum() >= 6:
            rho, p = stats.spearmanr(stage[valid], agg.loc[valid, name])
            rows.append({"feature": name, "comparison": "KDIGO_stage", "n": int(valid.sum()),
                         "statistic": rho, "test": "Spearman", "p": p})
        out_col = "outcome_after_ninety_daysme.fine"
        if out_col in agg:
            groups = agg.dropna(subset=[name, out_col]).groupby(out_col)[name]
            if len(groups) >= 2 and min(len(g) for _, g in groups) >= 4:
                vals = [g.values for _, g in groups]
                p = stats.kruskal(*vals).pvalue
                rows.append({"feature": name, "comparison": "90d_outcome", "n": int(sum(len(v) for v in vals)),
                             "statistic": np.nan, "test": "Kruskal-Wallis", "p": p})
        if "RRT" in agg:
            a = agg.loc[agg["RRT"].astype(str).str.lower().isin(["yes", "y", "1"]), name].dropna()
            b = agg.loc[agg["RRT"].astype(str).str.lower().isin(["no", "n", "0"]), name].dropna()
            if len(a) >= 4 and len(b) >= 4:
                rows.append({"feature": name, "comparison": "RRT", "n": len(a) + len(b),
                             "statistic": np.nan, "test": "Mann-Whitney",
                             "p": stats.mannwhitneyu(a, b).pvalue})
    tests = pd.DataFrame(rows)
    if len(tests):
        tests["fdr"] = multipletests(tests["p"], method="fdr_bh")[1]
    tests.to_csv(RES / "urine_signature_clinical.csv", index=False)
    print("\n临床关联（探索性）:")
    print(tests.round(4).to_string(index=False) if len(tests) else "  无足够样本")

    # 纵向（同一患者多个时间点）
    serial = agg[agg["patient_sample"].str.contains(r"\.\d+$", regex=True, na=False)]
    serial = serial.sort_values("patient_sample")
    serial.to_csv(RES / "urine_signature_longitudinal.csv", index=False)
    print(f"\n纵向样本: {len(serial)} 个（{serial['patient'].nunique()} 名患者）")
    if len(serial):
        print(serial[["patient_sample", "n_pt_cells", "injury_stress", "repair_progenitor", "reference_PT"]].round(3).to_string(index=False))


if __name__ == "__main__":
    main()
