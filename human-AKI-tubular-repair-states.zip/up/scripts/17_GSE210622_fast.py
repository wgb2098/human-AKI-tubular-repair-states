#!/usr/bin/env python3
"""Fast parallel gene-level validation for GSE210622 (extracted raw matrices)."""

from __future__ import annotations

import gzip
import io
import re
from multiprocessing import Pool
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import sparse, stats
from statsmodels.stats.multitest import multipletests

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
EXTRACTED = ROOT / "data/GSE210622/extracted"
CELLS = ROOT / "metadata/GSE210622_cells.csv"
SIGS = ROOT / "results/Klocke_signature_genes.csv"
RES = ROOT / "results"
FIG = ROOT / "figures"

CYCLING = ["MKI67", "TOP2A", "CCNB1", "CDK1", "PTTG1", "NUSAP1", "BIRC5", "CDC20", "TPX2", "CENPF", "CCNA2", "AURKB"]
plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "font.size": 9})

# Globals shared with forked workers
G = {}


def score_vector(counts: np.ndarray, genes: list[str], signatures: dict[str, list[str]]) -> dict:
    lib = counts.sum()
    if lib <= 0:
        return {}
    logcpm = np.log2(counts / lib * 1e6 + 1)
    series = pd.Series(logcpm, index=genes)
    series = series[~series.index.duplicated(keep="first")]
    z = (series - series.mean()) / (series.std() if series.std() else 1)
    out = {}
    for name, gene_list in signatures.items():
        present = [g for g in gene_list if g in z.index]
        out[f"{name}_score"] = z.loc[present].mean() if len(present) >= 8 else np.nan
    return out


def process_sample(sample: str) -> dict | None:
    paths = G["members"][sample]
    try:
        features = gzip.decompress(Path(paths["features"]).read_bytes()).decode(errors="replace").splitlines()
    except Exception as exc:
        return {"tar_sample": sample, "error": f"features: {exc}"}
    genes = [line.split("\t")[1] if len(line.split("\t")) > 1 else line.split("\t")[0] for line in features]
    n_genes = len(genes)
    try:
        data = Path(paths["matrix"]).read_bytes()
        body = gzip.decompress(data)
        body = body.split(b"\n", 3)[3]
        df = pd.read_csv(io.BytesIO(body), sep=" ", header=None, names=["g", "c", "v"],
                         dtype={"g": np.int32, "c": np.int32, "v": np.float32}, engine="c")
        mat = sparse.csr_matrix((df["v"].values, (df["g"].values - 1, df["c"].values)),
                                shape=(n_genes, G["n_barcodes"] + 1))
    except Exception as exc:
        return {"tar_sample": sample, "error": f"matrix: {exc}"}

    col_tot = np.asarray(mat.sum(axis=0)).ravel()
    a = G["assign_all"][1:]
    mask = a >= 0
    total = np.bincount(a[mask], weights=col_tot[1:][mask], minlength=len(G["sample_info"]) + 1)
    assigned = int(np.argmax(total))
    if assigned == 0:
        return {"tar_sample": sample, "error": "no barcode match"}
    info = G["sample_info"][assigned - 1]

    all_counts = np.asarray(mat[:, np.where(G["assign_all"] == assigned)[0]].sum(axis=1)).ravel()
    row = {
        "tar_sample": sample, "meta_sample": info["sample"], "group": info["group"],
        "n_cells": info["n_cells"], "total_counts": int(total[assigned]),
        "expected_counts": int(info["nCount_sum"]),
    }
    row.update({f"all_{k}": v for k, v in score_vector(all_counts, genes, G["signatures"]).items()})

    pt_sel = np.where(G["assign_pt"] == assigned)[0]
    if len(pt_sel) > 0:
        pt_counts = np.asarray(mat[:, pt_sel].sum(axis=1)).ravel()
        row["pt_counts"] = int(pt_counts.sum())
        row.update({f"pt_{k}": v for k, v in score_vector(pt_counts, genes, G["signatures"]).items()})
    return row


def main() -> None:
    cells = pd.read_csv(CELLS)
    cells["barcode"] = cells["cell"].str.split("_", n=1).str[1]
    samples = list(cells["sample"].unique())
    sample_info = []
    for s in samples:
        sub = cells[cells["sample"] == s]
        sample_info.append({
            "sample": s, "group": sub["group"].iloc[0], "n_cells": len(sub),
            "nCount_sum": pd.to_numeric(sub["nCount"], errors="coerce").sum(),
            "barcodes": sub["barcode"].tolist(),
            "pt_barcodes": sub.loc[sub["celltype"] == "PT", "barcode"].tolist(),
        })

    members: dict[str, dict[str, str]] = {}
    for p in sorted(EXTRACTED.glob("*")):
        mo = re.match(r"(GSM\d+)_(.+)\.(barcodes|features|matrix)\.(tsv|mtx)\.gz$", p.name)
        if mo:
            members.setdefault(mo.group(2), {})[mo.group(3)] = str(p)

    first = next(iter(members.values()))
    whitelist = gzip.decompress(Path(first["barcodes"]).read_bytes()).decode(errors="replace").split()
    index = {b: i + 1 for i, b in enumerate(whitelist)}
    n_barcodes = len(whitelist)

    assign_all = np.full(n_barcodes + 1, -1, dtype=np.int8)
    assign_pt = np.full(n_barcodes + 1, -1, dtype=np.int8)
    for idx, info in enumerate(sample_info, start=1):
        for b in info["barcodes"]:
            pos = index.get(b)
            if pos:
                assign_all[pos] = idx
        for b in info["pt_barcodes"]:
            pos = index.get(b)
            if pos:
                assign_pt[pos] = idx

    sig = pd.read_csv(SIGS)
    signatures = {name: list(g["gene"].astype(str)) for name, g in sig.groupby("signature")}
    signatures["cycling"] = CYCLING

    G.update({
        "members": members, "sample_info": sample_info, "n_barcodes": n_barcodes,
        "assign_all": assign_all, "assign_pt": assign_pt, "signatures": signatures,
    })

    with Pool(7) as pool:
        rows = pool.map(process_sample, sorted(members))

    table = pd.DataFrame([r for r in rows if r and "error" not in r])
    table.to_csv(RES / "GSE210622_signature_scores.csv", index=False)
    print(table.to_string(index=False))
    errors = [r for r in rows if r and "error" in r]
    if errors:
        print("errors:", errors)

    stat_rows = []
    for level in ["all", "pt"]:
        for s in ["cycling", "injury_stress", "repair_progenitor", "reference_PT"]:
            col = f"{level}_{s}_score"
            if col not in table:
                continue
            control = table.loc[table["group"] == "Control", col].dropna()
            noncov = table.loc[table["group"] == "Non-COVID", col].dropna()
            cov = table.loc[table["group"] == "COVID", col].dropna()
            aki = pd.concat([noncov, cov])
            stat_rows.append({
                "level": level, "signature": s,
                "n_control": len(control), "n_nonCOVID": len(noncov), "n_COVID": len(cov),
                "mean_control": control.mean(), "mean_nonCOVID": noncov.mean(), "mean_COVID": cov.mean(),
                "p_control_vs_AKI": stats.mannwhitneyu(control, aki).pvalue if len(control) >= 3 and len(aki) >= 3 else np.nan,
                "p_nonCOVID_vs_COVID": stats.mannwhitneyu(noncov, cov).pvalue if len(noncov) >= 3 and len(cov) >= 3 else np.nan,
            })
    stats_table = pd.DataFrame(stat_rows)
    stats_table["fdr_control_vs_AKI"] = multipletests(stats_table["p_control_vs_AKI"].fillna(1), method="fdr_bh")[1]
    stats_table["fdr_nonCOVID_vs_COVID"] = multipletests(stats_table["p_nonCOVID_vs_COVID"].fillna(1), method="fdr_bh")[1]
    stats_table.to_csv(RES / "GSE210622_signature_tests.csv", index=False)

    fig, axes = plt.subplots(2, 4, figsize=(14, 6.5))
    order = ["Control", "Non-COVID", "COVID"]
    colors = {"Control": "#7F8C8D", "Non-COVID": "#2874A6", "COVID": "#C0392B"}
    for row_i, level in enumerate(["all", "pt"]):
        for col_i, s in enumerate(["cycling", "injury_stress", "repair_progenitor", "reference_PT"]):
            ax = axes[row_i, col_i]
            col = f"{level}_{s}_score"
            for pos, group in enumerate(order, 1):
                if col not in table:
                    continue
                vals = table.loc[table["group"] == group, col].dropna()
                ax.scatter(np.ones(len(vals)) * pos + np.random.uniform(-0.1, 0.1, len(vals)),
                           vals, s=18, color=colors[group])
                if len(vals):
                    ax.hlines(vals.mean(), pos - 0.25, pos + 0.25, color=colors[group], lw=2)
            ax.set_xticks([1, 2, 3]); ax.set_xticklabels(order, fontsize=7)
            ax.set_title(f"{level.upper()} {s.replace('_', ' ')}", fontsize=8)
    fig.suptitle("Independent validation GSE210622 (top = all cells, bottom = PT cells)", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_GSE210622_signature_validation.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_GSE210622_signature_validation.pdf", bbox_inches="tight")
    plt.close(fig)

    print("\nSignature tests:")
    print(stats_table.to_string(index=False))


if __name__ == "__main__":
    main()
