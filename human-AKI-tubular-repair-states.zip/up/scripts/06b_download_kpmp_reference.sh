#!/usr/bin/env bash
set -u
root=/media/desk16/iy16128/comorbidity_analysis/aki_repair
cd "$root"
mkdir -p data/KPMP/ref
while IFS='|' read -r url out participant size; do
  [ -z "$url" ] && continue
  if [ -e "$out" ]; then printf 'exists %s\n' "$out"; continue; fi
  printf 'start %s (%s, %s bytes)\n' "$(basename "$out")" "$participant" "$size"
  for attempt in $(seq 1 8); do
    curl --http1.1 -L --silent --show-error --fail --connect-timeout 20 --max-time 600 --continue-at - --user-agent 'Mozilla/5.0' --output "$out.part" "$url" && break
    printf 'retry %s for %s\n' "$attempt" "$(basename "$out")"
    sleep 5
  done
  if [ -s "$out.part" ]; then mv -- "$out.part" "$out"; stat --printf='saved %n (%s bytes)\n' "$out"; fi
done < /tmp/kpmp_ref_download_list.txt
