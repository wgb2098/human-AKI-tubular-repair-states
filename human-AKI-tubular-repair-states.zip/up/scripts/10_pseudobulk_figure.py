#!/usr/bin/env python3
"""Pseudobulk signature scores versus KDIGO stage (all downloaded AKI samples)."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
FIG = ROOT / "figures"

TABLE = RES / "KPMP_sc_pseudobulk_signatures.csv"
SIGNATURES = ["cycling", "injury_stress", "repair_progenitor", "reference_PT"]

plt.rcParams.update({"figure.dpi": 150, "font.size": 9, "axes.spines.top": False, "axes.spines.right": False})


def main() -> None:
    table = pd.read_csv(TABLE)
    stage = pd.to_numeric(table["stage"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
    fig, axes = plt.subplots(1, 4, figsize=(13, 3.4))
    for ax, name in zip(axes, SIGNATURES):
        col = f"{name}_score"
        data = pd.DataFrame({"stage": stage, "score": table[col]}).dropna()
        ax.scatter(data["stage"] + np.random.uniform(-0.12, 0.12, len(data)), data["score"],
                   s=18, alpha=0.75, color="#2874A6")
        for s in [1, 2, 3]:
            sub = data.loc[data["stage"] == s, "score"]
            if len(sub):
                ax.hlines(sub.mean(), s - 0.25, s + 0.25, color="#C0392B", lw=2)
        rho, p = stats.spearmanr(data["stage"], data["score"], nan_policy="omit")
        ax.set_title(f"{name.replace('_', ' ')}\nrho={rho:.2f}, p={p:.3f}, n={len(data)}", fontsize=9)
        ax.set_xticks([1, 2, 3]); ax.set_xticklabels(["Stage 1", "Stage 2", "Stage 3"])
        ax.set_ylabel("Pseudobulk signature (mean log2 CPM)")
    fig.suptitle("Gene-level pseudobulk signatures across KDIGO severity (KPMP sc, 42 AKI samples)", y=1.04)
    fig.tight_layout()
    fig.savefig(FIG / "Fig_pseudobulk_signatures_stage.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG / "Fig_pseudobulk_signatures_stage.pdf", bbox_inches="tight")
    plt.close(fig)
    print("saved figures/Fig_pseudobulk_signatures_stage.png/.pdf")


if __name__ == "__main__":
    main()
