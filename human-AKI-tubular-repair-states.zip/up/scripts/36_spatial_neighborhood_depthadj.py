#!/usr/bin/env python3
"""Depth-adjusted neighbourhood enrichment in the Visium sections.

The naive version (top-quartile labels, free permutation) is confounded: spots
with high total counts score high for every signature and they cluster
spatially. Here each feature score is residualised on log total UMI and the
permutation is performed within UMI deciles, so the test asks whether spots with
high *depth-adjusted* programme scores are spatial neighbours more often than
chance.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.io import mmread
from scipy.spatial import cKDTree

ROOT = Path("/media/desk16/iy16128/comorbidity_analysis/aki_repair")
RES = ROOT / "results"
SPATIAL = ROOT / "data/KPMP_spatial"
K = 6
N_PERM = 500
FEATURES = ["injury_stress", "repair_progenitor", "cycling", "reference_PT",
            "marker_PT", "marker_TAL", "marker_immune", "marker_fibroblast", "marker_endothelial"]
rng = np.random.default_rng(0)


def main() -> None:
    spot = pd.read_csv(RES / "spatial_pilot_spot_scores.csv.gz")
    rows = []
    for (patient, stage), group in spot.groupby(["patient", "stage"]):
        group = group.dropna(subset=FEATURES).reset_index(drop=True)
        if len(group) < 60:
            continue
        matrix = mmread(SPATIAL / patient / "rctd_input" / "counts.mtx").tocsc()
        barcodes = (SPATIAL / patient / "rctd_input" / "barcodes.txt").read_text().split()
        total_umi = np.asarray(matrix.sum(axis=0)).ravel()
        umi = pd.Series(total_umi, index=barcodes)
        depth = group["barcode"].map(umi).to_numpy(dtype=float)
        if np.isnan(depth).any():
            keep = ~np.isnan(depth)
            group = group.loc[keep].reset_index(drop=True)
            depth = depth[keep]
        log_depth = np.log10(depth + 1)

        coords = group[["pxl_col", "pxl_row"]].to_numpy(dtype=float)
        tree = cKDTree(coords)
        _, neighbour_idx = tree.query(coords, k=min(K + 1, len(group)))
        neighbour_idx = neighbour_idx[:, 1:]

        # residualise each score on depth, then label the upper quartile
        high = {}
        for feature in FEATURES:
            values = group[feature].to_numpy(dtype=float)
            slope, intercept = np.polyfit(log_depth, values, 1)
            residual = values - (slope * log_depth + intercept)
            high[feature] = residual >= np.nanquantile(residual, 0.75)

        strata = pd.qcut(log_depth, 5, labels=False)

        def fraction(labels: np.ndarray) -> float:
            both = labels[neighbour_idx[:, 0]] & labels[neighbour_idx[:, 1]]
            return both.mean()

        for i, a in enumerate(FEATURES):
            for b in FEATURES[i:]:
                pair_high = high[a] & high[b]
                if pair_high.sum() < 5:
                    continue
                observed = fraction(pair_high)
                permuted = np.empty(N_PERM)
                for j in range(N_PERM):
                    labels = np.zeros(len(group), dtype=bool)
                    for stratum in np.unique(strata):
                        idx = np.where(strata == stratum)[0]
                        n_high = int(np.isin(idx, np.where(pair_high)[0]).sum())
                        if n_high:
                            labels[rng.choice(idx, size=n_high, replace=False)] = True
                    permuted[j] = fraction(labels)
                z = (observed - permuted.mean()) / (permuted.std() if permuted.std() else 1)
                p = (np.sum(permuted >= observed) + 1) / (N_PERM + 1)
                rows.append({"patient": patient, "stage": stage, "feature_a": a, "feature_b": b,
                             "observed": observed, "z": z, "p": p, "n_spots": len(group)})
        print(f"{patient} ({stage}): {len(group)} spots processed")

    result = pd.DataFrame(rows)
    result.to_csv(RES / "spatial_neighborhood_enrichment_depthadj.csv", index=False)

    summary = (result.groupby(["feature_a", "feature_b"])
               .agg(n_sections=("z", "count"), median_z=("z", "median"),
                    median_observed=("observed", "median"))
               .reset_index().sort_values("median_z", ascending=False))
    summary.to_csv(RES / "spatial_neighborhood_summary_depthadj.csv", index=False)

    print("\nDepth-adjusted neighbourhood enrichment (median z across sections; "
          "Wilcoxon signed-rank against 0):")
    for (a, b), group in result.groupby(["feature_a", "feature_b"]):
        if len(group) >= 8:
            w, p = stats.wilcoxon(group["z"])
            marker = "*" if p < 0.05 else " "
            print(f" {marker} {a:20s} + {b:20s} n={len(group):2d} median z={group['z'].median():+.2f} P={p:.2e}")


if __name__ == "__main__":
    main()
