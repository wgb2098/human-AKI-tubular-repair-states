# KPMP Visium pilot 下载清单（历史记录）

最后更新：2026-11-06

> **状态（2026-11-06）**：这是**最初 6 例 pilot 的下载记录（历史存档）**，下列路径为当时的下载目标，**不代表当前文件位置**：
> - 当前样本集为 **16 例**，清单与校验见 `metadata/kpmp_spatial_pilot_files.json` 与 `metadata/spatial_download_verify.json`；
> - 本清单中 `30-11104`、`34-10666`（早期条目）不在最终 16 例集内；`32-10003` 已归档到 `archive/2026-11-05/KPMP_spatial_leftover/`；
> - 当前样本目录：`data/KPMP_spatial/<患者ID>/`（16 个，文件校验通过）。

保存目录：`/media/desk16/iy16128/comorbidity_analysis/aki_repair/data/KPMP_spatial/<患者ID>/`

文件名用链接最后一段原样保存。总大小约 359 MB。

- **30-11080（Stage 3，['Experimental Metadata']，0.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/a5aabffc-c146-4a80-9c06-1b7186dc9667/43fbf2a9-a89f-42a6-8aaa-d37883190f68_METADATA_Transcriptomics_Spatial_v3_30-11080.xlsx`
  保存为：`data/KPMP_spatial/30-11080/43fbf2a9-a89f-42a6-8aaa-d37883190f68_METADATA_Transcriptomics_Spatial_v3_30-11080.xlsx`
- **30-11080（Stage 3，['Expression Matrix']，15.7 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/a5aabffc-c146-4a80-9c06-1b7186dc9667/3325f27c-9797-4972-9358-c8cb80b65452_expression_matrix.zip`
  保存为：`data/KPMP_spatial/30-11080/3325f27c-9797-4972-9358-c8cb80b65452_expression_matrix.zip`
- **30-11080（Stage 3，['Spatial Imaging Data']，15.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/a5aabffc-c146-4a80-9c06-1b7186dc9667/f91c8cd5-957d-43a5-b86d-a6f4852f4099_spatial_V12U21-009_XY02_22-0086.zip`
  保存为：`data/KPMP_spatial/30-11080/f91c8cd5-957d-43a5-b86d-a6f4852f4099_spatial_V12U21-009_XY02_22-0086.zip`
- **30-11104（Stage 3，['Experimental Metadata']，0.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/6e8c4072-bea9-4d73-8628-d9514a2d215b/cf1dd94b-a0dc-44c4-9a93-af2a42e5a198_METADATA_Transcriptomics_Spatial_v3_30-11104.xlsx`
  保存为：`data/KPMP_spatial/30-11104/cf1dd94b-a0dc-44c4-9a93-af2a42e5a198_METADATA_Transcriptomics_Spatial_v3_30-11104.xlsx`
- **30-11104（Stage 3，['Expression Matrix']，10.3 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/6e8c4072-bea9-4d73-8628-d9514a2d215b/e1860f47-2de4-47ba-a7e2-4b4a2985536b_expression_matrix.zip`
  保存为：`data/KPMP_spatial/30-11104/e1860f47-2de4-47ba-a7e2-4b4a2985536b_expression_matrix.zip`
- **30-11104（Stage 3，['Spatial Imaging Data']，10.8 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/6e8c4072-bea9-4d73-8628-d9514a2d215b/6d643fbe-2f71-4b87-a4fc-5f3b80658577_spatial_V13F08-026_XY03_23-0140.tar.gz`
  保存为：`data/KPMP_spatial/30-11104/6d643fbe-2f71-4b87-a4fc-5f3b80658577_spatial_V13F08-026_XY03_23-0140.tar.gz`
- **32-10003（Stage 2，['Experimental Metadata']，0.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/8c4e518e-e4fc-415e-84d4-a137a3b37f21/209752e3-ee5a-4781-ba39-cc7d115e63d6_METADATA_Transcriptomics_Spatial_v3_32-10003-v2.xlsx`
  保存为：`data/KPMP_spatial/32-10003/209752e3-ee5a-4781-ba39-cc7d115e63d6_METADATA_Transcriptomics_Spatial_v3_32-10003-v2.xlsx`
- **32-10003（Stage 2，['Expression Matrix']，5.7 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/8c4e518e-e4fc-415e-84d4-a137a3b37f21/3fa8da55-20d7-4ca1-b055-3cc7d00b49b8_expression_matrix.zip`
  保存为：`data/KPMP_spatial/32-10003/3fa8da55-20d7-4ca1-b055-3cc7d00b49b8_expression_matrix.zip`
- **32-10003（Stage 2，['Spatial Imaging Data']，256.7 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/8c4e518e-e4fc-415e-84d4-a137a3b37f21/560b3d7e-d52f-40e6-a947-4f1adfe4713e_space_ranger_outs_32-10003.zip`
  保存为：`data/KPMP_spatial/32-10003/560b3d7e-d52f-40e6-a947-4f1adfe4713e_space_ranger_outs_32-10003.zip`
- **34-10184（Stage 1，['Experimental Metadata']，0.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/9c28830e-a7a6-4478-8bfc-bb4bc199dd4f/0dc8f5ee-18f2-472d-b4a4-09f62e5232d9_METADATA_Transcriptomics_Spatial_v3_27-10042.xlsx`
  保存为：`data/KPMP_spatial/34-10184/0dc8f5ee-18f2-472d-b4a4-09f62e5232d9_METADATA_Transcriptomics_Spatial_v3_27-10042.xlsx`
- **34-10184（Stage 1，['Expression Matrix']，5.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/9c28830e-a7a6-4478-8bfc-bb4bc199dd4f/9074ecd1-d508-423e-98c7-3a58f649e8f2_expression_matrix.zip`
  保存为：`data/KPMP_spatial/34-10184/9074ecd1-d508-423e-98c7-3a58f649e8f2_expression_matrix.zip`
- **34-10184（Stage 1，['Spatial Imaging Data']，8.4 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/9c28830e-a7a6-4478-8bfc-bb4bc199dd4f/56fbb3ab-92c3-4a46-9101-bd7c6d498c44_spatial_V12N14-057_XY03_23-0117.zip`
  保存为：`data/KPMP_spatial/34-10184/56fbb3ab-92c3-4a46-9101-bd7c6d498c44_spatial_V12N14-057_XY03_23-0117.zip`
- **34-10729（Stage 1，['Experimental Metadata']，0.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/127b22f3-642b-4df6-b9b9-6ecc820f8b4e/7c980437-f16e-4925-8576-9442fd99192e_METADATA_Transcriptomics_Spatial_v3_34-10729.xlsx`
  保存为：`data/KPMP_spatial/34-10729/7c980437-f16e-4925-8576-9442fd99192e_METADATA_Transcriptomics_Spatial_v3_34-10729.xlsx`
- **34-10729（Stage 1，['Expression Matrix']，11.3 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/127b22f3-642b-4df6-b9b9-6ecc820f8b4e/b3f7a6e8-8222-48f2-b0b3-6cc78fe48ead_expression_matrix.zip`
  保存为：`data/KPMP_spatial/34-10729/b3f7a6e8-8222-48f2-b0b3-6cc78fe48ead_expression_matrix.zip`
- **34-10729（Stage 1，['Spatial Imaging Data']，11.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/127b22f3-642b-4df6-b9b9-6ecc820f8b4e/de9074e3-7a0d-410e-b754-3c3f1b721c96_spatial_V14S03-385_XY02_23-0153.tar.gz`
  保存为：`data/KPMP_spatial/34-10729/de9074e3-7a0d-410e-b754-3c3f1b721c96_spatial_V14S03-385_XY02_23-0153.tar.gz`
- **34-11025（Stage 2，['Experimental Metadata']，0.0 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/cb4475f6-90fe-4df5-8dd0-7512f4548f46/44ab63ab-07fc-4d5e-ad6e-711fda9499d9_METADATA_Transcriptomics_Spatial_v3_34-11025.xlsx`
  保存为：`data/KPMP_spatial/34-11025/44ab63ab-07fc-4d5e-ad6e-711fda9499d9_METADATA_Transcriptomics_Spatial_v3_34-11025.xlsx`
- **34-11025（Stage 2，['Expression Matrix']，1.4 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/cb4475f6-90fe-4df5-8dd0-7512f4548f46/ade00af0-ee25-4c49-ae16-40ec330adc09_expression_matrix.zip`
  保存为：`data/KPMP_spatial/34-11025/ade00af0-ee25-4c49-ae16-40ec330adc09_expression_matrix.zip`
- **34-11025（Stage 2，['Spatial Imaging Data']，7.4 MB）**
  `https://atlas.kpmp.org/api/v1/file/download/cb4475f6-90fe-4df5-8dd0-7512f4548f46/6e59961e-bb98-4c8b-b066-f3b7e2af7d73_spatial_V14Y20-298_XY02_24-0184_fl.tar.gz`
  保存为：`data/KPMP_spatial/34-11025/6e59961e-bb98-4c8b-b066-f3b7e2af7d73_spatial_V14Y20-298_XY02_24-0184_fl.tar.gz`
