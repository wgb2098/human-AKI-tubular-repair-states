# Table 1. Cohorts used in this study

生成时间：2026-11-06（由 scripts/31 自动生成）

| Cohort | Platform | n | Cells/spots | Groups | Use |
|---|---|---:|---:|---|---|
| KPMP scRNA-seq (GSE183276) | 10x sc/sn RNA-seq | 49 | 109,741 | DKD: 12 patients / 43,076 cells; AKI: 12 patients / 35,777 cells; Ref: 18 patients / 21,650 cells; H-CKD: 3 patients / 9,238 cells | discovery (AKI vs Reference, PT states, KDIGO trend) |
| KPMP snRNA-seq (GSE183277) | 10x sc/sn RNA-seq | 44 | 203,702 | Ref: 13 patients / 88,460 cells; H-CKD: 6 patients / 36,011 cells; AKI: 6 patients / 32,190 cells; DKD: 7 patients / 27,363 cells; COV-AKI: 4 patients / 19,678 cells; **分析口径：AKI 组 = AKI + COV-AKI 合并（n=10）** | discovery (AKI vs Reference, PT states, KDIGO trend) |
| KPMP scRNA-seq, PT-level | 10x scRNA-seq (per-sample matrices) | 54 | 28,911 | AKI: 12 patients / 9,272 PT cells; CKD (DKD + H-CKD): 15 patients / 14,786 PT cells; Reference: 18 patients / 4,853 PT cells | primary cell-type-resolved comparison |
| GSE210622 | 10x snRNA-seq (human kidney) | 14 | 29,534 | control: 6 samples; COVID-AKI: 4; non-COVID AKI: 4; **29,534 PT 细胞用于签名打分（队列合计 106,971 细胞）** | independent replication (PT injury/repair) |
| KPMP Visium | 10x Visium spatial transcriptomics | 16 | 11,301 | Stage 1: 5; Stage 2: 5; Stage 3: 6 | spatial localisation of injury/repair programmes + RCTD deconvolution |
| GSE139061 (Eadon) | bulk RNA-seq (kidney biopsy) | 48 | — | 39 AKI vs 9 reference | bulk-level signature validation |
| GSE67401 | blood transcriptome (SIRS/AKI) | 53 | — | SIRS with/without AKI | tissue-specificity control and KDIGO-stage meta-analysis |
| Urine AKI cohort (GitHub) | clinical + urine output/creatinine | 32 | — | KDIGO 1-3; infection-associated 15 vs non-infectious 17 | clinical trajectory and infection-associated subgroup (exploratory) |

**脚注**

1. `Cells/spots` 列对 sc/sn 为细胞数、对 Visium 为 spot 数、对 bulk/blood 为样本数。
2. GSE210622 行的 29,534 是**用于签名打分的 PT 细胞数**（队列合计 106,971 细胞、14 个样本）。
3. KPMP sn 行中 AKI 与 COV-AKI 分开列出，**所有分析中合并为 AKI 组（n=10）**。
4. KPMP sc 行的条件分组与 sn 相同口径：分析时 AKI 单独成组（无 COV-AKI）。

## KPMP scRNA-seq 患者基线（患者水平）

| 组 | n | 女/男 | 年龄中位（可得/总） | eGFR 中位（可得/总） | KDIGO 1/2/3 |
|---|---:|---:|---:|---:|---:|
| AKI | 12 | 3/9 | 54 (12/12) | 76 (12/12) | 1/4/7 |
| CKD | 15 | 10/5 | 64 (15/15) | 45 (15/15) | 0/0/0 |
| Ref | 18 | 11/7 | 44 (18/18) | — | 0/0/0 |

参考供肾者的年龄/性别来自开放临床表与 KPMP 仓库索引（规范化 ID 匹配，18/18 可得），eGFR 在参考组缺失。

**脚注**

1. `Cells/spots` 列对 sc/sn 为细胞数、对 Visium 为 spot 数、对 bulk/blood 为样本数。
2. GSE210622 行的 29,534 是**用于签名打分的 PT 细胞数**（队列合计 106,971 细胞、14 个样本）。
3. KPMP sn 行中 AKI 与 COV-AKI 分开列出，**所有分析中合并为 AKI 组（n=10）**。
4. KPMP sc 行的条件分组与 sn 相同口径：分析时 AKI 单独成组（无 COV-AKI）。
