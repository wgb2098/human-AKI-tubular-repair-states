# PT-level pseudobulk: AKI versus reference (three cohorts)

最后更新：2026-11-06

> **2026-11-05 更新**：新增第三队列 **KPMP snRNA-seq**（GSE183277 样本矩阵，AKI 4 例 5,625 PT 细胞 / CKD 6 例 / Reference 12 例）。方向与 sc、GSE210622 一致（injury 1.181 vs 1.031、独立 aPT 标志物 1.707 vs 1.522 p=0.058、cycling −0.055 vs −0.332），但**功效不足、无一过 FDR**，仅作方向性证据；数据见 `results/KPMP_sn_PT_pseudobulk*.csv`。（AKI 仅 4 例：6 例中 2 例的仓库矩阵与其被注释文库不是同一文库。）

Goal: test whether the epithelial injury/repair programme seen in the atlas
comparisons survives when the analysis is restricted to proximal-tubule (PT)
cells, i.e. after removing the cell-composition shift that dominates
whole-library pseudobulk.

## Why this analysis was needed

The earlier whole-library pseudobulk (`results/KPMP_sc_pseudobulk_signatures.csv`)
used every cell in a sample library and therefore mixes two effects: the change
in PT cell state and the change in PT cell *abundance*. In AKI the PT fraction
falls, so a PT-derived signature can move in either direction depending on which
effect dominates. Restricting to annotated PT cells removes that ambiguity.

## Cohort 1 - KPMP scRNA-seq (GSE183276 metadata, KPMP repository matrices)

* Cell labels: PT and PT l2 states from the published KPMP sc atlas metadata.
* Matrices: per-sample 10x matrices from the KPMP repository; each matrix ships
  its own barcode list, so barcodes are resolved per file (an early version that
  used a shared whitelist matched only a handful of cells and was discarded).
* Group sizes: 12 AKI patients (193-1578 PT cells each, 9,272 total) versus
  18 healthy-reference patients (23-1057 PT cells each, 4,853 total).

Patient-level medians (Mann-Whitney, two-sided):

| Feature | AKI | Reference | P | FDR |
|---|---|---|---|---|
| PT injury/stress signature | 1.98 | 1.85 | 0.019 | 0.019 |
| PT repair-progenitor signature | 1.24 | 1.04 | 0.0056 | 0.0067 |
| PT cycling signature | 0.76 | -0.39 | 2.1e-05 | 4.2e-05 |
| PT reference-state signature | 3.00 | 3.58 | 8e-06 | 4.2e-05 |
| Reference-state fraction of PT cells | 0.092 | 0.521 | 1.7e-05 | 4.2e-05 |
| Cycling fraction of PT cells | 0.041 | 0.000 | 3.6e-05 | 5.4e-05 |

Internal consistency: the PT pseudobulk reference-state score correlates with the
independently annotated reference-state fraction across all 30 patients
(Spearman rho = +0.785, P = 3e-05), and injury/repair/cycling scores correlate
negatively with it (rho = -0.48, -0.44, -0.65).

Within the 12 AKI patients the injury/stress score rises with KDIGO stage
(Spearman rho = +0.56, P = 0.059); the other three signatures show no stage
gradient at this sample size.

## Cohort 2 - GSE210622 snRNA-seq (independent replication)

* 8 AKI samples (4 COVID-AKI: P1cov, P2cov, P4cov, P13cov; 4 non-COVID AKI:
  P15cov, P3sepsis, Pat17, Pat20, following the labels in the published GSE210622
  cell metadata) versus 6 control samples (3 tumour-nephrectomy, 3 post-mortem
  15/60/120 min).
* AKI file names (AKI1-AKI8) were mapped to metadata sample names by per-cell
  UMI matching (`metadata/GSE210622_AKI_file_map.json`), because the AKI
  matrices ship the full 6.79M-barcode whitelist and counts alone do not
  identify the sample.

Sample-level medians (Mann-Whitney, two-sided):

| Feature | AKI | Control | P | FDR |
|---|---|---|---|---|
| PT injury/stress signature | 1.34 | 0.85 | 0.0007 | 0.0013 |
| PT repair-progenitor signature | 0.95 | 0.80 | 0.0007 | 0.0013 |
| PT cycling signature | -0.46 | -0.52 | 0.081 | 0.108 |
| PT reference-state signature | 2.07 | 2.13 | 0.41 | 0.41 |

Injury and repair replicate at FDR < 0.01. Cycling does not reach significance in
this nucleus-based cohort, where proliferative transcripts are under-represented;
the reference-state score is flat, most likely because (i) these controls are
tumour-nephrectomy or post-mortem tissue rather than living healthy kidney, and
(ii) the published state annotation used to define it comes from the sc atlas.

Exploratory: COVID-AKI samples show a higher cycling score than non-COVID AKI
samples (median -0.37 versus -0.49, P = 0.036, n = 5/3); injury and repair scores
are similar between the two aetiologies.

## Pseudo-count sensitivity (2026-11-06)

Signature scoring uses `log2(CPM + 1)`; because that pseudo-count is a free
parameter, the whole PT-pseudobulk pipeline was re-run with **+0.5** and **+0.1**
(patient-level AKI vs Reference, `PT_PSEUDO` env var in `scripts/22`):

| 签名 | 中位 AKI (+1) | (+0.5) | (+0.1) | p (+1) | (+0.5) | (+0.1) | FDR 范围 |
|---|---:|---:|---:|---:|---:|---:|---|
| injury/stress | 1.978 | 1.880 | 1.702 | 0.0188 | 0.0133 | 0.0149 | 0.013–0.019 |
| repair-progenitor | 1.237 | 1.233 | 1.209 | 0.0056 | 0.0021 | 0.0010 | 0.0012–0.0064 |
| cycling | 0.756 | 0.830 | 0.931 | <1e-4 | <1e-4 | <1e-4 | 0.0001 |
| reference-state | 2.999 | 2.778 | 2.388 | <1e-4 | <1e-4 | <1e-4 | 0.0001 |
| 独立 aPT 标志物 | 2.493 | 2.342 | 2.072 | 0.0002 | 0.0002 | 0.0002 | 0.0002 |
| hypoxia 模块 | 1.559 | 1.514 | 1.413 | <1e-4 | 1e-4 | 1e-4 | 0.0001 |

All features keep their direction and remain significant at FDR<0.05 under every
pseudo-count (injury/stress becomes marginally stronger); median scores shift by
at most ~0.6 units, as expected when low-expression genes are down-weighted.
Result table: `results/PT_pseudocount_sensitivity.csv`.

## Files

| Path | Content |
|---|---|
| `scripts/22_PT_pseudobulk.py` | KPMP sc PT selection and pseudobulk (per-file barcodes) |
| `scripts/24_match_ref_sc.py` | maps reference libraries to repository matrices |
| `scripts/26_GSE210622_PT_pseudobulk.py` | independent sn cohort analysis |
| `scripts/27_map_GSE210622_AKI.py` | resolves AKI file names by UMI matching |
| `scripts/28_PT_two_cohorts_figure.py` | combined figure |
| `results/KPMP_sc_PT_pseudobulk.csv` | per-library scores |
| `results/KPMP_sc_PT_pseudobulk_patient.csv` | per-patient scores and state fractions |
| `results/KPMP_sc_PT_pseudobulk_AKI_vs_Ref.csv` | KPMP PT tests |
| `results/KPMP_sc_PT_pseudobulk_stage_trend.csv` | KDIGO stage trend within AKI |
| `results/GSE210622_PT_pseudobulk.csv` | independent cohort per-sample scores |
| `results/PT_pseudobulk_two_cohorts.csv` | combined tidy table |
| `figures/Fig_PT_pseudobulk_two_cohorts.png` | two-cohort figure |
| `figures/Fig_PT_pseudobulk_AKI_vs_Ref.png` | KPMP-only six-panel figure |

## How this changes the manuscript

The PT-level analysis converts the central claim from "PT injury/repair
programmes differ between AKI and reference kidneys at the tissue level" into a
cell-type-resolved claim: within PT cells, injury/stress, repair-progenitor and
cycling programmes are induced and the reference state is depleted, with the
injury score tracking KDIGO stage. It also provides an independent replication in
a second platform (snRNA-seq) for the injury and repair components, while
honestly reporting that the cycling and reference-state components did not reach
significance there.
