# Figure legends (English, manuscript-ready)

最后更新：2026-11-06

Draft legends matching the figures in `figures/`. Numbers correspond to the
current results tables; update if analyses are re-run.

**Figure 1 | Study design.** Public human kidney datasets used in this study and
the analysis flow. (A) Data: KPMP single-cell and single-nucleus atlas metadata
(GSE183276/GSE183277), KPMP repository per-sample matrices for 42 AKI libraries
and 18 reference participants, an independent human kidney single-nucleus cohort
(GSE210622), and 16 KPMP Visium sections (KDIGO stage 1 ×5, stage 2 ×5,
stage 3 ×6). (B) Analyses: tissue-level composition, PT-only pseudobulk,
independent replication, whole-library pseudobulk, spatial signature mapping and
RCTD deconvolution. (C) Validation: bulk kidney transcriptomes (GSE139061),
blood transcriptomes (GSE67401) and a clinical urine-output/creatinine cohort.
All comparisons are performed at the patient or sample level; signatures derive
from published human tubular cell states (Klocke et al.).

**Figure 2 | Proximal-tubule pseudobulk signatures in AKI versus controls.**
Left: KPMP scRNA-seq, 12 AKI patients (9,272 PT cells) versus 18 healthy
reference patients (4,853 PT cells). Right: GSE210622 snRNA-seq, 8 AKI samples
versus 6 control samples (29,534 PT cells). Boxes show medians and interquartile
ranges with individual patients/samples overlaid; P values from two-sided
Mann-Whitney tests. In KPMP all four signatures differ (injury/stress P=0.019,
repair-progenitor P=0.006, cycling P<0.001, reference state P<0.001); in
GSE210622 the injury/stress and repair-progenitor differences replicate
(P<0.001 each) while cycling and reference state do not reach significance.

**Figure 3 | PT-state composition and module scores across AKI versus reference
and KDIGO stages** (`Fig_AKI_vs_Ref_and_stage_heatmap`, `Fig_PT_states_KDIGO`,
`Fig_KDIGO_state_scores`). Patient-level epithelial-state fractions and mean
module scores are shown for AKI versus reference kidneys and across KDIGO
stages 1–3; AKI kidneys show expansion of adaptive and cycling states with
depletion of the reference state (BH FDR < 0.01), whereas stage trends within
AKI are weak and reported as exploratory.

**Figure 4 | Gene-level pseudobulk validation** (`Fig_pseudobulk_AKI_vs_Ref`,
`Fig_pseudobulk_signatures_stage`). Signature scores computed from whole-library
pseudobulk of 42 AKI libraries versus 72–74 reference libraries (left) and their
relationship to KDIGO stage (right). Cycling (AUC=0.95), injury/stress
(AUC=0.92) and repair-progenitor (AUC=0.87) signatures are elevated in AKI;
stage associations do not survive patient-level aggregation.

**Figure 5 | Independent validation in GSE210622**
(`Fig_GSE210622_composition`, `Fig_GSE210622_signature_validation`).
Cell-type composition and signature scores per sample. Injury/stress and
repair-progenitor signatures are higher in AKI both across all cells
(FDR=0.0018–0.0027, six-feature family) and within PT cells (FDR=0.001332,
four-signature family as used in `FINAL_manuscript_numbers.csv`); PT fraction
tends to be lower in AKI but does not pass FDR.

**Figure 6 | Spatial localisation of injury/repair programmes in 16 Visium
sections** (`Fig_spatial_pilot_signatures`). Representative sections (two largest
per KDIGO stage) with per-spot signature scores; colour scales are clipped at the
5th–95th percentile within each section. All signatures except cycling are
spatially autocorrelated (Moran's I 0.19–0.81 for injury/stress,
repair-progenitor and reference state); cycling shows near-zero autocorrelation.
RCTD deconvolution of the same sections (12 cell types) and depth-adjusted
neighbourhood enrichment are summarised in `reports/RCTD_RESULTS.md` and
`results/spatial_neighborhood_summary_depthadj.csv`.

**Figure 7 | Clinical trajectories in the urine AKI cohort**
(`Fig_urine_trajectories`, `Fig_infection_AKI_urine_trajectories`,
`Fig_infection_AKI_urine_clinical`). Serial serum creatinine and urine output for
patients with infection-associated versus non-infectious AKI; 90-day outcomes
differ between subgroups (P=0.014, exploratory) while KDIGO stage and RRT do not.

**Figure 8 | KDIGO severity across cohorts** (`Fig_severity_meta_forest`).
Patient-level Spearman correlations between signature scores and KDIGO stage
combined across 30 KPMP single-cell patients and 53 GSE67401 SIRS-AKI blood samples
(133-sample cohort: 111 SIRS + 22 haemodialysis controls) using a random-effects model
(I²=0%, no signature significant; injury/stress rho=0.217, P=0.053). Severity results are exploratory.

**Figure 9 | Infection-associated AKI (exploratory)**
(`Fig_GSE122274_sepsis_signatures`, `Fig_infection_AKI_sn`). Signatures in
sepsis kidney biopsies and comparison of COVID-associated versus non-COVID AKI
in KPMP snRNA-seq. Differences are nominal at most and inconsistent across
datasets.

**Supplementary tables.** Table S1 signature gene sets
(`results/Klocke_signature_genes.csv`); Table S2 cohort characteristics
(`reports/TABLE1_cohort_characteristics.md`); Table S3 PT pseudobulk results by
patient (`results/KPMP_sc_PT_pseudobulk_patient.csv`); Table S4 spatial
deconvolution and neighbourhood statistics (`results/spatial_rctd_*.csv`,
`results/spatial_neighborhood_summary_depthadj.csv`).
