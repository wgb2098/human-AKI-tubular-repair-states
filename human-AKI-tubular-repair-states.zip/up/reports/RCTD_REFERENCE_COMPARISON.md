# RCTD 参考选择对比：GSE210622 vs KPMP sn

最后更新：2026-11-05

同一 16 例 Visium，唯一变量是解卷积参考。GSE210622 参考缺成纤维细胞；
KPMP sn 参考与 Visium 同队列、同组织来源，并含 FIB。

## 样本水平一致性（compartment 比例，Spearman）

| compartment | rho | p | 中位(GSE210622) | 中位(KPMP sn) |
|---|---:|---:|---:|---:|
| PT | +0.929 | 1.9e-07 | 0.106 | 0.120 |
| TAL | +0.850 | 3.1e-05 | 0.018 | 0.043 |
| distal | +0.462 | 0.072 | 0.449 | 0.030 |
| endothelium | +0.829 | 7.1e-05 | 0.104 | 0.092 |
| immune | +0.950 | 1.8e-08 | 0.079 | 0.098 |
| podocyte | +0.603 | 0.013 | 0.124 | 0.019 |

## spot 水平一致性

| compartment | rho | n spot |
|---|---:|---:|
| PT | +0.910 | 10861 |
| TAL | +0.837 | 10861 |
| distal | +0.361 | 10861 |
| endothelium | +0.861 | 10861 |
| immune | +0.870 | 10861 |
| podocyte | +0.572 | 10861 |

## 分期趋势（样本水平）

| reference | feature | rho | p | FDR | n |
|---|---|---:|---:|---:|---:|
| GSE210622 | PT | +0.003 | 0.9909 | 0.991 | 16 |
| GSE210622 | TAL | -0.516 | 0.0407 | 0.117 | 16 |
| GSE210622 | distal | -0.337 | 0.2022 | 0.354 | 16 |
| GSE210622 | endothelium | -0.633 | 0.0085 | 0.059 | 16 |
| GSE210622 | immune | +0.497 | 0.0500 | 0.117 | 16 |
| GSE210622 | podocyte | -0.301 | 0.2574 | 0.360 | 16 |
| GSE210622 | n_spots | -0.087 | 0.7478 | 0.872 | 16 |
| KPMP_sn | PT | -0.014 | 0.9589 | 0.959 | 16 |
| KPMP_sn | TAL | -0.497 | 0.0500 | 0.200 | 16 |
| KPMP_sn | distal | -0.098 | 0.7174 | 0.959 | 16 |
| KPMP_sn | endothelium | -0.577 | 0.0193 | 0.155 | 16 |
| KPMP_sn | immune | +0.413 | 0.1117 | 0.298 | 16 |
| KPMP_sn | fibroblast | -0.257 | 0.3361 | 0.672 | 16 |
| KPMP_sn | podocyte | -0.023 | 0.9315 | 0.959 | 16 |
| KPMP_sn | n_spots | -0.087 | 0.7478 | 0.959 | 16 |

完整表：`results/spatial_rctd_reference_agreement*.csv`、`spatial_rctd_reference_sample_table.csv`、`spatial_rctd_stage_trends_by_reference.csv`。
