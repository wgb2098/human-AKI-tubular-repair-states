# 审稿意见的干实验落实（按 Kimi 评审文档逐条执行）

生成时间：2026-11-04。对应文档：`01-SCI-.docx`（Kimi 模拟审稿意见 + 修订记录）。
本文只记录**需要干实验/再分析才能回答**的条目；纯文字修改（摘要精简、术语统一、引文补充、图形摘要等）不在范围内。

所有新增结果表以 `reviewer_` 前缀保存在 `results/`，脚本为 `scripts/39`–`44`。

---

## Major 1｜统计单位与伪重复

**审稿要求**：主分析改为患者水平（同一患者多样本取中位数），或在正文同时报告两种口径。

**已完成**：把 sc/sn 的组织层与 PT 层结果全部按患者重新聚合（同一患者多个文库取中位数），并与原"文库即样本"口径并列。

| 队列/层级 | 特征 | P（文库口径） | 患者口径 P | 患者口径 FDR |
|---|---|---:|---:|---:|
| sc / 组织 | adaptive-epi 比例 | 4e-05 | 1.6e-05 | 0.0002 |
| sc / 组织 | reference 比例 | 0.0017 | 0.0019 | 0.0085 |
| sc / 组织 | cycling 比例 | 4e-05 | 1.4e-04 | 0.0009 |
| sc / PT | adaptive 比例 | 0.0015 | 0.0025 | 0.0032 |
| sc / PT | reference 比例 | 3.9e-05 | 3.9e-05 | 0.0001 |
| sc / PT | cycling 比例 | 1.1e-05 | 1.1e-05 | 0.0001 |
| **sn / 组织** | adaptive-epi 比例 | 0.0019 | 0.0070 | 0.107（全局口径）/ **0.021（族内，显著）** |
| **sn / 组织** | reference 比例 | 0.0011 | 0.0058 | 0.107（全局口径）/ **0.021（族内，显著）** |
| **sn / 组织** | cycling 比例 | 0.0083 | 0.0508 | **0.170** |
| sn / PT | cycling 比例 | 0.945 | 0.575 | 0.93 |

**结论与写法**：sc 主结论在患者水平**不变甚至更强**；sn 的 AKI vs Ref 差异在患者去重后，**组织层在族内 FDR（冻结口径）下仍显著**（adaptive/reference FDR=0.021；表内 0.107 是 32 特征全局口径，仅作敏感性），但 **sn 的 PT 层全部不显著**（族内 FDR≥0.73）。正文应写成「sc 与 sn 组织层一致；PT 层仅在 sc 与 GSE210622 中成立」，而不是笼统说「sn 不过 FDR」。

数据：`results/reviewer_sc_tissue_sample_vs_patient.csv`、`reviewer_sc_PT_sample_vs_patient.csv`、`reviewer_sn_*_sample_vs_patient.csv`。

> 注：Kimi 修订稿写的是"sc 45 名参与者、sn 36 名、pseudobulk 95 名（38 AKI vs 51 参考）"。本目录核算：sc 49 文库→45 患者、sn 44 文库→36 患者、全库 pseudobulk 114 文库→95 患者（38 AKI vs 57 参考患者）。参考患者数是 57 而非 51，需与修订稿核对。

---

## Major 2｜CKD 对照缺失（审稿人列为"不改大概率被拒"）

**审稿要求**：补 AKI vs CKD vs Reference 三组比较，明确所述状态重塑是否 AKI 特异。

**已完成三层证据**：

1. **图谱层（sc，患者水平，12 AKI / 15 CKD / 18 Ref）**

| 特征 | AKI | CKD | Ref | P(AKI-Ref) | P(AKI-CKD) | P(CKD-Ref) |
|---|---:|---:|---:|---:|---:|---:|
| adaptive-epi 比例 | 0.155 | 0.134 | 0.047 | 1.6e-05 | 0.23 | 1e-04 |
| reference 比例 | 0.545 | 0.625 | 0.680 | 0.0019 | 0.39 | 0.024 |
| **cycling 比例** | **0.0129** | **0.0027** | **0.000** | 1.4e-04 | **0.0010** | 0.0061 |
| 免疫细胞比例 | 0.220 | 0.133 | 0.051 | 0.0021 | 0.12 | 0.0097 |

2. **PT 层（sc 患者水平，同一批 45 人）**：adaptive 0.444/0.451/0.224（AKI/CKD/Ref，AKI-CKD p=0.94）、reference 0.092/0.169/0.522（p=0.11）、cycling 0.0414/0.0062/0.000（**p=0.0067**）。

3. **PT 内部 pseudobulk（新下载 20 个 CKD 矩阵，12 DKD + 3 H-CKD 患者，AKI 12 / CKD 15 / Ref 18）**

| 签名 | AKI | CKD | Ref | P(AKI-CKD) | P(CKD-Ref) |
|---|---:|---:|---:|---:|---:|
| injury/stress | 1.98 | 2.04 | 1.85 | 0.98 | 0.0097 |
| repair-progenitor | 1.24 | 1.12 | 1.04 | 0.14 | 0.10 |
| **cycling** | **0.756** | **0.041** | **-0.395** | **0.0104（FDR 0.042）** | 0.0011 |
| reference-state | 2.99 | 3.02 | 3.58 | 0.45 | 0.0009 |
| 独立 aPT 标志物 | 2.49 | 2.35 | 1.81 | 0.64 | 0.0002 |

**结论**：adaptive/injury 扩张与 reference 状态丢失是 **AKI 与 CKD 共有**；**cycling 扩增是 AKI 特有**（三层证据一致，PT 内部亦成立）。这实际上把论文立意从"AKI 图谱描述"提升为"急性 vs 慢性损伤的鉴别"，可直接改写为新的结果节 + 新图（`figures/Fig_PT_three_group.png`）。

数据：`reviewer_sc_tissue_three_group.csv`、`reviewer_sc_PT_three_group.csv`、`KPMP_sc_PT_pseudobulk_three_group.csv`；CKD 数据清单 `metadata/KPMP_open_CKD_single_sample_matrices.csv`。

---

## Major 2 补充｜RCTD 参考来源（空间方法学软肋）

**审稿人必问**："为什么用 GSE210622 而不是 KPMP 自己的 snRNA 图谱？"

**已做**：补下 KPMP sn 矩阵 43 个（1.89 GB，全部字节级校验通过），构建 **KPMP sn 参考（33,514 基因 × 5,502 细胞 × 14 类，含成纤维细胞）**，对同一 16 例 Visium 重跑 RCTD，并与原 GSE210622 参考逐 spot 对比：

- compartment 比例高度一致：免疫 rho=+0.95（样本级）/ +0.87（spot 级）、PT +0.93/+0.91、TAL +0.85/+0.84、内皮 +0.83/+0.86；
- 分期趋势方向一致（内皮 −0.63/−0.58、TAL −0.52/−0.50、免疫 +0.50/+0.41），KPMP sn 版更保守；
- KPMP sn 参考额外含成纤维细胞（543 细胞），补上了原参考的缺口。

**结论**：空间结论不依赖参考选择，方法段落可直接写"两套独立参考（跨队列 GSE210622 + 同队列 KPMP sn）结果一致"。详见 `reports/RCTD_REFERENCE_COMPARISON.md`、`results/spatial_rctd_reference_*.csv`。

## Major 3｜签名循环论证风险

**审稿要求**：说明签名独立于 KPMP；补 1–2 个来自其他文献的独立签名做交叉验证。

**已完成**：新增两个独立基因集并重跑全部 PT pseudobulk：
- `aPT_markers`（VCAM1、SPP1、LTF、MMP7、HAVCR1、CD24、PROM1、SOX9、KRT7、KRT19）——独立于 Klocke 聚类的人 AKI 损伤 PT 标志物；
- `hypoxia_targets`（VEGFA、SLC2A1、LDHA、PGK1、ENO1、HK2、BNIP3、NDRG1、ANKRD37、P4HA1、ADM、HILPDA、MIF、DDIT4）——正交的缺氧/糖酵解轴。

结果：
- **aPT 标志物成功复制主方向**：AKI vs Ref P=1.5e-04（FDR 0.0002）、CKD vs Ref P=0.0002；与 Klocke 签名高度一致（injury rho=+0.87、repair rho=+0.69、cycling rho=+0.54，n=45）；
- **hypoxia 模块不复制**：其表达在 reference PT 中反而更高（与 reference 状态比例正相关 rho=+0.52），说明它捕获的是代谢状态而非损伤；如实报告，不能算作支持性证据。

数据：`KPMP_sc_PT_pseudobulk_signature_crosscheck.csv`、`KPMP_sc_PT_pseudobulk_three_group.csv`。

---

## Major 1/3 补充｜KPMP sn 的 PT 级 pseudobulk（第三队列）

补下 KPMP sn 矩阵后新增第三套 PT 级数据（AKI 4 例 5,625 细胞 / CKD 6 例 / Ref 12 例；AKI 仅 4 例是因为 6 例中有 2 例的仓库矩阵与其被注释文库不是同一文库，barcode 重叠为 0）。

方向均与主分析一致（injury/stress 1.181 vs 1.031、独立 aPT 标志物 1.707 vs 1.522 p=0.058、cycling −0.055 vs −0.332），但 **n=4 vs 12 功效不足，无一通过 FDR**，只能作为"方向一致的第三平台证据"，不能计入主结论。数据：`results/KPMP_sn_PT_pseudobulk*.csv`；已并入 `FINAL_manuscript_numbers.csv` 的 `sn_PT_pseudobulk` 层。

## Major 4｜reference PT 的反向 pseudobulk 结果

**审稿要求**：给出定量组成校正（比例加权表达或解卷积后重测），或在摘要中平衡表述。

**已完成（定量证明这是组成假象）**：
1. 全库 pseudobulk 一致地从文库口径改为**患者口径**后，reference PT 的反向显著性消失：文库口径 P=0.049（FDR 0.049）→ 患者口径 P=0.172（38 AKI vs 57 参考）；injury/repair/cycling 在患者口径仍然 FDR≈0（`reviewer_pseudobulk_library_vs_patient.csv`）。
2. 在有细胞注释的 30 例患者中，全库 reference-PT 分数与 **PT 细胞比例的相关 rho=+0.85（P=2e-10）**——该分数基本由 PT 含量决定；调整 PT 比例后患者水平组间差异 P=0.072（原本 0.62）。
3. 同一批患者限制在 PT 细胞内部后，方向反转为**生理预期方向**：AKI 3.00 vs Ref 3.58（P=8e-06），且与注释的 reference 状态比例高度一致（rho=+0.81）。

**写法建议**：主文只引用 PT 内部结果；全库结果作为方法学说明保留，并在摘要中不出现"全库 pseudobulk reference PT 升高"这类反向表述。

数据：`reviewer_pseudobulk_library_vs_patient.csv`、`reviewer_wholelibrary_annotated_tests.csv`、`reviewer_wholelibrary_annotated_subset.csv`。

---

## Major 5｜FDR 策略透明化

**已完成**：显式定义特征族并做全局 FDR 敏感性分析。

- 特征族：`epithelial_state_fraction`（6 项）、`subclass_fraction`（16 项）、`module_score`（8 项，组织层）/（3 项，PT 层）、`qc`（2 项）、`pt_state_fraction`（6 项）；
- 全局 FDR 把该表所有评价特征合并校正。

关键敏感性：
- sc/PT 的 AKI vs Ref 四项主特征在**任何口径下都 FDR<0.05**（族内 FDR 5e-05–0.039；全局 9 项 FDR 1e-04–0.037）；
- **AKI vs CKD 的 cycling 差异**：PT 状态族内 FDR=0.040、模块族 FDR=0.035、PT pseudobulk（8 项）FDR=0.042，但在最保守的"组织层 32 项全局校正"下 FDR=0.054–0.070（仅名义）。建议正文写"族内校正显著、全局校正边缘"，避免被指选择性校正。

数据：`reviewer_{sc,sn}_{tissue,PT}_fdr_strategy.csv`。

---

## Major 6｜基线表与主比较的人口学校正

**已完成**（2026-11-04 修正：参考供肾者的年龄/性别**在开放临床表中存在**，此前用精确 ID 匹配漏掉了；改用规范化匹配后 18/18 参考患者全部补齐）：

1. **基线表**（`reviewer_{sc,sn}_baseline_table.csv`）：
   - sc：AKI 12 例（9M/3F，年龄中位 54.5，eGFR 76.2，n=12）、CKD 15 例（5M/10F，64.5，44.8，n=15）、**Ref 18 例（7M/11F，年龄中位 44.5，18/18 可得；eGFR 无）**；
   - 匹配方式：图谱患者 ID（如 `1157EO2`、`PRE018`）↔ 临床表文库级 ID（`Sample1157-EO2`、`PRE018-1`、`PRE19-025`）按规范化字符串相互包含匹配，并用图谱元数据自带 `sex` 交叉校验（18/18 一致，无冲突）。
2. **可比性检验**（`reviewer_{sc,sn}_baseline_tests.csv`）：**AKI vs Ref 年龄无显著差异（sc P=0.194；sn P=0.279）**；AKI vs CKD 的 eGFR 差异显著（sc P=0.0043，sn P=0.022），年龄无差异。
3. **校正后的主比较**（`reviewer_{sc}_adjusted_contrasts.csv`）：

| 特征（AKI vs Ref, sc, n=30） | 未校正 | 性别校正 | **性别+年龄校正** |
|---|---:|---:|---:|
| adaptive-epi 比例 | 2e-05 | <1e-04 | **<1e-04** |
| reference 比例 | 0.0019 | 0.0004 | **0.0001** |
| cycling 比例 | 1e-04 | <1e-04 | **<1e-04** |
| 免疫细胞比例 | 0.0021 | 0.0072 | **0.0144** |
| PT adaptive 比例 | 0.0025 | 0.0008 | **0.0058** |
| PT reference 比例 | 4e-05 | <1e-04 | **<1e-04** |
| PT cycling 比例 | 1e-05 | <1e-04 | **<1e-04** |
| repair index | <1e-04 | <1e-04 | **<1e-04** |

   即 **AKI vs Ref 主结论在性别+年龄校正后全部保持**；AKI vs CKD 的 cycling 差异在性别（0.0099）、性别+年龄（0.0219）、性别+年龄+eGFR（0.0162）校正下都稳健。
4. **eGFR 仍不可得**：18 例参考供肾者均无 baseline eGFR（开放临床表 129 例 Healthy Reference 中仅 31 例有），因此 AKI vs Ref 无法做 eGFR 校正，此项保留为局限；AKI vs CKD 的 eGFR 校正属过度校正（eGFR 在 CKD 因果通路上），已注明。

---

## Minor 中需要干实验的条目

| 条目 | 落实情况 |
|---|---|
| 图 1 缺 UMAP（"图谱类论文没有 UMAP 几乎必被吐槽"） | 已自算：45 例患者、24,917 个 PT 细胞、2,000 HVG + PCA50 + UMAP；三panel（PT 状态 / 研究分组 / VCAM1 表达）→ `figures/Fig_UMAP_PT_states.png`，坐标 `results/reviewer_PT_umap_coordinates.csv.gz` |
| repair index 需给出合理性论证与去一法敏感性 | 已完成去一法与替代权重敏感性（`reviewer_{sc,sn}_PT_repair_index_sensitivity.csv`）：AKI vs Ref 在所有变体下均显著；AKI vs CKD 仅在含 cycling 的变体显著（cycling−reference P=0.0037），与"cycling 为 AKI 特有成分"一致 |
| GSE210622 分组 5/3 vs 6/4/4 需统一 | 已按**发表元数据**更正为 control 6 / COVID 4 / 非 COVID 4（P15cov 在 GSE210622 元数据中标注为非 COVID），并同步修改 `PT_LEVEL_VALIDATION.md`、`METHODS_DRAFT.md` |
| 小样本趋势需标注"描述性" | 已有：KDIGO 趋势全部标注 n 与"探索性"；空间 16 例趋势标为描述性 |

---

## 未通过再分析解决、必须写进局限的点

1. **AKI vs Reference 无法校正 eGFR**（18 例参考供肾者在开放临床表与 KPMP 仓库索引中均无 baseline eGFR；年龄与性别已补齐并已用于校正）。补充核实：年龄来源为开放临床表（优先）与 KPMP 仓库文件索引（补缺），两来源仅 1 例不一致（31-10042，仓库 30-39 岁 vs 临床 60-69 岁，已按临床取值并标记），性别冲突 3 例（已标记）；eGFR 采用开放临床表的精确值（27/45，AKI 12 + CKD 15），KPMP 仓库索引里的 eGFR 是 10 单位分箱值（如 "80-89 ml/min/1.73m2"），仅作备用、未用于主分析，详见 `metadata/patient_demographics_consolidated.csv`；
2. sn 的 **PT 层**在患者去重后不显著（族内 FDR≥0.73）——组织层仍显著（族内 FDR=0.021）；
3. 缺氧/代谢独立签名不支持主方向（如实报告）；
4. AKI vs CKD 的 cycling 差异在全局（32 项）FDR 下为边缘（0.054–0.070）；
5. 无湿实验验证。
