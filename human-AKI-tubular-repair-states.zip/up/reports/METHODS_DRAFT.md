# Methods draft (English, manuscript-ready)

最后更新：2026-11-06

Draft methods text for the AKI tubular repair manuscript. Numbers match the
analysis outputs in `results/`; update if any analysis is re-run.

## Data sources

We analysed publicly available human kidney transcriptomes from five resources.
(1) The Kidney Precision Medicine Project (KPMP) open-access atlas single-cell
(GSE183276) and single-nucleus (GSE183277) cell-level metadata, comprising
109,741 single-cell and 203,702 single-nucleus profiles with published cell-type,
subclass and epithelial-state annotations. (2) Per-sample 10x matrices from the
KPMP atlas repository (`https://atlas.kpmp.org`): 42 open-access AKI libraries
(38 participants), 19 libraries from 18 healthy-reference participants, 20
libraries from 15 CKD participants (12 diabetic kidney disease, 3 hypertensive
CKD) and 43 single-nucleus matrices (29 participants, used both as a second
deconvolution reference and as a third PT-level cohort). (3) GSE210622, an independent human kidney
single-nucleus dataset of 8 AKI samples (4 labelled COVID-associated and 4 non-COVID in
the published metadata) and 6 control kidneys (three tumour-nephrectomy specimens and three post-mortem biopsies at
15/60/120 min). (4) GSE139061, bulk RNA-seq of 39 AKI and 9 reference kidney
biopsies, and GSE67401, blood transcriptomes from 53 patients with SIRS with
KDIGO staging. (5) KPMP spatial transcriptomics: 16 open-access Visium sections
(KDIGO stage 1 ×5, stage 2 ×5, stage 3 ×6; 11,301 spots) with expression
matrices, tissue positions and experimental metadata. All data are de-identified
and openly available; no ethics approval was required for this secondary
analysis.

## Signature definition

Epithelial injury/repair programmes were scored with marker sets derived from
published human tubular cell states (Klocke et al.): injury/stress,
repair-progenitor and reference proximal-tubule (PT) signatures, plus a
12-gene cycling signature (MKI67, TOP2A, CCNB1, CDK1, PTTG1, NUSAP1, BIRC5,
CDC20, TPX2, CENPF, CCNA2, AURKB). Gene sets are provided in
`results/Klocke_signature_genes.csv`.

## Tissue-level composition analyses

Cell-level metadata were aggregated per library and per patient. We computed
epithelial-state fractions (adaptive-epithelial, cycling, reference,
degenerative), subclass fractions (including immune and fibroblast fractions) and
mean published module scores. Patient-level comparisons between AKI and
reference used Mann-Whitney U tests with Benjamini-Hochberg (BH) correction;
KDIGO-stage associations used Spearman correlation and Kruskal-Wallis tests, and
were additionally modelled by OLS with HC3 robust standard errors adjusting for
baseline eGFR, age and sex.

## PT-only pseudobulk

Three PT-level datasets were analysed with the identical pipeline (KPMP scRNA-seq,
KPMP snRNA-seq and GSE210622). FDR for the four signatures is controlled within
the four-signature family (`fdr_family` in `FINAL_manuscript_numbers.csv`); a
global correction over all features of the same analysis level is reported
alongside as a sensitivity analysis. An independent marker set (VCAM1, SPP1,
LTF, MMP7, HAVCR1, CD24, PROM1, SOX9, KRT7, KRT19; plus a hypoxia/HIF module as
an orthogonal negative control) was scored in the same way to address the risk
of circular signature construction.

To separate cell-state change from cell-composition change, PT cells
(`subclass.l1 == "PT"`) were selected from the published annotations and their
raw counts summed per library. Each KPMP matrix ships its own barcode list, so
barcodes were resolved per file; libraries in which fewer than 20 annotated PT
barcodes were found were discarded. Pseudobulk counts were converted to log2
CPM and, within each library, genes were z-scored across expressed genes before
averaging signature genes, so that scores are comparable across libraries and
platforms. Library scores were aggregated per patient weighted by the number of
PT cells. The log pseudo-count is a free parameter, so the entire pipeline was
also run with +0.5 and +0.1 instead of +1: all signatures keep their direction
and FDR<0.05 (`results/PT_pseudocount_sensitivity.csv`). AKI (12 patients, 9,272 PT cells) and reference (18 patients, 4,853 PT
cells) groups were compared with Mann-Whitney U tests and BH correction.
The same procedure was applied to GSE210622 (8 AKI versus 6 control samples;
29,534 PT cells), with the mapping between repository file names (AKI1–AKI8) and
metadata sample names recovered by matching per-cell UMI totals against the
published `nCount` values.

## Spatial transcriptomics

Visium expression matrices and `tissue_positions.csv` were read directly from the
downloaded archives; spots outside the tissue were removed. Each spot was
scored with the same signatures after log2 CPM normalisation and gene-wise
z-scoring. Spatial autocorrelation was quantified with Moran's I using a 6-nearest
neighbour graph. Co-localisation between signatures and cell-type marker scores
(PT, TAL, immune, fibroblast, endothelial) was assessed with spot-level Spearman
correlations within each section; medians across sections are reported.

## RCTD deconvolution

Two independent references were used on the same 16 sections, so that the choice
of reference can be audited. Reference A was built from GSE210622, retaining at
most 150 cells per (sample, cell type) across six samples spanning control,
non-COVID AKI and COVID AKI (9,185 cells; 12 cell types; no fibroblasts).
Reference B is KPMP-matched: snRNA-seq matrices of the same atlas (AKI, CKD and
reference participants; at most 80 cells per sample and cell type; 5,502 cells;
14 cell types including fibroblasts). Compartment fractions agree closely
between references (immune rho=0.95, PT 0.93 at sample level; PT 0.91 across
10,861 spots), and KDIGO-stage trends are consistent in direction. Duplicate gene symbols were removed and the
spatial count matrices were restricted to the shared feature space
(31,908 genes). Deconvolution was run with spacexr (RCTD) in full mode; spots
with fewer than 100 UMIs are not assigned weights by RCTD, which is reported per
section. Compartment fractions (PT, TAL, distal nephron, endothelium, immune,
podocyte) were summed from the per-spot weights and related to spot-level
signature scores (Spearman) and to KDIGO stage (sample-level Spearman).

## Cross-cohort meta-analysis

Patient-level Spearman correlations between signature scores and KDIGO stage
were combined across KPMP single-cell patients and GSE67401 blood samples using
a DerSimonian-Laird random-effects model on Fisher-z transformed correlations,
with I² as the heterogeneity statistic.

## State-specific differential expression

To ask whether acute and chronic injury differ *within* the same epithelial
state, PT cells were split by their published l2 state (adaptive-epi,
degenerative, reference); raw counts were summed per patient and the same
patient-level pseudobulk was compared between groups with edgeR quasi-likelihood
F-tests for AKI vs CKD, AKI vs reference and CKD vs reference, run under two
designs (`~ 0 + group + sex` and `~ 0 + group + sex + age`) because age differs
between groups; the two models agree closely (Spearman rho of log fold-changes
0.94-0.99) and the reported signals are unchanged by age adjustment. Gene-set level tests used a competitive Mann-Whitney test
of the set's log fold-changes against all other genes, with BH correction.

## Urine bridge (exploratory, GSE199321)

All 37 urine 10x matrices were analysed (43 patient samples plus six pooled
samples deconvoluted to patients with the four hashing tags; 80% of pooled cells
assigned). Cells were annotated with the cluster markers published with that
dataset (top 25 genes per cluster, gene-wise z-scoring, argmax), and per patient
we derived the fraction of PT-like cells in reference / injury / repair-
proliferative clusters plus the four signature scores on PT-like cells. Scores
were related to KDIGO stage, 90-day outcome, RRT and COVID status
(Spearman/Mann-Whitney/Kruskal-Wallis, BH across features). Because the
signatures originate from this dataset, the analysis is presented as a
quantification/translation bridge and not as independent validation.

## Focused ligand-receptor analysis

Ten prespecified ligand-receptor pairs (ligand expressed by PT, receptor on
immune cells) were scored at patient level as the product of z-scored ligand
expression (PT pseudobulk) and mean z-scored receptor expression (immune
pseudobulk), then compared across groups and correlated with the annotated
immune fraction. Spatially, ligand expression per spot (from the Visium matrices,
gene-wise z-scored) was correlated with the mean immune marker score of the six
nearest neighbouring spots across the 16 sections.

## Software

Analyses used Python 3.9 (pandas, NumPy, SciPy, statsmodels, matplotlib) and
R 4.5 (spacexr, Matrix). Scripts are numbered in execution order in `scripts/`;
checksums are provided in `reports/file_checksums.sha256`.

## Data and code availability

All primary data are public: KPMP atlas and repository (`atlas.kpmp.org`),
GEO accessions GSE183276, GSE183277, GSE210622, GSE139061, GSE122274, GSE67401,
and the Urine AKI cohort data hosted on GitHub. Derived tables and figures are
provided in `results/` and `figures/`; analysis code is in `scripts/`.

## Limitations

Analyses are cross-sectional re-analyses of convenience samples. KDIGO stages are
unbalanced (stage 3 predominates), and no signature reaches significance for
stage after patient-level meta-analysis; severity results are therefore
exploratory. Spatial sections comprise both acute tubular injury and acute
interstitial nephritis, and spots are not independent units, so spatial stage
trends are descriptive. The GSE210622 reference lacks fibroblasts, so
fibroblast content cannot be estimated there. No wet-lab validation was
performed.
