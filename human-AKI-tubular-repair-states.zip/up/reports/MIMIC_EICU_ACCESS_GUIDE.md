# MIMIC-IV / eICU 数据获取执行清单

最后更新：2026-11-02

目标：合法获得 MIMIC-IV 与 eICU-CRD，用于 SA-AKI 临床共病研究。  
注意：数据访问资格绑定个人，不能转让；原始数据不得转发或公开。

## 0. 先试开放 demo（无需认证，可立即开始）

- MIMIC-IV demo：`https://physionet.org/content/mimic-iv-demo/`
- MIMIC-IV ED demo、MIMIC-CXR demo 也有开放版本。
- 用途：先验证字段、写 SQL/Python 草稿；不能用于正式论文结果。

## 1. 注册 PhysioNet

1. 打开 `https://physionet.org/` 注册账号。
2. 填写真实姓名、机构、职位、机构邮箱（优先 .edu / 医院邮箱）。
3. 完成个人资料中的 affiliation 和身份信息；独立研究者通常需要一位推荐人/导师。

## 2. 完成 CITI 培训

1. 登录 CITI Program：`https://about.citiprogram.org/`，或你所在机构的 CITI 入口。
2. 选择课程：**Data or Specimens Only Research**（有时显示为 Biomedical Research – Data/Specimens Only）。
3. 完成全部必修模块，下载 Completion Report（PDF）。
4. 费用：部分机构已购买、可免费；个人注册可能需要几十美元。有效期通常数年，到期需更新。

## 3. 申请 PhysioNet Credentialing

1. 打开 `https://physionet.org/settings/credentialing/`。
2. 提交：
   - CITI Completion Report；
   - 身份与机构证明（按页面要求）；
   - 推荐人/导师信息（如有要求）。
3. 等待审核：常见为几天到几周。
4. 通过后会显示 Credentialed 状态；这是申请受控数据的前提。

## 4. 申请 MIMIC-IV / eICU 并签署 DUA

1. MIMIC-IV：`https://physionet.org/content/mimiciv/`
2. eICU-CRD：`https://physionet.org/content/eicu-crd/`
3. 在项目页面点击 Request Access，填写研究用途，在线签署：
   - **PhysioNet Credentialed Health Data License 1.5.0**
   - **PhysioNet Credentialed Health Data Use Agreement 1.5.0**
4. 数据免费；不得再分发、不得尝试重新识别、只能用于申请中写明的用途。
5. 下载前记录版本号与获取日期，论文中必须引用。

## 5. 下载方式

- **AWS Open Data**：MIMIC-IV 与 eICU 在 AWS Registry 上有公开镜像；用 AWS CLI 同步到本地。
- **Google BigQuery**：公共数据集 `physionet-data`，适合先用 SQL 探索；注意大查询可能产生费用，正式分析建议下载到本地。
- **PhysioNet 直链**：提供 CSV 压缩包，体积从数 GB 到十几 GB，下载较慢。
- 建议先下载 MIMIC-IV（主队列），eICU 作为多中心外部验证。

## 6. 本地存放与安全

- 建议目录：`/media/desk16/iy16128/mimic_data/`（与代码仓库分离）。
- 不要上传到 GitHub、网盘或任何外部服务。
- 记录版本、下载日期、文件校验和；必要时磁盘加密。
- 保留 DUA 和 CITI 证书副本，以备投稿或机构审查。

## 7. 数据到手后我可以直接完成的部分

- 队列构建：Sepsis-3、KDIGO AKI 分期、SA-AKI vs Sepsis non-AKI、AKI 恢复轨迹。
- 协变量：年龄、性别、CKD、糖尿病、SOFA、休克、液体平衡、 nephrotoxin、RRT。
- 统计分析：竞争风险、Cox/logistic、混合模型、倾向评分、机器学习预测与外部验证。
- 图表、STROBE/TRIPOD 报告、论文初稿。

## 8. 建议时间顺序

1. 今天：注册 PhysioNet + 报名 CITI。
2. 1–3 天：完成 CITI，提交 credentialing。
3. 等待认证期间：先用 demo 数据和我一起把分析流程跑通。
4. 认证通过：签 DUA，下载 MIMIC-IV；eICU 随后。
5. 数据到位：一周内可完成主要队列和第一版结果。
