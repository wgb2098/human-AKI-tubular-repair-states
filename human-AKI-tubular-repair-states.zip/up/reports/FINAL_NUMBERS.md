# 稿件最终数字（权威来源）
生成时间：2026-11-06

**唯一数据源**：`results/FINAL_manuscript_numbers.csv`（长表）。字段：`analysis_level / cohort / contrast / feature / family / n_a / n_b / median_a / median_b / statistic / statistic_name / p / test / unit / covariates / fdr_family / fdr_global / source_table`。

**覆盖范围**（`analysis_level` 全清单见文末）：图谱层（sc/sn：组织层、PT 层、校正模型）、PT pseudobulk（sc、sn、GSE210622 三个队列）、全库 pseudobulk（文库口径/患者口径/组成校正）、**KDIGO 分期趋势（图谱/PT/空间三套）**、**严重度跨队列 meta**、**GSE139061 / GSE67401 / 尿液 / 感染亚组**、空间 RCTD 双参考对比。

## 口径说明（回答审稿人可能提出的 6 类「看似矛盾」）

1. **sn 参考组 13 vs 12**：组织层 13 名参考患者，PT 层 12 名（1 名参考患者无 PT 细胞）。同一患者在不同层缺席属正常，非数据冲突。
2. **sn PT 内 cycling 方向与 sc 相反**（AKI 0.72% < Ref 1.00%，而 sc 为 4.14% > 0%）：数值在两个文件中互相吻合，是**真实的跨平台不一致**；sn 平台核内 S 期转录本缺失、AKI 侧仅 4 例，故不作为结论。
3. **FDR 两级标注（关键示例）**：sn 组织层 adaptive-epi 与 reference 的 `fdr_family=0.021`（显著）而 `fdr_global=0.107`（不显著）——按冻结口径应表述为**显著**，全局值只作敏感性；切勿用 `fdr_global` 下结论。`fdr_family` 为预定义特征族内 BH 校正，`fdr_global` 为同一分析层/对比内全部特征校正。**BH 非单调，`fdr_global` 并非恒严于 `fdr_family`**（共 794 行中 171 行出现 global < family）。结论以 `fdr_family`（冻结口径）为准，`fdr_global` 仅作敏感性。
4. **全库 pseudobulk 文库数 41 vs 42**：cycling 行为 41（1 个 AKI 文库缺 cycling 基因覆盖），其余签名为 42。
5. **严重度分析的多重 n**：42 个 AKI 文库 → 34 个有 KDIGO 分期 → 33 个同时有 cycling 分值（1 个文库缺 cycling 基因）→ 患者水平聚合后 30 名患者；跨队列 meta 用 30 名 KPMP 患者 + 53 例 GSE67401 血液样本。引用时必须标明层级。
6. **GSE67401 的 111 vs 53**：数据集共 133 个样本（111 例 SIRS：58 非 AKI + 53 AKI；另 22 例血液透析对照），严重度 meta 只用其中的 53 例 SIRS-AKI。

## 分析层（共 30 层）

## GSE139061_bulk — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 39.0/9.0 | nan | nan | 0.0447 | 0.1341 | 0.1341 |
| repair_progenitor | 39.0/9.0 | nan | nan | 0.4129 | 0.5261 | 0.5261 |
| injury_stress | 39.0/9.0 | nan | nan | 0.5261 | 0.5261 | 0.5261 |

## GSE210622_PT_pseudobulk — AKI_vs_Control

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| injury_stress | 8.0/6.0 | 1.341 | 0.8538 | 0.000666 | 0.001332 | 0.001332 |
| repair_progenitor | 8.0/6.0 | 0.9531 | 0.7987 | 0.000666 | 0.001332 | 0.001332 |
| cycling | 8.0/6.0 | -0.4616 | -0.5169 | 0.08125 | 0.1083 | 0.1083 |
| reference_PT | 8.0/6.0 | 2.074 | 2.13 | 0.4136 | 0.4136 | 0.4136 |

## GSE67401_blood — AKI_vs_non_AKI

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| injury_stress | 53.0/58.0 | -0.006388 | 0.09928 | 0.1103 | 0.2987 | 0.2987 |
| reference_PT | 53.0/58.0 | -0.005866 | 0.09938 | 0.1991 | 0.2987 | 0.2987 |
| repair_progenitor | 53.0/58.0 | 0.03879 | 0.04971 | 0.6388 | 0.6388 | 0.6388 |

## KDIGO_trend — stage

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_cycling | nan/nan | nan | nan | 0.05295 | 0.3177 | 0.6776 |
| injury_stress | 12.0/nan | nan | nan | 0.05931 | 0.2372 | 0.6776 |
| frac_sub_IMM | nan/nan | nan | nan | 0.2042 | 0.638 | 0.6776 |
| frac_state_adaptive - epi | nan/nan | nan | nan | 0.2578 | 0.7733 | 0.6776 |
| frac_state_reference | nan/nan | nan | nan | 0.3262 | 0.6523 | 0.7455 |
| frac_state_reference | nan/nan | nan | nan | 0.4775 | 0.8525 | 0.7814 |
| frac_state_adaptive - epi | nan/nan | nan | nan | 0.5734 | 0.8541 | 0.8541 |
| frac_sub_IMM | nan/nan | nan | nan | 0.5734 | 0.8541 | 0.8541 |
| cycling | 12.0/nan | nan | nan | 0.6745 | 0.9804 | 0.9339 |
| repair_progenitor | 12.0/nan | nan | nan | 0.8439 | 0.9804 | 0.98 |
| frac_state_cycling | nan/nan | nan | nan | 0.8541 | 0.8541 | 0.8541 |
| reference_PT | 12.0/nan | nan | nan | 0.9804 | 0.9804 | 0.9902 |

## PT_pseudocount_sensitivity — AKI_vs_Ref|pseudo+0.1

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 12.0/18.0 | 2.388 | 2.753 | 6.529e-06 | 5.223e-05 | 5.223e-05 |
| cycling | 12.0/18.0 | 0.9313 | -0.3009 | 2.095e-05 | 5.587e-05 | 5.587e-05 |
| aPT_markers | 12.0/18.0 | 2.072 | 1.572 | 0.0001514 | 0.0002018 | 0.0002018 |
| repair_progenitor | 12.0/18.0 | 1.209 | 0.9783 | 0.001035 | 0.001183 | 0.001183 |
| injury_stress | 12.0/18.0 | 1.702 | 1.622 | 0.01493 | 0.01493 | 0.01493 |

## PT_pseudocount_sensitivity — AKI_vs_Ref|pseudo+0.5

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 12.0/18.0 | 2.778 | 3.275 | 7.963e-06 | 5.587e-05 | 5.587e-05 |
| cycling | 12.0/18.0 | 0.8299 | -0.3661 | 2.095e-05 | 5.587e-05 | 5.587e-05 |
| aPT_markers | 12.0/18.0 | 2.342 | 1.723 | 0.0001514 | 0.0002018 | 0.0002018 |
| repair_progenitor | 12.0/18.0 | 1.233 | 1.022 | 0.002147 | 0.002453 | 0.002453 |
| injury_stress | 12.0/18.0 | 1.88 | 1.772 | 0.01327 | 0.01327 | 0.01327 |

## PT_pseudocount_sensitivity — AKI_vs_Ref|pseudo+1

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 12.0/18.0 | 2.999 | 3.58 | 7.963e-06 | 5.587e-05 | 5.587e-05 |
| cycling | 12.0/18.0 | 0.7557 | -0.3947 | 2.095e-05 | 5.587e-05 | 5.587e-05 |
| aPT_markers | 12.0/18.0 | 2.493 | 1.806 | 0.0001514 | 0.0002018 | 0.0002018 |
| repair_progenitor | 12.0/18.0 | 1.237 | 1.043 | 0.005557 | 0.006351 | 0.006351 |
| injury_stress | 12.0/18.0 | 1.978 | 1.854 | 0.0188 | 0.0188 | 0.0188 |

## infection_sn — COV-AKI_vs_AKI

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_sub_IMM | 4.0/6.0 | 0.04999 | 0.08028 | 0.1143 | 0.1143 | 0.381 |
| frac_state_cycling | 4.0/6.0 | 0.004232 | 0.00827 | 0.1714 | 0.6857 | 0.4286 |
| frac_state_reference | 4.0/6.0 | 0.591 | 0.5348 | 0.4762 | 0.7619 | 0.7937 |
| frac_state_adaptive - epi | 4.0/6.0 | 0.183 | 0.2054 | 0.7619 | 0.7619 | 0.8466 |

## sc_PT — AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_cycling | 12.0/15.0 | 0.04139 | 0.006188 | 0.006733 | 0.0404 | 0.05388 |
| frac_reference | 12.0/15.0 | 0.0922 | 0.1687 | 0.1128 | 0.2486 | 0.2237 |
| repair_index | 12.0/15.0 | 0.3646 | 0.3741 | 0.7884 | 1 | 1 |
| frac_adaptive | 12.0/15.0 | 0.444 | 0.4507 | 0.9417 | 1 | 1 |

## sc_PT — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_reference | 12.0/18.0 | 0.0922 | 0.5224 | 1.733e-05 | 5.059e-05 | 5.691e-05 |
| frac_cycling | 12.0/18.0 | 0.04139 | 0 | 2.446e-05 | 5.059e-05 | 5.691e-05 |
| repair_index | 12.0/18.0 | 0.3646 | -0.3197 | 2.529e-05 | 5.059e-05 | 5.691e-05 |
| frac_adaptive | 12.0/18.0 | 0.444 | 0.2244 | 0.002471 | 0.003707 | 0.003177 |

## sc_PT — CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_reference | 15.0/18.0 | 0.1687 | 0.5224 | 0.0005548 | 0.002171 | 0.003256 |
| repair_index | 15.0/18.0 | 0.3741 | -0.3197 | 0.0007235 | 0.002171 | 0.003256 |
| frac_cycling | 15.0/18.0 | 0.006188 | 0 | 0.001982 | 0.003964 | 0.005946 |
| frac_adaptive | 15.0/18.0 | 0.4507 | 0.2244 | 0.01788 | 0.02682 | 0.02682 |

## sc_PT_pseudobulk — AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| cycling | 12.0/15.0 | 0.7557 | 0.04096 | 0.01041 | 0.04166 | 0.04166 |
| repair_progenitor | 12.0/15.0 | 1.237 | 1.12 | 0.1367 | 0.2734 | 0.2734 |
| reference_PT | 12.0/15.0 | 2.999 | 3.016 | 0.4495 | 0.5993 | 0.5993 |
| aPT_markers | 12.0/15.0 | 2.493 | 2.355 | 0.643 | 0.7348 | 0.7348 |
| injury_stress | 12.0/15.0 | 1.978 | 2.035 | 0.9805 | 0.9805 | 0.9805 |

## sc_PT_pseudobulk — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 12.0/18.0 | 2.999 | 3.58 | 7.963e-06 | 5.587e-05 | 5.587e-05 |
| cycling | 12.0/18.0 | 0.7557 | -0.3947 | 2.095e-05 | 5.587e-05 | 5.587e-05 |
| aPT_markers | 12.0/18.0 | 2.493 | 1.806 | 0.0001514 | 0.0002018 | 0.0002018 |
| repair_progenitor | 12.0/18.0 | 1.237 | 1.043 | 0.005557 | 0.006351 | 0.006351 |
| injury_stress | 12.0/18.0 | 1.978 | 1.854 | 0.0188 | 0.0188 | 0.0188 |

## sc_PT_pseudobulk — CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| aPT_markers | 15.0/18.0 | 2.355 | 1.806 | 0.0001825 | 0.0007301 | 0.0007301 |
| reference_PT | 15.0/18.0 | 3.016 | 3.58 | 0.000939 | 0.001424 | 0.001424 |
| cycling | 15.0/18.0 | 0.04096 | -0.3947 | 0.001068 | 0.001424 | 0.001424 |
| injury_stress | 15.0/18.0 | 2.035 | 1.854 | 0.009735 | 0.01113 | 0.01113 |
| repair_progenitor | 15.0/18.0 | 1.12 | 1.043 | 0.09996 | 0.09996 | 0.09996 |

## sc_adjusted — AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_cycling | 12.0/15.0 | nan | nan | 0.0009889 | 0.006269 | 0.01672 |
| frac_state_adaptive - epi | 12.0/15.0 | nan | nan | 0.001045 | 0.006269 | 0.01672 |
| frac_reference | 12.0/15.0 | nan | nan | 0.004397 | 0.03114 | 0.0406 |
| frac_cycling | 12.0/15.0 | nan | nan | 0.005076 | 0.03114 | 0.0406 |
| frac_cycling | 12.0/15.0 | nan | nan | 0.006733 | 0.03114 | 0.04152 |
| frac_cycling | 12.0/15.0 | nan | nan | 0.007784 | 0.03114 | 0.04152 |
| frac_state_cycling | 12.0/15.0 | nan | nan | 0.009862 | 0.03945 | 0.04508 |
| frac_cycling | 12.0/15.0 | nan | nan | 0.01367 | 0.04373 | 0.05466 |
| frac_state_cycling | 12.0/15.0 | nan | nan | 0.01624 | 0.04871 | 0.05773 |
| frac_state_cycling | 12.0/15.0 | nan | nan | 0.02191 | 0.05258 | 0.07011 |
| repair_index | 12.0/15.0 | nan | nan | 0.02945 | 0.07854 | 0.08568 |
| frac_reference | 12.0/15.0 | nan | nan | 0.04094 | 0.09357 | 0.1092 |
| frac_reference | 12.0/15.0 | nan | nan | 0.1128 | 0.2256 | 0.2776 |
| frac_sub_IMM | 12.0/15.0 | nan | nan | 0.1243 | 0.388 | 0.2841 |
| frac_state_adaptive - epi | 12.0/15.0 | nan | nan | 0.1537 | 0.3075 | 0.328 |
| frac_reference | 12.0/15.0 | nan | nan | 0.1768 | 0.2971 | 0.3495 |
| frac_adaptive | 12.0/15.0 | nan | nan | 0.1857 | 0.2971 | 0.3495 |
| frac_state_adaptive - epi | 12.0/15.0 | nan | nan | 0.2319 | 0.341 | 0.4092 |
| frac_state_reference | 12.0/15.0 | nan | nan | 0.2517 | 0.341 | 0.4092 |
| frac_state_adaptive - epi | 12.0/15.0 | nan | nan | 0.2558 | 0.341 | 0.4092 |
| frac_sub_IMM | 12.0/15.0 | nan | nan | 0.3295 | 0.388 | 0.4926 |
| frac_sub_IMM | 12.0/15.0 | nan | nan | 0.3386 | 0.388 | 0.4926 |
| frac_sub_IMM | 12.0/15.0 | nan | nan | 0.388 | 0.388 | 0.5242 |
| frac_state_reference | 12.0/15.0 | nan | nan | 0.3932 | 0.4525 | 0.5242 |
| frac_state_reference | 12.0/15.0 | nan | nan | 0.4148 | 0.4525 | 0.531 |
| repair_index | 12.0/15.0 | nan | nan | 0.5717 | 0.8316 | 0.7037 |
| repair_index | 12.0/15.0 | nan | nan | 0.6872 | 0.8903 | 0.8116 |
| frac_state_reference | 12.0/15.0 | nan | nan | 0.7101 | 0.7101 | 0.8116 |
| repair_index | 12.0/15.0 | nan | nan | 0.7884 | 0.8903 | 0.8605 |
| frac_adaptive | 12.0/15.0 | nan | nan | 0.8068 | 0.8903 | 0.8605 |
| frac_adaptive | 12.0/15.0 | nan | nan | 0.8347 | 0.8903 | 0.8616 |
| frac_adaptive | 12.0/15.0 | nan | nan | 0.9417 | 0.9417 | 0.9417 |

## sc_adjusted — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_reference | 12.0/18.0 | nan | nan | 4.433e-18 | 5.319e-17 | 1.064e-16 |
| frac_reference | 12.0/18.0 | nan | nan | 1.083e-15 | 6.501e-15 | 1.3e-14 |
| frac_cycling | 12.0/18.0 | nan | nan | 3.103e-14 | 1.241e-13 | 2.483e-13 |
| frac_state_adaptive - epi | 12.0/18.0 | nan | nan | 3.501e-13 | 3.151e-12 | 2.101e-12 |
| repair_index | 12.0/18.0 | nan | nan | 3.351e-12 | 1.005e-11 | 1.608e-11 |
| frac_cycling | 12.0/18.0 | nan | nan | 1.458e-11 | 3.499e-11 | 5.832e-11 |
| frac_state_adaptive - epi | 12.0/18.0 | nan | nan | 7.249e-11 | 3.262e-10 | 2.485e-10 |
| repair_index | 12.0/18.0 | nan | nan | 3.707e-10 | 7.414e-10 | 1.112e-09 |
| frac_state_cycling | 12.0/18.0 | nan | nan | 1.995e-07 | 5.984e-07 | 5.319e-07 |
| frac_state_cycling | 12.0/18.0 | nan | nan | 2.763e-06 | 6.216e-06 | 6.631e-06 |
| frac_state_adaptive - epi | 12.0/18.0 | nan | nan | 5.343e-06 | 9.618e-06 | 1.166e-05 |
| frac_reference | 12.0/18.0 | nan | nan | 1.733e-05 | 2.97e-05 | 3.465e-05 |
| frac_cycling | 12.0/18.0 | nan | nan | 2.446e-05 | 3.372e-05 | 4.336e-05 |
| repair_index | 12.0/18.0 | nan | nan | 2.529e-05 | 3.372e-05 | 4.336e-05 |
| frac_state_cycling | 12.0/18.0 | nan | nan | 5.51e-05 | 8.265e-05 | 8.816e-05 |
| frac_state_reference | 12.0/18.0 | nan | nan | 0.0001118 | 0.0001437 | 0.0001676 |
| frac_state_reference | 12.0/18.0 | nan | nan | 0.0003931 | 0.0004423 | 0.000555 |
| frac_adaptive | 12.0/18.0 | nan | nan | 0.0008465 | 0.001016 | 0.001129 |
| frac_state_reference | 12.0/18.0 | nan | nan | 0.001861 | 0.001861 | 0.002351 |
| frac_sub_IMM | 12.0/18.0 | nan | nan | 0.002147 | 0.00644 | 0.002576 |
| frac_adaptive | 12.0/18.0 | nan | nan | 0.002471 | 0.002696 | 0.002824 |
| frac_adaptive | 12.0/18.0 | nan | nan | 0.005763 | 0.005763 | 0.006287 |
| frac_sub_IMM | 12.0/18.0 | nan | nan | 0.007189 | 0.01078 | 0.007502 |
| frac_sub_IMM | 12.0/18.0 | nan | nan | 0.01441 | 0.01441 | 0.01441 |

## sc_tissue — AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_cycling | 12.0/15.0 | 0.01289 | 0.002705 | 0.0009889 | 0.005933 | 0.03165 |
| frac_sub_IMM | 12.0/15.0 | 0.2198 | 0.1325 | 0.1243 | 0.4971 | 0.3977 |
| frac_state_adaptive - epi | 12.0/15.0 | 0.1551 | 0.1339 | 0.2319 | 0.4472 | 0.5455 |
| frac_state_reference | 12.0/15.0 | 0.5448 | 0.6252 | 0.3932 | 0.4472 | 0.7401 |

## sc_tissue — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_adaptive - epi | 12.0/18.0 | 0.1551 | 0.04664 | 5.343e-06 | 3.206e-05 | 0.000171 |
| frac_state_cycling | 12.0/18.0 | 0.01289 | 0 | 5.51e-05 | 0.0001653 | 0.0008816 |
| frac_state_reference | 12.0/18.0 | 0.5448 | 0.6804 | 0.001861 | 0.003723 | 0.008509 |
| frac_sub_IMM | 12.0/18.0 | 0.2198 | 0.05075 | 0.002147 | 0.01145 | 0.008586 |

## sc_tissue — CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_adaptive - epi | 15.0/18.0 | 0.1339 | 0.04664 | 7.527e-05 | 0.0004516 | 0.002409 |
| frac_state_cycling | 15.0/18.0 | 0.002705 | 0 | 0.006061 | 0.01818 | 0.02771 |
| frac_sub_IMM | 15.0/18.0 | 0.1325 | 0.05075 | 0.009735 | 0.02596 | 0.03461 |
| frac_state_reference | 15.0/18.0 | 0.6252 | 0.6804 | 0.02384 | 0.04768 | 0.06357 |

## severity_meta — stage_meta

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| injury_stress | 83.0/nan | nan | nan | 0.05267 | 0.2081 | 0.2081 |
| repair_progenitor | 83.0/nan | nan | nan | 0.1104 | 0.2081 | 0.2081 |
| cycling | 83.0/nan | nan | nan | 0.1561 | 0.2081 | 0.2081 |
| reference_PT | 83.0/nan | nan | nan | 0.7788 | 0.7788 | 0.7788 |

## sn_PT — AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_cycling | 10.0/13.0 | 0.007154 | 0.004651 | 0.1823 | 1 | 1 |
| repair_index | 10.0/13.0 | 0.2446 | -0.03206 | 0.4757 | 1 | 1 |
| frac_adaptive | 10.0/13.0 | 0.4683 | 0.3046 | 0.6869 | 1 | 1 |
| frac_reference | 10.0/13.0 | 0.2717 | 0.361 | 0.733 | 1 | 1 |

## sn_PT — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_adaptive | 10.0/12.0 | 0.4683 | 0.2423 | 0.1213 | 0.7275 | 0.6902 |
| repair_index | 10.0/12.0 | 0.2446 | 0.01905 | 0.2766 | 0.8298 | 0.6902 |
| frac_cycling | 10.0/12.0 | 0.007154 | 0.01004 | 0.5752 | 0.9314 | 0.9314 |
| frac_reference | 10.0/12.0 | 0.2717 | 0.3272 | 0.8691 | 1 | 1 |

## sn_PT — CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_cycling | 13.0/12.0 | 0.004651 | 0.01004 | 0.07704 | 0.4623 | 0.6934 |
| frac_adaptive | 13.0/12.0 | 0.3046 | 0.2423 | 0.3143 | 0.9429 | 0.7676 |
| frac_reference | 13.0/12.0 | 0.361 | 0.3272 | 0.7648 | 1 | 0.9833 |
| repair_index | 13.0/12.0 | -0.03206 | 0.01905 | 0.8918 | 1 | 1 |

## sn_PT_pseudobulk — AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| repair_progenitor | 4.0/6.0 | 0.9187 | 0.805 | 0.0381 | 0.1524 | 0.1524 |
| aPT_markers | 4.0/6.0 | 1.707 | 1.481 | 0.0381 | 0.1524 | 0.1524 |
| cycling | 4.0/6.0 | -0.05503 | -0.2771 | 0.06667 | 0.1778 | 0.1778 |
| injury_stress | 4.0/6.0 | 1.181 | 1.124 | 0.1143 | 0.2286 | 0.2286 |
| reference_PT | 4.0/6.0 | 2.034 | 2.028 | 0.7619 | 0.8707 | 0.8707 |

## sn_PT_pseudobulk — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| aPT_markers | 4.0/12.0 | 1.707 | 1.522 | 0.05824 | 0.3393 | 0.3393 |
| injury_stress | 4.0/12.0 | 1.181 | 1.031 | 0.1033 | 0.3393 | 0.3393 |
| cycling | 4.0/12.0 | -0.05503 | -0.3317 | 0.1703 | 0.3393 | 0.3393 |
| reference_PT | 4.0/12.0 | 2.034 | 1.859 | 0.2615 | 0.3487 | 0.3487 |
| repair_progenitor | 4.0/12.0 | 0.9187 | 0.9485 | 0.6835 | 0.6835 | 0.6835 |

## sn_PT_pseudobulk — CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| repair_progenitor | 6.0/12.0 | 0.805 | 0.9485 | 0.009696 | 0.07757 | 0.07757 |
| reference_PT | 6.0/12.0 | 2.028 | 1.859 | 0.6165 | 0.9093 | 0.9093 |
| aPT_markers | 6.0/12.0 | 1.481 | 1.522 | 0.682 | 0.9093 | 0.9093 |
| injury_stress | 6.0/12.0 | 1.124 | 1.031 | 0.8201 | 0.9372 | 0.9372 |
| cycling | 6.0/12.0 | -0.2771 | -0.3317 | 0.9636 | 0.9636 | 0.9636 |

## sn_adjusted — AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_sub_IMM | 10.0/13.0 | nan | nan | 0.00871 | 0.03484 | 0.1763 |
| frac_state_cycling | 10.0/13.0 | nan | nan | 0.01102 | 0.111 | 0.1763 |
| frac_state_cycling | 10.0/13.0 | nan | nan | 0.02004 | 0.111 | 0.1868 |
| repair_index | 10.0/13.0 | nan | nan | 0.02335 | 0.3735 | 0.1868 |
| frac_state_adaptive - epi | 10.0/13.0 | nan | nan | 0.02998 | 0.111 | 0.1919 |
| frac_state_adaptive - epi | 10.0/13.0 | nan | nan | 0.03705 | 0.111 | 0.1973 |
| frac_state_adaptive - epi | 10.0/13.0 | nan | nan | 0.04973 | 0.111 | 0.1973 |
| frac_adaptive | 10.0/13.0 | nan | nan | 0.05175 | 0.4001 | 0.1973 |
| frac_state_cycling | 10.0/13.0 | nan | nan | 0.05548 | 0.111 | 0.1973 |
| frac_state_adaptive - epi | 10.0/13.0 | nan | nan | 0.06732 | 0.1154 | 0.2154 |
| frac_adaptive | 10.0/13.0 | nan | nan | 0.08778 | 0.4001 | 0.2554 |
| frac_sub_IMM | 10.0/13.0 | nan | nan | 0.1234 | 0.2349 | 0.3038 |
| repair_index | 10.0/13.0 | nan | nan | 0.13 | 0.4001 | 0.3038 |
| frac_reference | 10.0/13.0 | nan | nan | 0.1329 | 0.4001 | 0.3038 |
| frac_cycling | 10.0/13.0 | nan | nan | 0.1561 | 0.4001 | 0.3241 |
| frac_state_cycling | 10.0/13.0 | nan | nan | 0.1647 | 0.2471 | 0.3241 |
| frac_sub_IMM | 10.0/13.0 | nan | nan | 0.1762 | 0.2349 | 0.3241 |
| frac_cycling | 10.0/13.0 | nan | nan | 0.1823 | 0.4001 | 0.3241 |
| frac_cycling | 10.0/13.0 | nan | nan | 0.2 | 0.4001 | 0.3369 |
| frac_sub_IMM | 10.0/13.0 | nan | nan | 0.2778 | 0.2778 | 0.4445 |
| frac_reference | 10.0/13.0 | nan | nan | 0.2967 | 0.5275 | 0.4521 |
| frac_cycling | 10.0/13.0 | nan | nan | 0.3539 | 0.5662 | 0.5127 |
| frac_state_reference | 10.0/13.0 | nan | nan | 0.3685 | 0.4914 | 0.5127 |
| frac_state_reference | 10.0/13.0 | nan | nan | 0.4297 | 0.5156 | 0.5729 |
| repair_index | 10.0/13.0 | nan | nan | 0.4757 | 0.692 | 0.6089 |
| repair_index | 10.0/13.0 | nan | nan | 0.5712 | 0.7616 | 0.7031 |
| frac_adaptive | 10.0/13.0 | nan | nan | 0.6597 | 0.7819 | 0.7819 |
| frac_adaptive | 10.0/13.0 | nan | nan | 0.6869 | 0.7819 | 0.785 |
| frac_reference | 10.0/13.0 | nan | nan | 0.733 | 0.7819 | 0.8089 |
| frac_reference | 10.0/13.0 | nan | nan | 0.8303 | 0.8303 | 0.8856 |
| frac_state_reference | 10.0/13.0 | nan | nan | 0.8762 | 0.914 | 0.9045 |
| frac_state_reference | 10.0/13.0 | nan | nan | 0.914 | 0.914 | 0.914 |

## sn_adjusted — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_reference | 10.0/13.0 | nan | nan | 0.000692 | 0.004152 | 0.01107 |
| frac_state_adaptive - epi | 10.0/13.0 | nan | nan | 0.003589 | 0.01047 | 0.02792 |
| frac_state_reference | 10.0/13.0 | nan | nan | 0.005784 | 0.01047 | 0.02792 |
| frac_state_adaptive - epi | 10.0/13.0 | nan | nan | 0.006981 | 0.01047 | 0.02792 |
| frac_sub_IMM | 10.0/13.0 | nan | nan | 0.03239 | 0.06477 | 0.1036 |
| frac_state_cycling | 10.0/13.0 | nan | nan | 0.05075 | 0.06091 | 0.1353 |
| frac_sub_IMM | 10.0/13.0 | nan | nan | 0.06717 | 0.06717 | 0.1535 |
| frac_adaptive | 10.0/12.0 | nan | nan | 0.1213 | 0.7376 | 0.2425 |
| frac_state_cycling | 10.0/13.0 | nan | nan | 0.1863 | 0.1863 | 0.3312 |
| frac_adaptive | 10.0/12.0 | nan | nan | 0.235 | 0.7376 | 0.3761 |
| repair_index | 10.0/12.0 | nan | nan | 0.2766 | 0.7376 | 0.4023 |
| repair_index | 10.0/12.0 | nan | nan | 0.5208 | 0.9203 | 0.6944 |
| frac_cycling | 10.0/12.0 | nan | nan | 0.5752 | 0.9203 | 0.7079 |
| frac_cycling | 10.0/12.0 | nan | nan | 0.8191 | 0.9407 | 0.927 |
| frac_reference | 10.0/12.0 | nan | nan | 0.8691 | 0.9407 | 0.927 |
| frac_reference | 10.0/12.0 | nan | nan | 0.9407 | 0.9407 | 0.9407 |

## sn_tissue — AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_cycling | 10.0/13.0 | 0.005916 | 0.002755 | 0.02004 | 0.06011 | 0.1266 |
| frac_state_adaptive - epi | 10.0/13.0 | 0.201 | 0.1303 | 0.06732 | 0.1346 | 0.1958 |
| frac_sub_IMM | 10.0/13.0 | 0.05881 | 0.04006 | 0.2778 | 0.4867 | 0.5157 |
| frac_state_reference | 10.0/13.0 | 0.5613 | 0.5968 | 0.3685 | 0.5528 | 0.5896 |

## sn_tissue — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_reference | 10.0/13.0 | 0.5613 | 0.7809 | 0.005784 | 0.02094 | 0.1073 |
| frac_state_adaptive - epi | 10.0/13.0 | 0.201 | 0.06435 | 0.006981 | 0.02094 | 0.1073 |
| frac_sub_IMM | 10.0/13.0 | 0.05881 | 0.03574 | 0.03239 | 0.1208 | 0.1481 |
| frac_state_cycling | 10.0/13.0 | 0.005916 | 0.002914 | 0.05075 | 0.1015 | 0.1703 |

## sn_tissue — CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| frac_state_reference | 13.0/13.0 | 0.5968 | 0.7809 | 0.02102 | 0.1261 | 0.1947 |
| frac_state_adaptive - epi | 13.0/13.0 | 0.1303 | 0.06435 | 0.1239 | 0.2479 | 0.2644 |
| frac_state_cycling | 13.0/13.0 | 0.002755 | 0.002914 | 0.2382 | 0.3573 | 0.4012 |
| frac_sub_IMM | 13.0/13.0 | 0.04006 | 0.03574 | 0.6444 | 0.7931 | 0.7111 |

## state_DE_gene_sets — adaptive__epi|AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| repair_progenitor | 95.0/nan | -0.2284 | nan | 2.816e-12 | 2.253e-11 | 5.632e-11 |
| repair_progenitor | 95.0/nan | -0.155 | nan | 4.729e-09 | 1.892e-08 | 4.729e-08 |
| injury_stress | 119.0/nan | -0.03552 | nan | 0.03509 | 0.09357 | 0.1404 |
| reference_PT | 39.0/nan | 0.1327 | nan | 0.161 | 0.2146 | 0.2927 |
| injury_stress | 119.0/nan | -0.007108 | nan | 0.2334 | 0.2667 | 0.3591 |
| reference_PT | 39.0/nan | 0.06137 | nan | 0.8457 | 0.8457 | 0.89 |

## state_DE_gene_sets — adaptive__epi|AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| repair_progenitor | 95.0/nan | -0.4098 | nan | 6.501e-12 | 5.201e-11 | 1.3e-10 |
| repair_progenitor | 95.0/nan | -0.3647 | nan | 2.314e-10 | 9.257e-10 | 2.314e-09 |
| injury_stress | 119.0/nan | -0.2164 | nan | 8.028e-05 | 0.0002141 | 0.0003211 |
| injury_stress | 119.0/nan | -0.191 | nan | 0.0001506 | 0.0003013 | 0.0005021 |
| reference_PT | 39.0/nan | -0.115 | nan | 0.02566 | 0.04106 | 0.06415 |
| reference_PT | 39.0/nan | -0.07512 | nan | 0.1477 | 0.1969 | 0.2954 |

## state_DE_gene_sets — adaptive__epi|CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| repair_progenitor | 95.0/nan | -0.24 | nan | 1.367e-07 | 1.093e-06 | 2.734e-06 |
| reference_PT | 39.0/nan | -0.3955 | nan | 1.931e-05 | 7.724e-05 | 9.655e-05 |
| repair_progenitor | 95.0/nan | -0.1219 | nan | 0.0003761 | 0.001003 | 0.001504 |
| injury_stress | 119.0/nan | -0.1635 | nan | 0.0006926 | 0.001385 | 0.002309 |
| injury_stress | 119.0/nan | -0.08469 | nan | 0.002941 | 0.004706 | 0.008404 |
| reference_PT | 39.0/nan | -0.2159 | nan | 0.01435 | 0.01913 | 0.03587 |

## state_DE_gene_sets — degenerative|AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 39.0/nan | -0.3333 | nan | 1.14e-06 | 9.119e-06 | 1.596e-05 |
| injury_stress | 83.0/nan | 0.2314 | nan | 2.993e-06 | 1.197e-05 | 2.095e-05 |
| reference_PT | 39.0/nan | -0.2154 | nan | 2.531e-05 | 6.749e-05 | 0.0001181 |
| injury_stress | 83.0/nan | 0.1732 | nan | 0.0007511 | 0.001502 | 0.002629 |
| repair_progenitor | 61.0/nan | -0.04594 | nan | 0.07214 | 0.1154 | 0.1263 |
| repair_progenitor | 61.0/nan | -0.05106 | nan | 0.2412 | 0.3216 | 0.3376 |

## state_DE_gene_sets — degenerative|AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 39.0/nan | -0.784 | nan | 9.317e-15 | 7.454e-14 | 1.304e-13 |
| reference_PT | 39.0/nan | -0.6959 | nan | 3.627e-13 | 1.451e-12 | 2.539e-12 |
| injury_stress | 83.0/nan | 0.59 | nan | 1.379e-11 | 3.679e-11 | 6.437e-11 |
| injury_stress | 83.0/nan | 0.5368 | nan | 9.74e-11 | 1.948e-10 | 3.409e-10 |
| repair_progenitor | 61.0/nan | 0.08261 | nan | 0.4496 | 0.5138 | 0.5722 |
| repair_progenitor | 61.0/nan | 0.1035 | nan | 0.6502 | 0.6502 | 0.7586 |

## state_DE_gene_sets — degenerative|CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 39.0/nan | -0.6343 | nan | 5.523e-15 | 4.418e-14 | 7.732e-14 |
| reference_PT | 39.0/nan | -0.494 | nan | 6.471e-13 | 2.588e-12 | 4.53e-12 |
| injury_stress | 83.0/nan | 0.5395 | nan | 3.936e-12 | 1.049e-11 | 1.837e-11 |
| injury_stress | 83.0/nan | 0.4009 | nan | 1.563e-09 | 3.125e-09 | 5.47e-09 |
| repair_progenitor | 61.0/nan | 0.2836 | nan | 0.01014 | 0.01622 | 0.01774 |
| repair_progenitor | 61.0/nan | 0.248 | nan | 0.02762 | 0.03683 | 0.03867 |

## state_DE_gene_sets — reference|AKI_vs_CKD

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| injury_stress | 92.0/nan | 0.1755 | nan | 0.000348 | 0.001903 | 0.002537 |
| reference_PT | 39.0/nan | -0.2755 | nan | 0.0006591 | 0.001903 | 0.002537 |
| injury_stress | 92.0/nan | 0.1687 | nan | 0.0008942 | 0.001903 | 0.002537 |
| reference_PT | 39.0/nan | -0.2848 | nan | 0.0009513 | 0.001903 | 0.002537 |
| repair_progenitor | 83.0/nan | -0.031 | nan | 0.4504 | 0.6608 | 0.5544 |
| repair_progenitor | 83.0/nan | -0.01096 | nan | 0.679 | 0.679 | 0.679 |

## state_DE_gene_sets — reference|AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| injury_stress | 92.0/nan | 0.4918 | nan | 2.084e-09 | 1.22e-08 | 2.441e-08 |
| injury_stress | 92.0/nan | 0.493 | nan | 3.051e-09 | 1.22e-08 | 2.441e-08 |
| reference_PT | 39.0/nan | -0.8534 | nan | 1.957e-07 | 4.582e-07 | 9.165e-07 |
| reference_PT | 39.0/nan | -0.8159 | nan | 2.291e-07 | 4.582e-07 | 9.165e-07 |
| repair_progenitor | 83.0/nan | 0.1887 | nan | 0.07386 | 0.1182 | 0.1074 |
| repair_progenitor | 83.0/nan | 0.1471 | nan | 0.1162 | 0.1544 | 0.155 |

## state_DE_gene_sets — reference|CKD_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 39.0/nan | -0.5686 | nan | 6.53e-11 | 5.224e-10 | 1.045e-09 |
| injury_stress | 92.0/nan | 0.3252 | nan | 7.282e-10 | 2.035e-09 | 4.069e-09 |
| reference_PT | 39.0/nan | -0.4733 | nan | 7.63e-10 | 2.035e-09 | 4.069e-09 |
| injury_stress | 92.0/nan | 0.3209 | nan | 1.674e-09 | 3.348e-09 | 6.697e-09 |
| repair_progenitor | 83.0/nan | 0.2184 | nan | 0.0009354 | 0.001497 | 0.002138 |
| repair_progenitor | 83.0/nan | 0.2103 | nan | 0.01026 | 0.01368 | 0.01368 |

## urine_bridge — COVID_yes_vs_no

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| aPT_markers | 17.0/nan | nan | nan | 0.2311 | 1 | 0.9941 |
| reference_PT | 17.0/nan | nan | nan | 0.6605 | 1 | 0.9941 |
| frac_reference | 17.0/nan | nan | nan | 0.7249 | 0.7249 | 0.9941 |
| repair_progenitor | 17.0/nan | nan | nan | 0.8075 | 1 | 0.9941 |
| injury_stress | 17.0/nan | nan | nan | 0.8836 | 1 | 0.9941 |
| cycling | 17.0/nan | nan | nan | 1 | 1 | 1 |

## urine_bridge — KDIGO_stage

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| reference_PT | 15.0/nan | nan | nan | 0.02712 | 0.1356 | 0.1221 |
| injury_stress | 15.0/nan | nan | nan | 0.276 | 0.6899 | 0.6036 |
| repair_progenitor | 15.0/nan | nan | nan | 0.4304 | 0.7173 | 0.6455 |
| frac_reference | 15.0/nan | nan | nan | 0.6499 | 0.6499 | 0.7935 |
| aPT_markers | 15.0/nan | nan | nan | 0.7053 | 0.8817 | 0.7935 |
| cycling | 15.0/nan | nan | nan | nan | 1 | 1 |

## whole_library_pseudobulk_annotated_PT-fraction — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| cycling | 12.0/18.0 | 0.3086 | -0.4467 | 1.739e-16 | 6.957e-16 | 6.957e-16 |
| injury_stress | 12.0/18.0 | 2.052 | 1.921 | 0.01473 | 0.02946 | 0.02946 |
| reference_PT | 12.0/18.0 | 2.383 | 2.365 | 0.07202 | 0.09603 | 0.09603 |
| repair_progenitor | 12.0/18.0 | 1.25 | 1.173 | 0.3007 | 0.3007 | 0.3007 |

## whole_library_pseudobulk_annotated_unadjusted — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| cycling | 12.0/18.0 | 0.3086 | -0.4467 | 1.197e-17 | 4.788e-17 | 4.788e-17 |
| injury_stress | 12.0/18.0 | 2.052 | 1.921 | 0.006635 | 0.01327 | 0.01327 |
| repair_progenitor | 12.0/18.0 | 1.25 | 1.173 | 0.3596 | 0.4795 | 0.4795 |
| reference_PT | 12.0/18.0 | 2.383 | 2.365 | 0.6185 | 0.6185 | 0.6185 |

## whole_library_pseudobulk_library — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| cycling | 41.0/66.0 | 2.529 | 0.6929 | 4.503e-15 | 1.801e-14 | 1.801e-14 |
| injury_stress | 42.0/66.0 | 6.517 | 5.147 | 1.478e-13 | 2.955e-13 | 2.955e-13 |
| repair_progenitor | 42.0/66.0 | 4.773 | 3.847 | 1.028e-10 | 1.371e-10 | 1.371e-10 |
| reference_PT | 42.0/66.0 | 6.929 | 6.374 | 0.04891 | 0.04891 | 0.04891 |

## whole_library_pseudobulk_patient — AKI_vs_Ref

| feature | n | median A | median B | p | FDR(family) | FDR(global) |
|---|---:|---:|---:|---:|---:|---:|
| cycling | 38.0/51.0 | 2.61 | 0.7075 | 1.139e-12 | 4.556e-12 | 4.556e-12 |
| injury_stress | 38.0/51.0 | 6.556 | 5.118 | 3.141e-11 | 6.283e-11 | 6.283e-11 |
| repair_progenitor | 38.0/51.0 | 4.783 | 3.796 | 3.786e-09 | 5.048e-09 | 5.048e-09 |
| reference_PT | 38.0/51.0 | 6.929 | 6.553 | 0.1724 | 0.1724 | 0.1724 |

## 队列人数（用于统一 51 vs 57 争议）

| cohort | group | libraries | participants |
|---|---|---:|---:|
| KPMP whole-library pseudobulk | AKI | 42 | 38 |
| KPMP whole-library pseudobulk | Reference | 72 | 57 |
| KPMP sc (AKI enrollment) | expression matrices | 42 | 38 |
| KPMP AKI manifest (all strategies) | manifest rows (all strategies) | 138 | 70 |
| KPMP sc_ref (Reference enrollment) | expression matrices | 19 | 18 |
| KPMP sc_ckd (CKD enrollment) | expression matrices | 20 | 15 |
| KPMP sn (GSE183277 samples) | expression matrices | 43 | 29 |
| sc_PT_pseudobulk | AKI | 15 | 12 |
| sc_PT_pseudobulk | DKD | 17 | 12 |
| sc_PT_pseudobulk | H-CKD | 3 | 3 |
| sc_PT_pseudobulk | Ref | 19 | 18 |
