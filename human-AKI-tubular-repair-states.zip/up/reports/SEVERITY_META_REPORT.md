# KDIGO 严重度跨队列 meta 分析报告

最后更新：2026-11-05

目的：判断加入独立队列和患者水平聚合后，能否把 AKI 修复/损伤签名的分期趋势从“探索性”升级为“跨队列支持”。

## 数据与方法

| 队列 | 组织 | 样本 | 分期分布 |
|---|---|---|---|
| KPMP sc pseudobulk | 肾组织 | 42 个文库 → 34 个有 KDIGO 分期 → 33 个兼有 cycling 分值 → 聚合为 **30 名患者** | Stage 1=4、Stage 2=9、Stage 3=17 |
| GSE67401 | 外周血（SIRS） | **53 例**有分期 | Stage 1=36、Stage 2/3=17 |

- 同一患者的多个文库先按细胞数加权聚合到患者水平，避免伪重复。
- 每队列内用 Spearman 检验分期趋势；再用 Fisher z 随机效应（DerSimonian–Laird）合并，报告 I²。
- KPMP sn（6 名有分期患者）的细胞状态趋势作为补充，不进入签名 meta。
- 空间部分：16 例 Visium（Stage 1×5、2×5、3×6）的分期趋势在签名为不显著、在 compartment 上名义显著（内皮 rho=−0.63，族内 FDR=0.072），见 `RCTD_REFERENCE_COMPARISON.md`；不进入 meta。
- 数字口径：本报告的 rho/p 与 `FINAL_manuscript_numbers.csv` 的 `severity_meta` / `KDIGO_trend` 层逐项一致。

## 结果

| 签名 | KPMP sc rho (p) | GSE67401 rho (p) | 合并 rho | 合并 p | I² |
|---|---:|---:|---:|---:|---:|
| cycling | 0.299 (0.108) | 0.082 (0.560) | 0.160 | 0.156 | 0% |
| injury/stress | 0.189 (0.318) | 0.233 (0.094) | **0.217** | **0.053** | 0% |
| repair/progenitor | 0.111 (0.560) | 0.217 (0.119) | 0.180 | 0.110 | 0% |
| reference PT | 0.062 (0.745) | 0.016 (0.910) | 0.032 | 0.779 | 0% |

补充：KPMP sn 中 degenerative 状态比例与分期正相关（rho=0.878，p=0.021，n=6），其余状态不显著。

## 关键发现

1. **患者水平聚合后，之前的显著信号消失**：KPMP sc cycling 从样本水平 rho=0.375、p=0.032 降为患者水平 rho=0.299、p=0.108，说明原结果部分由同一患者重复文库造成。
2. **跨队列合并后没有任何签名达到 p<0.05**；injury/stress 最接近（合并 rho=0.217，p=0.053），且两个队列方向一致、异质性为 0。
3. 血液队列（GSE67401）与肾组织队列方向一致，但都不显著；reference PT 完全无趋势。
4. 因此，**现有数据不足以把严重度分析从探索性升级为跨队列支持的关联**。

## 对“补队列 / 空间验证”的判断

- 公共数据中不存在分期均衡且带分子数据的 AKI 队列；KPMP 本身 Stage 3 占多数（临床 59/96，sc 17/30，Visium 约 35–40/62）。
- KPMP Visium/Xenium 空间数据的主要价值是**空间定位与机制验证**，其分期分布同样偏 Stage 3，不能解决均衡性问题；spot 水平还存在伪重复，不能直接当独立样本。
- 即使把空间样本加入 meta，严重度结论仍需谨慎；只有在新增独立、分期均衡、患者水平的队列后，才可能升级为较强结论。
- 若要严重度作为主结论，现实路径是前瞻性或本院的均衡分期队列（配对血/组织、固定采样时间），纯公共干实验无法替代。

## 产物

- 脚本：`scripts/18_severity_meta.py`、`scripts/18a_GSE67401_cycling.R`
- 结果：`results/severity_meta_analysis.csv`、`results/GSE67401_signature_scores_with_cycling.csv`
- 图：`figures/Fig_severity_meta_forest.png/.pdf`
