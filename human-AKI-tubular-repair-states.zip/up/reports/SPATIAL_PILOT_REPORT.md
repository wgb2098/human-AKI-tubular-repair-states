# KPMP Visium 空间报告（16 例扩展版）

最后更新：2026-11-06

目标：验证 AKI 肾组织中 injury/repair/cycling 信号的空间定位，为论文提供"表达 + 空间机制"证据。空间部分不承担严重度升级任务。

2026-11-04 更新：样本从 6 例扩到 16 例；新增 RCTD 解卷积流程（参考含 AKI 状态）。

## 样本

16 个开放 Visium AKI 样本，分期均衡（Stage 1×5、Stage 2×5、Stage 3×6），急性肾小管损伤（ATI）与急性间质肾炎（AIN）混合：

| 患者 | 分期 | 病理裁定 | spot 数 |
|---|---|---|---:|
| 30-11084 | Stage 1 | Acute Tubular Injury | 463 |
| 34-10184 | Stage 1 | Cannot be determined | 455 |
| 34-10666 | Stage 1 | Acute Tubular Injury | 1222 |
| 34-10729 | Stage 1 | Cannot be determined | 1021 |
| 34-11066 | Stage 1 | Acute Tubular Injury | 723 |
| 30-10868 | Stage 2 | Acute Interstitial Nephritis | 484 |
| 30-11072 | Stage 2 | Acute Interstitial Nephritis | 703 |
| 34-10187 | Stage 2 | Acute Tubular Injury | 785 |
| 34-11025 | Stage 2 | Acute Tubular Injury | 533 |
| 936-10217 | Stage 2 | Acute Interstitial Nephritis | 467 |
| 30-10018 | Stage 3 | Acute Interstitial Nephritis | 294 |
| 30-11080 | Stage 3 | Acute Interstitial Nephritis | 1399 |
| 30-11141 | Stage 3 | Acute Tubular Injury | 716 |
| 34-10306 | Stage 3 | Acute Tubular Injury | 455 |
| 34-10331 | Stage 3 | Acute Interstitial Nephritis | 971 |
| 34-11042 | Stage 3 | Acute Tubular Injury | 610 |

全部表达矩阵、空间坐标与实验元数据文件下载完成并通过 zip/gzip 完整性与大小校验（`metadata/spatial_download_verify.json`）。总计 11,301 个 spot（Stage 1: 3,884；Stage 2: 2,972；Stage 3: 4,445）。

## 方法

- 直接从 zip/tar.gz 读取 10x 表达矩阵和 `tissue_positions.csv`，保留组织内 spot；
- 每个 spot 计算 log2 CPM，并用 Klocke gene sets 打 injury/stress、repair/progenitor、cycling、reference PT 分；
- 用 6 近邻计算 Moran's I 评估空间自相关；
- 用 marker 基因给每个 spot 打 PT、TAL、免疫、成纤维、内皮细胞评分；
- 每个样本内做签名与 marker 的 spot 水平 Spearman 共定位；
- RCTD 解卷积：以 GSE210622（含对照、非 COVID AKI、COVID AKI，共 12 细胞类型）为参考，逐样本估计 spot 的细胞类型构成，并与签名做 spot/样本水平关联；
- 与同一患者的 PT 内部单细胞 pseudobulk 做跨模态比较；分期趋势仅作描述。

## 结果

### 空间自相关（Moran's I，16 例范围）

- injury/stress：0.19–0.71
- repair/progenitor：0.27–0.77
- reference PT：0.26–0.81
- cycling：-0.01–0.12（信号弱）

除 cycling 外所有签名在所有样本中均呈正空间自相关，说明信号有明确组织学结构而非随机分布。

### 签名与细胞类型的空间共定位（16 例中位 rho）

| 签名 | PT | TAL | 免疫 | 成纤维 | 内皮 |
|---|---:|---:|---:|---:|---:|
| injury/stress | 0.282 | 0.302 | 0.321 | **0.340** | 0.227 |
| repair/progenitor | **0.322** | **0.322** | 0.281 | 0.299 | 0.246 |
| cycling | 0.101 | 0.064 | 0.122 | 0.083 | 0.065 |
| reference PT | **0.660** | 0.245 | 0.160 | 0.170 | 0.173 |

- injury/repair 信号同时与 PT、TAL、成纤维和免疫细胞正共定位，"损伤—免疫—修复"空间邻接在 16 例中稳定存在；
- reference PT 与 PT marker 强共定位（0.66），验证打分方法可靠；
- cycling 在 spot 水平信号弱（Moran's I 近 0），与 cycling 细胞比例低、55 µm spot 稀释一致。

### 分期趋势

16 例的样本水平分期趋势均不显著（injury rho=-0.15，p=0.59；repair rho=-0.36，p=0.17；reference rho=-0.26，p=0.34；cycling rho=-0.05，p=0.85）。空间样本按分期分层设计，但每例 spot 数差异大且病理类型混杂（ATI/AIN），该分析只作描述，不用于严重度结论。

### 邻域富集（深度校正）

朴素做法（每例内取上四分位 spot、自由置换）会被测序深度混杂：任何高 depth 的 spot 对所有签名都打高分且空间聚集。因此先对每个签名按 log10(总 UMI) 回归取残差，再在 UMI 五分位内做分层置换（500 次），检验"深度校正后高分 spot 是否仍互为邻居"。16 例的 Wilcoxon 符号秩检验（`results/spatial_neighborhood_summary_depthadj.csv`）：

| 组合 | 中位 z | P |
|---|---:|---:|
| repair + repair | +1.74 | 6.1e-05 |
| injury + repair | +1.60 | 1.5e-04 |
| injury + immune | +1.22 | 0.006 |
| repair + immune | +0.86 | 0.006 |
| repair + fibroblast | +0.46 | 0.013 |
| reference PT + PT | +2.32 | 3.1e-04 |
| reference PT + immune | +0.32 | 0.14（不显著） |

injury 与 repair 程序不仅各自空间聚集，而且在邻近 spot 中共现；两者都与免疫细胞邻接，而 reference 状态与免疫细胞无邻接关系。这为"损伤—修复—炎症"空间单元提供了深度校正后的证据。

### RCTD 解卷积（两套参考并行）

**参考 A（GSE210622，9,185 细胞 × 12 类）** 与 **参考 B（KPMP sn，33,514 基因 × 5,502 细胞 × 14 类，含成纤维细胞）** 分别对同一 16 例解卷积，用于回答"为什么不用 KPMP 自己的 snRNA 图谱"。

两套参考的一致性（`reports/RCTD_REFERENCE_COMPARISON.md`）：

| compartment | 样本水平 rho (n=16) | spot 水平 rho (n=10,861) |
|---|---:|---:|
| 免疫 | +0.950 | +0.870 |
| PT | +0.929 | +0.910 |
| TAL | +0.850 | +0.837 |
| 内皮 | +0.829 | +0.861 |
| 足细胞 | +0.603 | +0.572 |
| 远端小管 | +0.462 | +0.361 |

分期趋势在两套参考下方向一致（内皮 rho −0.63/−0.58、TAL −0.52/−0.50、免疫 +0.50/+0.41），KPMP sn 版更保守（FDR 均未过 0.05）。**结论：compartment 比例与分期趋势对参考选择不敏感；KPMP sn 参考额外提供成纤维细胞比例。**


16 例逐一解卷积，参考为 9,185 细胞 × 12 类（Control、non-COVID AKI、COVID AKI 混合）。下游分析（`scripts/30_rctd_downstream.py`）产出：

- `results/spatial_rctd_sample_table.csv`：每例的 compartment 比例与签名均值；
- `results/spatial_rctd_spot_table.csv.gz`：spot 水平表；
- `results/spatial_rctd_spot_correlations.csv` / `spatial_rctd_patient_correlations.csv`：签名与 PT/TAL/远端小管/内皮/免疫/足细胞比例的关系；
- `results/spatial_rctd_stage_trends.csv`：分期趋势。

（具体数值见上述 CSV；RCTD 权重对 LPS/损伤状态的着色可能受参考深度影响，解释时以方向与相对顺序为主。）

### 跨模态

与同一患者单细胞 pseudobulk 的重叠仅 3 例（空间样本多数无 sc 数据），n=3 的相关系数不具统计意义，不作结论。

## 结论

1. 空间证据支持主线的"损伤—修复程序"在组织中具有稳定定位，且与免疫细胞、PT、成纤维空间邻接。
2. cycling 的 spot 水平信号弱，空间部分不适合作为 cycling 结论的来源；cycling 以单细胞/细胞核层面证据为准。
3. 严重度分析不受此扩展影响，仍为探索性；空间分期趋势同样不显著，需更大且均一的样本或前瞻队列。
4. 下一步：继续扩到 30–60 例 Visium；做邻域富集；Xenium 单细胞级验证。

## 产物

- 脚本：`scripts/19_prepare_spatial_pilot.py`、`19e_parallel_download_spatial.py`、`19d_verify_spatial_downloads.py`、`20_spatial_pilot_analysis.py`、`21a_build_rctd_reference.py`、`21b_export_rctd_inputs.py`、`21c_rctd_visium.R`、`30_rctd_downstream.py`
见 `reports/RCTD_RESULTS.md`（自动生成，含每例组成与分期趋势）。

- 结果：`results/spatial_pilot_sample_scores.csv`、`spatial_pilot_spot_scores.csv.gz`、`spatial_pilot_colocalization.csv`、`spatial_pilot_stage_trend.csv`、`spatial_rctd_*.csv`
- 图：`figures/Fig_spatial_pilot_signatures.png/.pdf`（每期最大 2 例的代表性子集）
- 下载清单：`reports/SPATIAL_PILOT_DOWNLOAD_LINKS.md`
