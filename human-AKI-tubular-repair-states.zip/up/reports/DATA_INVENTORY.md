# 数据清单（aki_repair）

统计时间：2026-11-04（最后更新：2026-11-06）。项目总大小约 6.8 GB（已把 2.0 GB 的 GEO 原始 tar 与若干中断下载移出到 `archive/2026-11-04/`）。

## 目录总览

| 目录 | 大小 | 内容 | 使用者 |
|---|---:|---|---|
| `data/KPMP/sc/` | 1.7 GB | 42 个 KPMP 开放 AKI 单细胞表达矩阵（`{file_id}_{file_name}.zip`） | `09_kpmp_pseudobulk.py`、`22_PT_pseudobulk.py` |
| `data/KPMP/sc_ref/` | 240 MB | 18 例 Reference 患者、19 个文库的 sc 矩阵，与 GSE183276 元数据按文库名匹配 | `22_PT_pseudobulk.py`（AKI vs Reference） |
| `data/KPMP/ref/` | 2.0 GB | 74 个手工下载的 Reference 样本矩阵（含未在 atlas 元数据中标注的样本） | `11_combined_pseudobulk.py`（全细胞 pseudobulk） |
| `data/KPMP_spatial/` | 717 MB | 16 例 Visium：表达矩阵 + 空间成像 + 实验元数据 + `rctd_input/` | `20_spatial_pilot_analysis.py`、`21b/21c`、`30_rctd_downstream.py` |
| `data/rctd_reference/` | 238 MB | RCTD 参考：9,185 细胞 × 33,538 基因，12 细胞类型（Control + 非 COVID AKI + COVID AKI） | `21a_build_rctd_reference.py` → `21c_rctd_visium.R` |
| `data/GSE210622/` | 2.0 GB | 独立 sn 队列：14 样本原始矩阵（extracted）+ 系列矩阵/元数据 | `15–17`、`21a`、`26`、`27` |
| `data/GSE183/` | 29 MB | GSE183276（sc）与 GSE183277（sn）细胞级元数据 | `03`、`05`、`12`、`22`、`26` |
| `data/validation/` | 19 MB | GSE139061 bulk 表达与样本表、GSE67401 血液表达与表型 | `07`、`18a`、`18` |
| `data/UrineAKI_github/` | 1.1 MB | 尿液队列公开临床与纵向肌酐/尿量 | `12` |
| `data/GSE122274/` | 7.7 MB | 脓毒症肾活检表达矩阵 | `13` |
| `metadata/` | 9.1 MB | 清单、临床表、下载清单、样本名映射、下载校验 | 全部脚本 |
| `results/` | 26 MB | 结果表（见下） | — |
| `figures/` | 8.5 MB | 全部图（PNG + PDF） | — |
| `reports/` | 140 KB | 各类报告 | — |
| `scripts/` | 284 KB | 39 个脚本 | — |

## 结果表索引（关键）

| 文件 | 说明 |
|---|---|
| `KEY_FINDINGS_AKI_repair.csv` | 汇总关键结果（sc/sn 图谱层 + sc_PT/sn_PT 层） |
| `KPMP_sc_PT_pseudobulk*.csv` | PT 内部 pseudobulk（per-library、per-patient、AKI vs Ref 检验、分期趋势） |
| `GSE210622_PT_pseudobulk*.csv` | 独立 sn 队列 PT 检验与 COVID/非 COVID 比较 |
| `PT_pseudobulk_two_cohorts.csv` | 两队列合并的整洁表 |
| `KPMP_sc_feature_tests.csv` / `KPMP_sn_feature_tests.csv` | 图谱层 AKI vs Ref 与分期趋势 |
| `KPMP_pseudobulk_AKI_vs_Ref_stats.csv` | 全细胞 pseudobulk，42 AKI vs 72 Reference |
| `severity_meta_analysis.csv` | 患者水平跨队列 meta（KPMP sc + GSE67401 血液） |
| `spatial_pilot_*.csv` | 16 例 Visium 签名、共定位、分期趋势 |
| `spatial_rctd_*.csv` | RCTD 解卷积 spot/样本表、相关性、分期趋势 |
| `infection_AKI_*.csv` / `GSE122274_*.csv` | 感染相关 AKI 次要分析 |

## 数据来源

- KPMP 开放仓库（atlas.kpmp.org）：单细胞矩阵、Visium 文件、临床表；
- GEO：GSE183276/GSE183277（KPMP 图谱元数据）、GSE210622（人 AKI snRNA-seq，Kirita 等）、GSE139061、GSE67401、GSE122274；
- GitHub：UrineAKI 尿液队列公开数据。

## 归档与清理记录（2026-11-04）

> 注：下列路径为**归档前的路径**，内容已移至 `archive/2026-11-04/`。


移出项目（保留在 `archive/2026-11-04/`）：

- `data/GSE210622_RAW.tar`（2.03 GB）：GEO 原始 tar，内容已完整解压到 `data/GSE210622/extracted/`；
- `data/GSE183/GSE183276_..._Counts_03282022.RDS.gz.part`（20 MB）：中断下载，已被逐样本矩阵方案取代；
- `data/GSE183276_..._Field_Descriptions.txt.gz.part`（980 B）：中断下载；
- `data/expression_matrix-v2.zip`（18 MB）：无 file_id 前缀的散落单样本矩阵，无脚本引用。

原 `reports/REFERENCE_DOWNLOAD_MISSING.md`、`REFERENCE_DOWNLOAD_TODO.md` 记录的下载任务已全部完成或由 `data/KPMP/sc_ref/` 系统化方案取代，两文件已删除，状态并入本清单。

- `aki_repair_bundle_20261102.tar.gz`（4.4 MB）：11-02 导入工程时的快照。逐文件比对（MD5）后确认：95 个文件中 85 个与当前工程完全一致，8 个已被更新版本取代，仅 `reports/REFERENCE_DOWNLOAD_MISSING.md`、`REFERENCE_DOWNLOAD_TODO.md` 两份已作废的下载清单为包内独有；无任何脚本或文档引用。已移出工程。

## 清理记录（2026-11-05）

> 注：下列路径均为**清理前的路径**，现已被删除或移动到 `archive/`——列出仅为留痕；查找当前文件请以本文顶部的「目录总览」与「当前状态快照」为准。


按"只删确定冗余"的原则删除：

- `comorbidity_analysis/transfer/`（3.3 GB）：VPS 传输区（tar.gz 已解压并 43/43 逐字节校验通过、分片、下载脚本）；
- `aki_repair_results_2026-11-04.zip` / `_filelist.txt` / `aki_repair_release_2026-11-04.tar.gz`：已被 11-05 版取代；
- 3 个 1 字节空输出：`results/KPMP_sc_ATI_vs_AIN.csv`、`results/KPMP_sn_ATI_vs_AIN.csv`、`results/reviewer_pseudobulk_composition_adjusted.csv`（后者功能由 `reviewer_wholelibrary_annotated_tests.csv` 取代）；
- 2 个无引用元数据：`metadata/kpmp_transcriptomics_open_reference.json`、`metadata/kpmp_xenium_open_files.json`（Xenium 未开展）；
- `/tmp` 下一次性测试文件。

未删（按需再定）：`results/*.rds`（358 MB，RCTD 中间对象）、`archive/2026-11-04/GSE210622_RAW.tar`（2.03 GB，内容已解压且分析完成）、`data/rctd_reference/`（238 MB，可 3 分钟重建）。

回收约 3.0 GB：`comorbidity_analysis/` 15 GB → 12 GB。

## 一致性修订（2026-11-05，回应数字审计）

A 类（真冲突，已修）：
1. `AKI_REPAIR_REPORT.md` 旧口径全文 → 加"口径已更新"置顶声明，主结果数字替换为患者级中位数，文末新增"口径变更"对照表；
2. GSE210622 FDR 双版本 → 统一为 4 签名族 **0.001332**，旧 6 特征族 0.0018 明确标注为旧口径（`INDEPENDENT_VALIDATION_GSE210622.md`、`FIGURE_LEGENDS_DRAFT.md`、`AKI_REPAIR_REPORT.md`）；
3. `FINAL_cohort_accounting.csv` 重算：拆分为 `KPMP sc (AKI enrollment, 42/38)`、`KPMP AKI manifest 全策略 (138/70，明细 sc 42 / sn 56 / multiome 40)`、`sc_ref (19/18)`、`sc_ckd (20/15)`、`sn (43/29)`，并加 `detail`/`note` 列说明哪些行真正用于分析；
4. GSE67401 桥接写明：133 样本 = 111 SIRS（53 AKI + 58 非 AKI）+ 22 HD，meta 用 53；
5. `FINAL_manuscript_numbers.csv` 从 13 层扩到 **22 层**，新增 KDIGO 趋势（图谱 68 行 / 空间 GSE210622 17 行 / 空间 KPMP sn 8 行）、严重度 meta、GSE139061、GSE67401、尿液、感染亚组。

B 类（口径说明，已写入 `FINAL_NUMBERS.md` 开头"口径说明"6 条）：sn 参考 13 vs 12；sn PT cycling 方向反转（真实跨平台差异）；FDR 两级非单调（536 行中 112 行 global<family，结论以族内为准）；全库 cycling 41 vs 42；严重度多重 n（42 文库→34 有分期→33 有 cycling 分值→30 患者）；GSE67401 111 vs 53。

### 主报告整体重写（2026-11-05）

`AKI_REPAIR_REPORT.md` 已按 FINAL 表（患者水平/中位数/族内 FDR）**整体重写**，不再保留任何旧口径数字；结论按 A（强）/B（中）/C（探索性）三级重排，每个小节标注来源表；旧值对照表移除（历史口径对照保留在本文件的"一致性修订"段）。重写后逐项核对：6 个关键数字与 FINAL 表完全一致，旧数字（0.196 / 42.9% / 11.6% / AUC=0.72 / "111 例 SIRS" / "6 例 Visium"）在报告中零残留。

## 清理记录（2026-11-05 第二波，全目录范围）

> 注：下列路径均为**清理前的路径**，现已被删除或移动到 `archive/`——列出仅为留痕；查找当前文件请以本文顶部的「目录总览」与「当前状态快照」为准。


在 `comorbidity_analysis` 全域扫描后执行：

1. 删除 `data/KPMP/sn/*.part`（11 个残缺分片，**144 MB**；43 个正式文件已校验入库）与顶层 `__pycache__/`；
2. 删除顶层 `literature/`（**4.3 MB**，与 `aki_repair/literature/` 逐文件相同）；
3. 移动 `results/*.rds`（32 个 RCTD 中间对象，**358 MB**）→ `archive/2026-11-05/rctd_rds/`；
4. 移动四个旧共病工程（**1.8 GB**）→ `archive/2026-11-05/old_comorbidity_projects/`：
   `comorbidity_drylab`、`test0516_*`、`test0521_*`、`Sepsis_AKI_Project_Mitoxyperilysis`；
   归档前验证：`aki_repair` 对其零依赖（`scripts/07` 中 `COMO` 为死常量，已删除；bulk 数据用 `data/validation/` 副本）；
5. 移动 `serve_file.py` → `archive/2026-11-05/utils/`（传输工具，留待 Xenium 阶段复用）；
6. **未动**：`data/KPMP/ref` 与 `data/KPMP/sc_ref` 之间 239 MB 重叠矩阵（前者是全库 pseudobulk 的输入，改动会影响已发布结果的样本集合）。

合计回收约 **2.3 GB**；`comorbidity_analysis/` 由 12 GB 降至 ~9.6 GB（其中 `aki_repair` 9.4 GB）。

## 文档同步（2026-11-05，全 .md 审计）

对 `comorbidity_analysis` 下全部 22 个（报告 + README + 未来计划 + scripts 导航）做了一轮数据与结构同步，共 21 处修改：

- **内容刷新**：`README.md`（数据清单加 CKD/sn、结论加三队列与 CKD、运行顺序加脚本 49/50/52/53/39/40/47）、`METHODS_DRAFT.md`（KPMP 矩阵口径、PT 三队列与自由签名、RCTD 双参考段）、`MANUSCRIPT_OUTLINE_AKI_REPAIR.md`（新增 CKD 证据 2b、图表补 `Fig_PT_three_group` 与 `Fig_UMAP_PT_states`）、`SEVERITY_META_REPORT.md`（n 层级 42→34→33→30、空间口径）、`INFECTION_AKI_REPORT.md`（FDR 改为冻结口径：FIB 0.019、matrisome 0.152）、`PT_LEVEL_VALIDATION.md`（第三队列 KPMP sn）、`未来计划.md`（RCTD 双参考 + 11-05 补充）。
- **口径标注**：`FIGURE_LEGENDS_DRAFT.md`（Figure 5 明确 6 特征族 vs 4 签名族）— 此前一次 patch 静默失败，本次修复；`VALIDATION_CHECKLIST_AKI_REPAIR.md`（GSE210622 行标注 FDR 口径）。
- **历史状态说明**：`RCTD_RESULTS.md`（指向双参考对比）、`OPTIMIZATION_ROUND_2026-11-04.md`（11-05 补充说明）、`SPATIAL_PILOT_DOWNLOAD_LINKS.md`（6 例 pilot 记录 + 当前 16 例状态）、`metadata/DATA_AUDIT_AKI_REPAIR.md`（11-02 快照说明）。
- **结构同步**：顶层 `README.md`（aki_repair 行更新为 sc/sn/CKD/双参考/FINAL 22 层——该轮口径，当前 29 层 / 770 行）。

终检：22 个 .md 引用的 96 个具体文件 **零断链**（含 PNG/PDF 双后缀与花括号记法）；未标注的过时表述零残留（`DATA_INVENTORY` 与 `VALIDATION_CHECKLIST` 中的旧数字均为刻意保留的历史对照或口径标注）。

## 新一轮分析（2026-11-05 晚）

### ① adaptive 状态内的 AKI vs CKD 差异表达（已完成）

患者级状态特异 pseudobulk（`data/state_pseudobulk/`）→ edgeR QL（`scripts/61`）→ 签名/通路竞争检验（`scripts/62`）。核心结果：**adaptive 状态内部 AKI 与 CKD 仅 3 个 DE 基因（FDR<0.05，FDR<0.01 为 0），而同两组相对 Reference 各有 1,500+ 个 DE 基因**——功效充足的阴性，说明急慢差别在"哪些细胞进入该状态"（组成）而非胞内程序；残余差异集中在 **reference 状态**（57 个基因，AKI 侧仍带损伤/炎症印记）。报告：`reports/STATE_DE_REPORT.md`；FINAL 数字表新增 `state_DE_*` 与 `state_DE_gene_sets` 层。

### ② 尿液桥梁（受阻，待数据）

NCBI 对该机出口限速严重（每次尝试仅下到 ~1 MB 即断，485 MB 需数小时以上）；figshare 直接 403。方案：由 VPS 代下 `GSE199321_RAW.tar`（485 MB）后回传（同 sn 矩阵流程）。写法已定：只作"尿液细胞中可量化并与临床同步"的转化叙述，明确声明签名源自该数据集、不作独立性主张。

### ③ 细胞互作（待启动，工具已就绪：CellChat/nichenetr 已安装）

### ②③ 完成（2026-11-06）

- **② 尿液桥梁**：GSE199321 全量矩阵（485 MB，8 路并行取回，`scripts/64_parallel_fetch.sh`）→ 用原论文 23 个簇标记判定细胞类型/状态 + hashing 去卷积池化样本 → 患者级状态比例与签名分值（72,063 细胞；PT 样 57,661；38 样本/30 患者）→ 临床关联与纵向轨迹。报告 `reports/URINE_BRIDGE_REPORT.md`；结果 `results/urine_signature_*.csv`、`results/urine_cell_clusters.csv.gz`；FINAL 新增 `urine_bridge` 层。
- **③ 聚焦配体-受体**：患者级 PT→免疫 LR 打分（10 对）+ 与免疫浸润/PT 签名的一致性 + 16 例 Visium 空间邻域检验。报告 `reports/CELLCOMM_REPORT.md`；结果 `results/cellcomm_*.csv`；FINAL 新增 `cellcomm_LR`、`cellcomm_LR_links` 两层。
- 数据新增：`data/UrineAKI_GEO/`（GSE199321，485 MB）、`data/celltype_pseudobulk/`（PT/IMM/FIB/EC 患者级 pseudobulk）、`data/state_pseudobulk/`（① 用）。
- FINAL 数字表当时为 677 行 / 29 层（**该轮口径**；当前 770 行 / 29 层，见下方快照）。

## 当前状态快照（2026-11-06，含伪计数敏感性）

- 权威数字表：`results/FINAL_manuscript_numbers.csv` — **29 层 / 770 行**（含 state_DE 双模型、urine_bridge、cellcomm 两层）
- 报告 22 份（含 `STATE_DE_REPORT.md`、`URINE_BRIDGE_REPORT.md`、`CELLCOMM_REPORT.md`）
- 交付包 `aki_repair_results_2026-11-06.zip`：**331 文件 / 74 MB**，含 `data/state_pseudobulk/` 与 `data/celltype_pseudobulk/`（可离线复现 edgeR 与配体分析）；归档包 `aki_repair_release_2026-11-06.tar.gz`
- 校验和：`reports/file_checksums.sha256`（341 项，含中间聚合数据；自校验通过）
- 数据总量：`aki_repair/` 约 9.5 GB（新增 GSE199321 485 MB + state/celltype pseudobulk 33 MB）
- 已完成分析：图谱层 / PT 层 / 三队列 PT pseudobulk / 全库 pseudobulk（含组成校正）/ CKD 对照 / KDIGO 趋势与 meta / 空间 16 例双参考 RCTD / 状态内部 DE（sex 与 sex+age 双模型）/ 尿液桥梁 / 聚焦配体-受体 / **伪计数敏感性（+1/+0.5/+0.1，`results/PT_pseudocount_sensitivity.csv`）** / 患者水平与校正模型 / 审稿响应 9 项
- 未做：Xenium（留作 revision）

### 伪计数敏感性（2026-11-06）

PT pseudobulk 的 `log2(CPM+PSEUDO)` 伪计数原为默认 1，属自由参数；用 `PT_PSEUDO` 环境变量重跑 +0.5 与 +0.1：**8 项指标在三档下全部保持方向且 FDR<0.05**（injury/stress 0.013–0.019、repair 0.0012–0.0064，其余 ≤0.0002）。脚本 `scripts/22_PT_pseudobulk.py`（支持 `PT_PSEUDO`），结果 `results/PT_pseudocount_sensitivity.csv` + `*_pseudo05.csv` / `*_pseudo01.csv`，并已并入 FINAL 表的 `PT_pseudocount_sensitivity` 层。
