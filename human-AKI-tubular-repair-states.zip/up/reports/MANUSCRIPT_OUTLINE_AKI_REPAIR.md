# 投稿框架：人 AKI 肾小管适应/修复状态

最后更新：2026-11-06

## 备选题名

1. Single-cell and single-nucleus profiling of human acute kidney injury reveals expansion of adaptive and cycling tubular epithelial states
2. Human kidney single-cell atlas identifies adaptive tubular and immune remodeling signatures in acute kidney injury
3. Adaptive and cycling proximal-tubule states dominate the human acute kidney injury transcriptomic landscape

## 核心论点（按证据强度排序）

1. **最强证据（患者水平、两个平台一致）**：把分析限制在 PT 细胞内部后，AKI 患者的 injury/stress、repair-progenitor、cycling 签名升高、reference-state 签名与状态比例下降；KPMP sc 12 AKI vs 18 Reference 四个签名全部显著（P=8e-06 ~ 0.019），独立 sn 队列 GSE210622（8 AKI vs 6 对照）中 injury/stress、repair-progenitor 以 FDR<0.01 复制（cycling P=0.081、reference 方向不显著，如实报告）。详见 `PT_LEVEL_VALIDATION.md`。
2. **强证据**：AKI 肾脏中 adaptive/repair PT 和 cycling 上皮状态显著扩张，reference PT 显著减少；sc 与 sn 两个独立图谱方向一致。**注意层级**：sn **组织层**的 adaptive-epi 与 reference 在族内 FDR 口径下同样显著（p=0.0070/0.0058，族内 FDR=0.021；全局口径 0.107 仅作敏感性）；但 sn **PT 层**全部不显著（族内 FDR≥0.73），且 sn PT 内 cycling 方向与 sc 相反。正文须按「组织层显著 / PT 层不显著」分层表述。
2b. **强证据（急性 vs 慢性可分，新）**：CKD 对照（15 名患者）显示 adaptive 扩张与 reference 丢失为 AKI/CKD 共有，而 **cycling 扩张为 AKI 特有**（PT 层 p=0.0067、PT 内 pseudobulk p=0.0104）。详见 `AKI_REPAIR_REPORT.md` §4.2/§4.5。
3. **强证据**：基因层面 pseudobulk 显示 AKI 中 cycling（AUC=0.952）、injury/stress（AUC=0.923）和 repair/progenitor（AUC=0.870）签名显著升高；AKI 肾脏中免疫细胞比例升高。
4. **探索性证据（不能作主结论）**：KDIGO 分期趋势——PT 内部 injury/stress 随分期升高（rho=+0.56，p=0.059，n=12）；样本水平 sc cycling rho=0.57（p=0.053）；与 GSE67401 血液 meta 后无签名达 p<0.05。严重度整体保持探索性，详见 `SEVERITY_META_REPORT.md`。
4b. **机制细节（新增，可作讨论亮点）**：急慢差异是**状态组成**而非胞内程序——adaptive 状态内 AKI vs CKD 仅 3 个 DE 基因（**年龄校正后 1 个**；同两组相对 Reference 各 1,564 / 1,390）；且 AKI 中仍标注为 reference 的细胞保留更多损伤/炎症印记（injury +0.18、炎症 +0.50，FDR<0.05；年龄校正后 36/57 保留）。注意：**CKD vs Reference 的效应含年龄成分**（1,562→719），行文需注明。见 `reports/STATE_DE_REPORT.md`。
4c. **转化可行性（探索性）**：同一套程序可在尿液脱落细胞中量化（GSE199321，72,063 细胞），reference 分值随 KDIGO 升高而下降（rho=−0.568，p=0.027，未过 FDR；须声明签名源自该数据集）。见 `reports/URINE_BRIDGE_REPORT.md`。
4d. **阴性结果（写入讨论/局限）**：10 对预设 PT→免疫配体-受体无 AKI 特异差异；仅 ANXA1/MIF 轴与免疫浸润同步（p≈0.04，探索性）。见 `reports/CELLCOMM_REPORT.md`。
5. **探索性/次要结论**：感染相关 AKI 可能具有更强的 cycling/repair 倾向和更差的短期结局（GSE210622 中 COVID-AKI cycling 高于非 COVID AKI，p=0.036），但三个数据源不一致，样本量小，只能作为假设。详见 `INFECTION_AKI_REPORT.md`。

## 图表规划

- Fig 1：研究设计与数据（KPMP sc/sn、Reference sc、KDIGO 样本、bulk/尿液验证、16 例 Visium）。
- Fig 2：**PT 细胞内部 pseudobulk（主图）**：KPMP sc（12 vs 18）+ GSE210622 sn（8 vs 6）四个签名（`Fig_PT_pseudobulk_two_cohorts`；补充 `Fig_PT_pseudobulk_AKI_vs_Ref`）；第三队列 KPMP sn（4 vs 12）作补充图（方向一致、功效不足）。
- Fig 2b：**三组比较（AKI/CKD/Reference）**：`Fig_PT_three_group`（PT 状态比例 + PT pseudobulk）。
- Fig 1b：**PT 细胞 UMAP**（24,917 细胞 / 45 患者，状态与分组着色）：`Fig_UMAP_PT_states`。
- Fig 3：AKI vs Reference 的患者水平效应量条形图 + Stage 均值热图（`Fig_AKI_vs_Ref_and_stage_heatmap`）。
- Fig 4：PT 内部 adaptive/reference/cycling/repair index 与 KDIGO 分期（`Fig_PT_states_KDIGO`）。
- Fig 5：整体状态比例与评分（`Fig_KDIGO_state_scores`）。
- Fig 6：bulk 肾组织签名验证（`Fig_GSE139061_signature_validation`）。
- Fig 7：基因层面 pseudobulk 签名与 KDIGO 分期（`Fig_pseudobulk_signatures_stage`）+ AKI vs Reference（`Fig_pseudobulk_AKI_vs_Ref`）。
- Fig 8：16 例 Visium 空间定位：签名打分、共定位、分期趋势（`Fig_spatial_pilot_signatures`；RCTD 解卷积结果补入 `SPATIAL_PILOT_REPORT.md`）。
- Fig 9：尿液队列肌酐/尿量轨迹（`Fig_urine_trajectories`）。
- Fig 10（可选次要分析）：感染相关 AKI 的临床结局和肾组织签名（`Fig_infection_AKI_urine_clinical`、`Fig_GSE122274_sepsis_signatures`）。使用前需明确写成探索性。

## 需要补强的实验/分析

- ✅ 已补：KPMP Reference 单细胞矩阵（18 例）与 GSE210622（8 AKI vs 6 对照）完成 PT 内部复制。
- ✅ 已补：16 例 Visium 空间样本 + RCTD 解卷积（参考含 AKI 状态）。
- 若有条件，增加蛋白/IHC 验证 aPT 标志物（如 LTF、MMP7、VCAM1、SPP1 等）。
- 对 KDIGO 严重度分析改用更大且分期均衡的队列；当前 Stage 3 占多数，跨队列 meta 后仍无显著结果，公共数据无法补齐。若要写成主结论，需要前瞻性或自有均衡分期队列。
- 空间转录组（Visium/Xenium）只用于空间定位与机制验证；其分期分布同样偏 Stage 3，且 spot 存在伪重复，不能单独升级严重度结论。

## 目标期刊

- 四区：综合性医学、肾脏病/生理学、生物信息学与数据驱动研究期刊中接收单细胞再分析/图谱类论文的刊物。
- 投稿前核对最新分区、APC 和是否存在掠夺性出版风险。
- 不建议声称“脓毒症共病机制”“因果机制”或“Mitoxyperilysis”。

## 若严重度结果始终不显著

- 主线保持为“AKI 上皮状态重塑图谱”，把严重度作为补充分析。
- 或与 bulk 参考 PT 丢失结果合并，写成“reference PT loss and adaptive state expansion in human AKI”。
