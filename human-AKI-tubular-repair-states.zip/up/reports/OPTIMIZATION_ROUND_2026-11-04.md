# 本轮优化总结（2026-11-04）

最后更新：2026-11-05

> **注（2026-11-05）**：本轮之后又完成了：CKD 三组对照（20 矩阵）、KPMP sn 的 PT 级 pseudobulk（第三队列）、**RCTD 换 KPMP sn 参考并做双参考一致性对比**、权威数字总表扩至 22 层、主报告 `AKI_REPAIR_REPORT.md` 整体重写。最新状态以 `reports/DATA_INVENTORY.md` 与 `results/FINAL_manuscript_numbers.csv` 为准。

在你离开期间完成的工作，按证据价值排序。

## 1. 补上了缺失的对照，把主结论升级为细胞类型内结论（最重要）

**问题**：此前"AKI 中 reference PT 信号下降"的结论基于全文库 pseudobulk，混入了 PT 细胞数量变化（AKI 中 PT 比例下降），属于组成混杂，审稿人一定会质疑。

**做法**：
- 从 KPMP 仓库补下 18 例健康 Reference 患者的单细胞矩阵（249 MB，19 个文库）；
- 修正 barcode 解析（每个矩阵自带 barcode 列表，不能共用索引）；
- 只取 `subclass.l1 == "PT"` 的细胞求 pseudobulk，得到 PT 内部表达谱。

**结果**（患者水平 Mann-Whitney）：
| 签名 | AKI (n=12) | Reference (n=18) | P |
|---|---:|---:|---:|
| injury/stress | 1.98 | 1.85 | 0.019 |
| repair-progenitor | 1.24 | 1.04 | 0.0056 |
| cycling | 0.76 | -0.39 | 2.1e-05 |
| reference state | 3.00 | 3.58 | 8e-06 |
| reference 状态比例 | 0.092 | 0.521 | 1.7e-05 |

**独立复制**（GSE210622 sn，8 AKI vs 6 对照，样本名用逐细胞 UMI 匹配解析）：injury P=0.0007、repair P=0.0007（FDR=0.0013）复制成功；cycling P=0.081、reference 方向不显著——如实报告。

产物：`reports/PT_LEVEL_VALIDATION.md`、`Fig_PT_pseudobulk_two_cohorts`、`Fig_PT_pseudobulk_AKI_vs_Ref`、4 个结果表。

## 2. 空间部分从 6 例扩到 16 例，并新增两项空间统计

- 16 例 Visium（Stage 1×5、2×5、3×6）全部下载校验；11,301 个 spot；
- Moran's I：injury 0.19–0.71、repair 0.27–0.77、reference 0.26–0.81、cycling ≈ -0.01–0.12；
- 新增**深度校正的邻域富集**（按 log10 UMI 回归取残差 + UMI 分层置换，500 次）：injury+repair 中位 z=+1.60（P=1.5e-04）、injury+immune z=+1.22（P=0.006）、repair+immune z=+0.86（P=0.006），而 reference+immune 不显著——"损伤—修复—炎症"空间单元有深度校正后的支持；
- **RCTD 解卷积（已完成 16/16）**：重建参考（9,185 细胞 × 12 类，含对照、非 COVID AKI、COVID AKI），16 例逐例解卷积（RCTD full 模式丢弃 UMI<100 的 spot，每例丢弃 0–240 个）。结果（`reports/RCTD_RESULTS.md`）：
  - 内部一致性通过：reference-PT 签名与解卷积 PT 比例在 spot 水平 Spearman rho=+0.57；
  - 免疫比例最高的样本是 AIN 病理的 30-11080（0.40），最低为 ATI 的 34-11066（0.025）；
  - 样本水平分期趋势（n=16）：内皮比例 rho=-0.633（p=0.0085，FDR=0.085）、TAL rho=-0.516（p=0.041，FDR=0.167）、免疫 rho=+0.497（p=0.050，FDR=0.167）；**无特征通过 FDR<0.05**，作为描述性结果；
  - 跨平台参考的比例定标不保证绝对值，已在报告中明确按相对值解释。

产物：`reports/SPATIAL_PILOT_REPORT.md`（已更新）、`spatial_neighborhood_*_depthadj.csv`、`spatial_rctd_*.csv`、`Fig_spatial_pilot_signatures`（每期最大 2 例）。

## 3. 投稿材料补齐

- `reports/METHODS_DRAFT.md`：英文 Methods 草稿（数据来源、签名、PT pseudobulk、空间、RCTD、meta、软件、可用性、局限）；
- `figures/Fig1_study_design.png/.pdf`：研究设计示意图；
- `reports/TABLE1_cohort_characteristics.md` + `results/TABLE1_cohort_characteristics.csv`：队列特征表；
- `MANUSCRIPT_OUTLINE`、`AKI_REPAIR_REPORT`、`VALIDATION_CHECKLIST`、`README`、`未来计划.md` 全部同步更新；
- `KEY_FINDINGS_AKI_repair.csv` 新增 12 行 PT 层结果（`sc_PT`、`sn_PT`）。

## 4. 数据与目录整理

- 归档（移出项目，保留在 `/media/desk16/iy16128/archive/2026-11-04/`）：`GSE210622_RAW.tar`（2.03 GB，内容已解压）、两个中断下载 `.part` 文件、一个无引用的散落矩阵 zip；
- 项目体积从约 8.9 GB 降到 6.8 GB；
- 新增 `reports/DATA_INVENTORY.md`：所有数据目录、使用者脚本、结果表索引与归档记录；
- 删除已被取代的 `REFERENCE_DOWNLOAD_MISSING.md` / `REFERENCE_DOWNLOAD_TODO.md`（状态并入数据清单）。

## 5. 仍未解决的（受公共数据限制，无法通过再分析突破）

1. KDIGO 严重度：PT 内部 injury/stress 随分期升高但仅接近显著（rho=+0.56，p=0.059，n=12）；跨队列 meta 无签名达 p<0.05；空间 16 例分期趋势不显著。需要前瞻性或分期均衡的自有队列。
2. 真正共病设计（SA-AKI vs Sepsis non-AKI）：公共开放数据不存在符合条件的四组队列，需受控数据（KPMP DUA、dbGaP/EGA）或自有队列。
3. 无湿实验验证（IHC/qPCR/ELISA）。

## 6. 交付包

`/media/desk16/iy16128/comorbidity_analysis/aki_repair_results_2026-11-04.zip`（188 个文件，11.7 MB，含脚本、结果表、18 张图（PNG+PDF）、全部报告；不含原始数据与 RCTD 中间 .rds 文件）。
