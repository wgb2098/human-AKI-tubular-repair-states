# ② 尿液桥梁：同一套肾小管程序在尿液细胞中的量化与临床关联

生成时间：2026-11-06

**循环性声明**：本项目的四个签名源自该数据集（Klocke et al., GSE199321）本身，因此本分析**不作"独立验证"主张**，只回答两个问题：(1) 能否在尿液细胞中量化同一套状态/程序？(2) 这些量化值是否与临床严重度/恢复同步？

## 数据与流程

- 数据：GSE199321 全部 37 套矩阵（`data/UrineAKI_GEO/GSE199321_RAW.tar`，485 MB，8 路并行取回，sha256 校验）；43 例单患者样本（6 名患者有多个时间点）+ 6 个池化样本；
- 细胞类型/状态：**用原论文自己的 23 个簇标记**（`results/urine_cluster_markers.csv`，每簇 top 25 基因、文库内基因 z 标准化后取均值、argmax 判定）；
- 池化样本按 4 个 hashing 标签（CD298B0251-254）去卷积到患者，成功率 19,415/24,342（80%）；
- 每患者：PT 样细胞的状态比例（PCT=reference；TEC_dmg/MMP7/IL32/LIF/IFIT=injury；TEC_prlf/prg1-4=repair-prolif）、四签名中位分值。

**规模**：72,063 个细胞（QC ≥200 UMI/≥100 基因），PT 样 57,661；可分析样本 38（30 名患者），其中 15 个样本有 KDIGO 分期。

## 结果

1. **可行性成立**：尿液细胞可稳定落入原论文的 PT 状态簇，每患者可给出状态比例与签名分值（如 P016：injury 0.24 / repair-prolif 0.67 / reference 0.008；P050：injury 0.18 / repair-prolif 0.21 / other-TEC 0.61）。
2. **与分期（探索性，n=15，全部未过 FDR）**：
   - `reference_PT` 分值随 KDIGO 升高而降低：rho=**−0.568，p=0.027**（方向与组织结果一致：越严重，reference 程序越少）；
   - `frac_injury` 与分期**反向**：rho=−0.641（p=0.010，中位 0.53/0.36/0.26 by stage 1/2/3）——与预期相反；
   - 检查混杂：采样时间点与分期无相关（rho=0.12，p=0.68），`frac_injury` 与采样时间无相关（rho=−0.19，p=0.50）；CVVHD 患者细胞数反而更多（中位 1335 vs 117，p=0.082），因此不能用"细胞数减少"解释；
   - 结论：**反向关系机制未明**，可能是重度 AKI 时损伤态细胞滞留于组织/脱落动力学改变，或簇判定的灵敏度差异；仅作现象记录。
3. **纵向可量化**：14 个连续采样（6 名患者），例如 P002 两个时间点 injury 比例 0.23→0.44、injury 分值 0.254→0.516；P019 repair-prolif 0.39→0.66。可用于"无创随访"的叙述，但需更多患者才能做统计。
4. **感染/结局**：COVID 与非 COVID、90 天结局、RRT 的分组比较样本量均不足（n≤17），无显著结果。

## 可用于正文的表述

> 同一套肾小管损伤/修复程序可在**尿液脱落细胞**中被量化，并能按状态拆解；其中 reference 程序的分值随 KDIGO 分期升高而下降，方向与肾脏组织中的结果一致（n=15，p=0.027，未过 FDR）。损伤态比例为反向趋势，机制未明，需前瞻队列验证。

## 产物

- 脚本：`scripts/65b_urine_bridge_v2.py`（v1 见 `65_urine_signature_bridge.py`）、`results/urine_cluster_markers.csv`（R 导出的原论文簇标记）
- 结果：`results/urine_signature_scores.csv`（样本级）、`results/urine_signature_clinical.csv`（临床关联）、`results/urine_signature_longitudinal.csv`、`results/urine_cell_clusters.csv.gz`（细胞级）
