# 独立验证队列：GSE210622

最后更新：2026-11-05

> **FDR 口径提示（2026-11-05）**：本表 PT 层新值为 4 签名族的 BH 校正（injury/repair/cycling/reference，与 `FINAL_manuscript_numbers.csv` 一致）；表中 0.0018 属早期 6 特征族口径，勿与新值混用。


> 交叉引用（2026-11-04）：本报告的 PT 内部结果已由 `scripts/26_GSE210622_PT_pseudobulk.py` 独立重算，并把 AKI1–AKI8 与元数据样本名的映射用逐细胞 UMI 匹配固化（`metadata/GSE210622_AKI_file_map.json`）。结论一致：injury/stress、repair/progenitor 在 AKI 中显著升高（PT 内部 P=0.0007，FDR=0.0013），cycling 为趋势（P=0.081），reference PT 无差异。汇总见 `reports/PT_LEVEL_VALIDATION.md`。

数据：人肾组织单核转录组，106,971 个细胞、14 个样本，包含：
- Control：5 个样本（Control-15min/60min/120min/TN1/TN2/TN3）
- 非 COVID AKI：3 个样本（P3sepsis、Pat17、Pat20）
- COVID AKI：5 个样本（P1cov、P2cov、P13cov、P15cov、P4cov）

细胞类型注释：PT、TAL、EC、CD-PC、tL、IntC、DCT、CNT、CD-IC-A/B、Leuk、Podo。

## 细胞组成验证结果

患者/样本水平比较（Mann–Whitney，BH FDR）：

| 细胞类型 | Control 平均 | 非 COVID AKI | COVID AKI | Control vs AKI P | FDR |
|---|---:|---:|---:|---:|---:|
| PT | 0.339 | 0.314 | 0.238 | 0.228 | 0.548 |
| TAL | 0.286 | 0.239 | 0.309 | 0.950 | 0.950 |
| Leuk | 0.013 | 0.035 | 0.019 | 0.059 | 0.178 |
| EC | 0.098 | 0.102 | 0.104 | 0.414 | 0.709 |
| CD-PC | 0.057 | 0.087 | 0.090 | 0.013 | 0.080 |
| Podo | 0.005 | 0.027 | 0.017 | 0.020 | 0.080 |
| CD-IC-A | 0.017 | 0.024 | 0.031 | 0.020 | 0.080 |

- PT 比例在 AKI 中降低（非 COVID 0.314、COVID 0.238，对照 0.339），方向与 KPMP 的 reference PT 减少一致，但未通过 FDR。
- Leuk 在非 COVID AKI 中升高（0.035 vs 对照 0.013，P=0.059），方向与 KPMP 免疫浸润增加一致。
- 非 COVID AKI 与 COVID AKI 之间没有显著组成差异（所有 P≥0.2）。
- 由于每组样本仅 3–5 个，且这里只有大类注释（没有 adaptive/cycling 状态），组成分析只能算方向性支持。

## 基因层面签名验证（已完成）

14 个样本全部完成聚合；样本归属通过矩阵计数总量与元数据 nCount 匹配确认（例如 AKI1 总计数 33,351,356 vs 期望 33,485,480）。比较 Control（6）vs AKI（非 COVID 4 + COVID 4）：

| 层级 | 签名 | Control 均值 | AKI 均值 | P | FDR |
|---|---|---:|---:|---:|---:|
| 所有细胞 | injury/stress | 1.030 | 1.410–1.509 | 0.00067 | 0.0018（旧 6 特征族口径） |
| 所有细胞 | repair/progenitor | 0.865 | 0.983–1.012 | 0.0013 | **0.0027** |
| 所有细胞 | cycling | -0.569 | -0.449–-0.425 | 0.029 | **0.047** |
| 所有细胞 | reference PT | 1.595 | 1.535–1.573 | 1.00 | 1.00 |
| PT 细胞 | injury/stress | 0.808 | 1.253–1.384 | 0.00067 | **0.001332**（现行 4 签名族口径） |
| PT 细胞 | repair/progenitor | 0.785 | 0.915–0.948 | 0.00067 | **0.001332**（现行 4 签名族口径） |
| PT 细胞 | cycling | -0.503 | -0.476–-0.388 | 0.081 | 0.108 |
| PT 细胞 | reference PT | 2.136 | 1.986–2.130 | 0.41 | 0.47 |

- 独立队列中 **injury/stress 和 repair/progenitor 在 AKI 中显著升高，且在 PT 细胞内部仍然显著**，方向与 KPMP 主分析一致。
- cycling 在所有细胞中显著（FDR=0.047），PT 细胞内部为趋势（FDR=0.108）。
- reference PT 签名无差异；这与其细胞比例在 AKI 中降低不完全一致，提示 pseudobulk 总文库组成和签名特异性仍需谨慎。
- 非 COVID AKI 与 COVID AKI 在所有签名上均无显著差异（P≥0.11），与前面感染相关分析一致。

## 产物

- `results/GSE210622_sample_celltype_fractions.csv`
- `results/GSE210622_composition_tests.csv`
- `results/GSE210622_signature_scores.csv`
- `results/GSE210622_signature_tests.csv`
- `figures/Fig_GSE210622_composition.png/.pdf`
- `figures/Fig_GSE210622_signature_validation.png/.pdf`
- `scripts/15_GSE210622_composition.py`、`scripts/17_GSE210622_fast.py`
