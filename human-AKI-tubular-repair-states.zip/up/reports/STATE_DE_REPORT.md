# ① adaptive 状态内部的 AKI vs CKD 差异表达（患者级 pseudobulk）

生成时间：2026-11-06

问题：此前"急慢可分"只做了**状态比例**（cycling 扩增为 AKI 特有）。本分析追问：**同样是 adaptive 状态的 PT 细胞，急性与慢性的转录程序是否不同？**

## 方法

- 按患者聚合各 PT 状态的原始 counts（`data/state_pseudobulk/`，`scripts/60`），同一患者多文库求和；
- 三套状态矩阵：adaptive-epi（40 例 / 11,936 细胞；AKI 12 / CKD 13 / Ref 15）、degenerative（39 例 / 8,592；12/14/13）、reference（40 例 / 7,711；10/14/16）；cycling 仅 6 例，不足；
- edgeR quasi-likelihood（`scripts/61`）：`~ 0 + group + sex`，三组两两对比，robust QL F 检验，BH FDR；
- 签名/通路层面（`scripts/62`）：对每个基因集用 Mann-Whitney 竞争检验（集合内 logFC vs 背景），BH 校正。

## 结果一：adaptive 状态内部，AKI 与 CKD 几乎没有差异（功效充足的阴性）

| PT 状态 | n (AKI/CKD) | AKI vs CKD（FDR<0.05） | AKI vs Ref | CKD vs Ref |
|---|---|---:|---:|---:|
| **adaptive-epi** | 12 / 13 | **3 个基因**（FDR<0.01 为 0） | 1,564 | 1,562 |
| degenerative | 12 / 14 | 14 | 866 | 415 |
| reference | 10 / 14 | **57** | 1,514 | 665 |

同一管线、同一 n，两组相对健康肾各自有 **1,500+ 个 DE 基因**——因此 adaptive 内的"无差异"**不是功效问题，而是真实结果**。

签名层面（adaptive，AKI vs CKD）：仅 repair-progenitor 通过 FDR（中位 logFC −0.23，FDR<0.001，即在 adaptive 细胞内 CKD 的修复-增殖程序略高）；FAO（+0.16）与炎症（−0.23）仅名义显著。

**解释**：急慢之间的差别主要体现在**哪些细胞进入 adaptive 状态**（组成），而不是进入之后的胞内程序；这与"cycling 扩增为 AKI 特有"互为印证——即 AKI 的特异性在于状态丰度，而非状态内容。

## 结果二：残留差异集中在 reference 状态（新的机制线索）

在仍被标注为 reference 状态的细胞里，AKI 比 CKD 保留了更多损伤信号（全部 FDR<0.05）：

| 对比 | 集合（中位 logFC） | 方向 |
|---|---|---|
| reference 状态 AKI vs CKD | injury/stress +0.18、reference-PT −0.28、炎症 +0.50、纤维化 +0.28、FAO −0.18 | AKI 侧仍"更受伤" |
| degenerative AKI vs CKD | reference-PT −0.33、injury/stress +0.23、FAO −0.21 | 同方向 |

即：**AKI 中未被重编程的细胞仍带有残余损伤/炎症印记，而 CKD 的 reference 细胞更"干净"**。这为"急性 vs 慢性"提供了第二条（细胞内，而非组成层面的）线索，可作为讨论中的机制假设。

## 结果三：adaptive 程序本身是"低炎症、低损伤"的共享程序

adaptive 细胞内相对 Reference：AKI 与 CKD **都**表现为 injury/stress 与炎症基因集**下调**（AKI：injury −0.22、炎症 −1.19；CKD：injury −0.16、炎症 −0.91，均 FDR<0.05）；而 degenerative 状态中两组的纤维化集合都大幅上调（AKI +1.46、CKD +1.05）。说明 adaptive 是一个共享的"应激后重编程"状态，degenerative 才是纤维化相关状态。

## 结果四：年龄敏感性（审稿人预期问题）

`scripts/61` 现同时输出两套模型（`~ 0 + group + sex` 与 `~ 0 + group + sex + age`；年龄 45/45 可得，AKI 中位 54.5 / CKD 64.5 / Ref 44.5）：

| 状态 | 对比 | DE（sex） | DE（sex+age） | 重叠 | logFC rho |
|---|---|---:|---:|---:|---:|
| adaptive | AKI vs CKD | 3 | **1** | 0 | 0.964 |
| adaptive | AKI vs Ref | 1,564 | 1,390 | 1,334 | 0.991 |
| adaptive | CKD vs Ref | 1,562 | **719** | 699 | 0.955 |
| degenerative | AKI vs CKD | 14 | 9 | 9 | 0.969 |
| reference | AKI vs CKD | 57 | **36** | 36 | 0.988 |
| reference | AKI vs Ref | 1,514 | 1,457 | 1,358 | 0.989 |
| reference | CKD vs Ref | 665 | 473 | 436 | 0.938 |

- **①的核心阴性结论在年龄校正后更强**：adaptive 内 AKI vs CKD 从 3 个降到 1 个 DE 基因；
- **reference 状态的残余差异不是年龄驱动**：基因集检验在 sex+age 模型下几乎不变（injury_stress +0.169/FDR=0.0025、reference_PT −0.285/0.0025、inflammation +0.438/0.0031、fibrosis +0.299/0.045）；
- 附带发现（须写入局限）：**CKD vs Reference 的效应部分来自年龄**（CKD 患者中位 64.5 岁 vs Ref 44.5 岁）——adaptive 状态 1,562→719、reference 状态 665→473。此前三组比较未校正年龄，正文提到"CKD 共享 adaptive 扩张"时应注明该对比含年龄成分，或引用年龄校正后的数字。

## 局限

- 每组 10–14 例，不能排除更小的效应（FDR<0.05 检出下限）；未做细胞周期回归（adaptive 状态内 cycling 基因残余）;
- 状态标签来自原图谱作者，重新聚类可能改变边界；
- 未纳入 sn 队列（PT 状态细胞数不足）。

## 产物

- 脚本：`scripts/60_export_state_pseudobulk.py`、`scripts/61_state_DE.R`、`scripts/62_state_DE_gene_sets.py`
- 数据：`data/state_pseudobulk/`（3 套 counts + 样本表 + 元数据）
- 结果：`results/state_DE_{state}_{contrast}.csv`（9 张 DE 表）、`results/state_DE_summary.csv`、`results/state_DE_gene_set_tests.csv`
