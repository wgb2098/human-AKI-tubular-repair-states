# ③ 聚焦版细胞互作：PT 配体 → 免疫受体（AKI vs CKD vs Reference）

生成时间：2026-11-06

**设计**：不做全库 CellChat，只检验一个预设假设——"适应性/损伤 PT 细胞分泌的配体在 AKI 中升高，并与其免疫受体的表达及免疫浸润同步"。使用 10 对预设配体-受体（SPP1、MIF、ANXA1、CXCL12、CCL2、VEGFA、MDK、LCN2、LGALS1、TIMP1）；受体集均按文献核对（**LGALS1 已由 CD69 更正为 PTPRC/ITGB1/NRP1**——galectin-1 的经典结合伙伴为 CD45、β1 整合素与 neuropilin-1，CD69 不是其受体），全部为患者级统计。

## 数据

- 患者级 pseudobulk：PT（44 例）与 IMM（42 例）由 `scripts/63` 导出（PT 42 例、IMM 42 例可用于配对）；
- 空间：16 例 Visium，配体表达直接取自 spot 矩阵（z 标准化），免疫强度用 6 近邻的免疫 marker 分均值；
- 成纤维受体分析**未做**：FIB 患者级 pseudobulk 仅 7 例（<20 细胞者被剔除），功效不足。

## 结果

### 1. 患者级 LR 打分：没有 AKI 特异的配体-受体轴

AKI 12 / CKD 14 / Ref 16，所有 10 对在 AKI vs CKD、AKI vs Ref 上**均未通过 FDR**（最大效应仅为名义趋势：MIF 复合分 p=0.074、LGALS1 p=0.082；SPP1 复合分 AKI 最高 0.407 vs CKD 0.023 vs Ref 0.404，p>0.10）。
→ **PT→免疫的配体信号在急慢性之间没有差异**，与①在胞内程序层面的结论一致。

### 2. 与免疫浸润同步的只有 ANXA1 与 MIF（名义显著，n=42）

| 配体（受体集合） | LR 分 vs 免疫细胞比例 | p |
|---|---:|---:|
| ANXA1（FPR1+FPR2） | **rho=+0.322** | 0.037 |
| MIF（CD74+CXCR4+CD44） | **rho=+0.308** | 0.048 |
| VEGFA（KDR+FLT1） | +0.183 | 0.246 |
| SPP1（CD44+ITGB1+ITGAV） | −0.280 | 0.073 |

同时，所有 LR 分与 PT 的 injury/repair 签名**几乎不相关**（|rho|<0.21，p>0.25）→ 配体表达不是损伤程序的简单下游，而是相对独立的轴。ANXA1（抗炎/促修复清除信号）与 MIF（髓系招募）与免疫浸润同步，方向合理但样本量小、未过多重校正。

### 3. 空间：PT 配体与邻近免疫细胞普遍弱正相关（16 例中位 rho）

ANXA1 +0.139、TIMP1 +0.101、CCL2 +0.092、MDK +0.074、LGALS1 +0.063、LCN2 +0.057、CXCL12 +0.051、VEGFA +0.047、SPP1 +0.038、MIF +0.037。

**全部为正但都很弱**，且方向与患者级结果不一致（患者级 ANXA1/MIF 最强，空间里 ANXA1 最强但 MIF 最弱）→ 提示这是**非特异的组织学邻近**（上皮与免疫细胞在每个切片里本就相邻，此前深度校正邻域富集已量化过），不能作为配体特异性的证据。

## 结论与写法

- **阴性为主**：未发现 AKI 特异的配体-受体轴；PT→免疫的耦合在各组间一致。
- 唯一可写的正向线索：**ANXA1 与 MIF 的 PT→免疫轴与免疫浸润程度同步**（n=42，p≈0.04，探索性），可作为讨论中的假设（"上皮通过 ANXA1/MIF 参与髓系调节"），不能进主结论。
- 若要升级为机制证据，需要真实配体-受体扰动（类器官/共培养）或用 CellChat 全库推断 + 空间配体-受体邻接显著性检验，属于 revision 阶段工作量。

## 产物

- 脚本：`scripts/66_focused_ligand_receptor.py`、`scripts/63_export_celltype_pseudobulk.py`
- 结果：`results/cellcomm_LR_scores.csv`（患者×配体对）、`cellcomm_LR_tests.csv`（组间检验）、`cellcomm_LR_links.csv`（与免疫浸润/PT 签名的一致性）、`cellcomm_spatial_ligand_immune.csv`（16 例空间）
