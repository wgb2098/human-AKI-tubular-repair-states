# 验收清单：AKI 修复方向

最后更新：2026-11-06

## 1. 先看结论

- `reports/AKI_REPAIR_REPORT.md` 第 1 节和第 6 节。
- 主结论：AKI 中 adaptive/cycling PT 状态扩张、reference PT 减少；KDIGO 严重度梯度弱，不能作主结论。

## 2. 核对数据来源

- KPMP 开放临床表：`metadata/20260930_OpenAccessClinicalData.csv`（973 人，AKI 118，96 例有 KDIGO 分期）。
- 细胞级元数据：
  - `data/GSE183/GSE183276_..._scCv3_Metadata_03282022.txt.gz`（109,741 细胞）。
  - `data/GSE183/GSE183277_..._snCv3_Metadata_03282022.txt.gz`（203,702 细胞）。
- 尿液队列：`data/UrineAKI_github/Urine_AKI_patient_data.csv`、`Urine_AKI_urine_output_crea_data.csv`。
- bulk 验证：`data/validation/GSE139061_Eadon_processed_QN_101419.csv.gz`（项目内副本；旧共病目录已于 2026-11-05 归档到 `archive/2026-11-05/old_comorbidity_projects/`）。
- 数据审计：`metadata/DATA_AUDIT_AKI_REPAIR.md`。

## 3. 核对关键数字

| 文件 | 关键数字 |
|---|---|
| `results/KPMP_sc_feature_tests.csv` | AKI vs Ref：adaptive FDR=1.1×10⁻⁴、cycling FDR=6.3×10⁻⁴、reference FDR=0.0069、immune FDR=0.0070、aEpi FDR=0.0030 |
| 同上 | 分期趋势：cycling rho=0.57（p=0.053）；其余 FDR>0.64 |
| `results/KPMP_sn_feature_tests.csv` | adaptive FDR=0.030、reference FDR=0.030、cycling FDR=0.085 |
| `results/KPMP_sc_adjusted_stage_models.csv` | cycling beta p=0.018，FDR=0.50；其余不显著 |
| `results/KPMP_sc_PT_state_tests.csv` | 旧的样本级口径：adaptive FDR=0.0018、reference/cycling/repair index FDR=4.9×10⁻⁵。**现行患者级口径见 `FINAL_manuscript_numbers.csv`（sc_PT 层）：adaptive FDR=0.0037、reference/cycling FDR=5.1×10⁻⁵** |
| `results/urine_recovery_correlation.csv` | n=6，rho=-0.21，p=0.69 |
| `results/GSE139061_signature_validation.csv` | reference PT AUC=0.72，p=0.045；repair/injury 不显著 |
| `results/GSE67401_blood_signature_validation.csv` | 三个签名均不显著（p>0.09） |
| `results/KPMP_sc_pseudobulk_signatures.csv` | 42 个 AKI 样本；cycling 分期 rho=0.375，p=0.032，n=33；其余签名不显著 |
| `results/KPMP_pseudobulk_AKI_vs_Ref_stats.csv` | 42 AKI vs 72 Reference；cycling AUC=0.952（FDR=9.0×10⁻¹⁵）、injury AUC=0.923（FDR=1.5×10⁻¹³）、repair AUC=0.870（FDR=6.9×10⁻¹¹）、reference PT AUC=0.613（FDR=0.024，方向需谨慎） |
| `results/infection_AKI_urine_tests.csv` | 感染相关 15 vs 非感染 17：KDIGO p=0.71、RRT p=0.072、90 天结局 p=0.014 |
| `results/GSE122274_sepsis_signature_tests.csv` | 脓毒症 5 vs 非脓毒症 10：cycling MW p=0.019、repair/progenitor 校正 p=0.027（均未过严格 FDR） |
| `results/GSE210622_composition_tests.csv` | 独立队列组成验证：PT Control 0.339 vs AKI 0.238–0.314（FDR=0.548）；Leuk 非 COVID AKI 0.035 vs Control 0.013（P=0.059） |
| `results/GSE210622_signature_tests.csv` | 独立队列基因层面（**旧 6 特征族口径**）：所有细胞 injury FDR=0.0018、repair FDR=0.0027、cycling FDR=0.047；现行 4 签名族口径为 **FDR=0.001332**（见 `FINAL_manuscript_numbers.csv` 的 GSE210622_PT_pseudobulk 层）；PT 内部 injury/repair FDR=0.0018；非 COVID vs COVID 均不显著 |
| `results/KPMP_sc_PT_pseudobulk.csv` / `_patient.csv` | PT 内部 pseudobulk：12 AKI 患者（9,272 PT 细胞）vs 18 Reference 患者（4,853 PT 细胞）；每文件独立 barcode 解析 |
| `results/KPMP_sc_PT_pseudobulk_AKI_vs_Ref.csv` | injury P=0.019、repair P=0.0056、cycling P=2.1e-05、reference P=8e-06（FDR 均 <0.007）；reference-state 比例 0.092 vs 0.521（P=1.7e-05） |
| `results/KPMP_sc_PT_pseudobulk_stage_trend.csv` | AKI 内分期：injury rho=+0.558（p=0.059，n=12）；其余不显著 |
| `results/GSE210622_PT_pseudobulk_tests.csv` | 独立 sn 队列 8 AKI vs 6 对照：injury P=0.0007、repair P=0.0007（FDR=0.0013）；cycling P=0.081、reference P=0.41（未复制） |
| `metadata/GSE210622_AKI_file_map.json` | AKI1–AKI8 与元数据样本名映射（逐细胞 UMI 匹配确定） |
| `results/severity_meta_analysis.csv` | 患者水平跨队列 meta：30 名 KPMP sc 患者 + 53 例 GSE67401 血液；injury/stress 合并 rho=0.217（p=0.053）最接近显著，无签名 p<0.05，I²=0% |
| `results/spatial_pilot_sample_scores.csv` | 16 个 Visium 样本（Stage 1×5、2×5、3×6），294–1399 spot；Moran's I 全为正（injury 0.19–0.71、repair 0.27–0.77、reference 0.26–0.81、cycling -0.01–0.12） |
| `results/spatial_pilot_colocalization.csv` | 16 例中位：injury/repair 与成纤维 0.340/0.299、免疫 0.321/0.281、PT 0.282/0.322；reference PT–PT marker 0.660 |
| `results/spatial_pilot_stage_trend.csv` | 16 例分期趋势均不显著（injury rho=-0.15，p=0.59） |
| `results/spatial_rctd_*.csv` | RCTD 解卷积（参考 9,185 细胞 × 12 类）的 spot/样本水平组成-签名关系与分期趋势 |

### 3a. 2026-11-06 稳健性：伪计数敏感性

| 文件 | 关键数字 |
|---|---|
| `results/PT_pseudocount_sensitivity.csv` | PT pseudobulk 在 `log2(CPM+1)` / `+0.5` / `+0.1` 三档下，AKI vs Ref 的 8 项全部保持同一方向且 **FDR<0.05**（injury/stress 0.013–0.019、repair 0.0012–0.0064、cycling/reference/aPT/hypoxia 均 ≤0.0002） |

### 3b. 2026-11-06 新增三项分析的关键数字

| 文件 | 关键数字 |
|---|---|
| `results/state_DE_summary.csv` | **含 sex 与 sex+age 两套模型**（`model` 列）。sex 模型：adaptive 内 AKI vs CKD **3 个 DE 基因**（FDR<0.01 为 0）；AKI vs Ref 1,564、CKD vs Ref 1,562；degenerative 14/866/415；reference 57/1,514/665。**sex+age 模型**：adaptive AKI vs CKD 降至 **1**、AKI vs Ref 1,390、**CKD vs Ref 719**；reference AKI vs CKD **36**（残余信号保留） |
| `results/state_DE_model_comparison.csv` | 两模型 logFC Spearman 0.94–0.99；reference AKI vs CKD 的 57 个基因中 **36 个在年龄校正后保留** → 非年龄驱动；CKD vs Ref 的下降（1,562→719）说明该对比含年龄成分 |
| `results/state_DE_gene_set_tests.csv` | adaptive AKI vs CKD：repair-progenitor 中位 logFC −0.23（FDR<0.001）；reference 状态 AKI vs CKD：injury +0.18、炎症 +0.50（FDR<0.05） |
| `results/urine_signature_clinical.csv` | 尿液（n=15）：reference_PT vs KDIGO rho=−0.568（p=0.027）、frac_injury rho=−0.641（p=0.010）——均未过 FDR，后者方向与预期相反 |
| `results/urine_signature_scores.csv` | 72,063 细胞 / PT 样 57,661 / 38 样本 30 患者；池化去卷积成功率 19,415/24,342 |
| `results/cellcomm_LR_tests.csv` | 10 对配体-受体 AKI vs CKD 与 AKI vs Ref **全部未过 FDR**（名义最小 p=0.074） |
| `results/cellcomm_LR_links.csv` | ANXA1→FPR1/FPR2 rho=+0.32（p=0.037）、MIF→CD74/CXCR4/CD44 rho=+0.31（p=0.048），n=42；LGALS1（受体集已更正为 PTPRC/ITGB1/NRP1）rho=+0.145（p=0.36，不显著） |
| `results/cellcomm_spatial_ligand_immune.csv` | 16 例：配体表达 vs 邻近 spot 免疫 marker 中位 rho 全为正但弱（0.037–0.139） |

## 4. 复现命令

```bash
cd /media/desk16/iy16128/comorbidity_analysis/aki_repair
python scripts/00_kpmp_query.py          # KPMP 开放文件清单
python scripts/01_kpmp_manifest.py       # 临床与文件映射
python scripts/03_kpmp_analysis.py       # 样本组成与评分
python scripts/04_adjusted_models_clinical.py
python scripts/05_PT_state_analysis.py
python scripts/07_signature_validation.py
python scripts/08_key_findings_figures.py
python scripts/09_kpmp_pseudobulk.py
python scripts/10_pseudobulk_figure.py
python scripts/11_combined_pseudobulk.py
python scripts/12_infection_AKI.py
python scripts/13_GSE122274_sepsis.py
/usr/local/bin/Rscript scripts/18a_GSE67401_cycling.R
python scripts/18_severity_meta.py
python scripts/19_prepare_spatial_pilot.py
python scripts/19e_parallel_download_spatial.py
python scripts/20_spatial_pilot_analysis.py
```

说明：`02_robust_download.py` 负责从限速的 NCBI FTP 断点续传；`06_download_kpmp_sc.sh` 仍在后台下载 KPMP 单细胞矩阵，用于后续基因层面验证。

## 5. 方法抽查

- 细胞是否被当作独立样本：主要统计均在患者/样本水平聚合；PT 分析按 sample 聚合。
- 分期分析是否只含 AKI：`stage` 仅取 1/2/3，非 AKI 为 NaN，不参与趋势。
- FDR：AKI vs Ref 与分期趋势均做 BH 校正。
- 校正模型：OLS + HC3，协变量为 KDIGO stage、baseline eGFR、年龄中值、性别。
- 签名来源：Klocke 2022 发表的肾小管簇标记基因；不是循环论证的候选基因。

## 6. 未完成部分

- 无蛋白/实验验证。
- KDIGO 分期患者数少，严重度结论为探索性；PT 内部仅在 injury/stress 上接近显著（p=0.059）。
- 空间样本病理类型混合（ATI/AIN）、spot 存在伪重复，分期趋势不显著。

（原"无独立单细胞队列复现"已完成：GSE210622 sn 在 PT 内部复制 injury/repair，见 `PT_LEVEL_VALIDATION.md`。）
