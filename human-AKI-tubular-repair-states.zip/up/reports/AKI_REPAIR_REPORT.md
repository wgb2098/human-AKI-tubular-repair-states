# 人 AKI 肾小管状态与修复方向干实验报告

最后更新：2026-11-06

分析目录：`/media/desk16/iy16128/comorbidity_analysis/aki_repair`

**本报告所有数字均来自 `results/FINAL_manuscript_numbers.csv`（患者水平、中位数、族内 FDR `fdr_family`），每个小节标出来源表。** 口径约定与"看似矛盾"的 6 类说明见 `reports/FINAL_NUMBERS.md` 开头；历史口径对照见 `reports/DATA_INVENTORY.md` 的"一致性修订"段。

数据来源：KPMP 开放临床表与 sc/sn 图谱（GSE183276 / GSE183277）、KPMP 仓库矩阵（AKI 42 / Reference 19 / CKD 20 个文库 + sn 43）、GSE210622（独立 sn 队列）、GSE139061（bulk 肾组织）、GSE67401（SIRS 血液）、GSE122274（脓毒症肾活检）、尿液 AKI 队列、KPMP Visium（16 例）。

---

## 1. 结论（按证据强度分级）

**A. 强证据（患者水平、多队列、跨平台一致）**

1. **AKI 肾脏中 adaptive/repair 上皮状态扩张、reference 状态收缩、cycling 状态出现、免疫浸润增加**。sc 图谱 12 例 vs 18 例参考：adaptive-epi 0.1551 vs 0.0466（p=5.3×10⁻⁶）、cycling 0.0129 vs 0（p=5.7×10⁻⁵）、reference 0.5448 vs 0.6804（p=0.0019）、免疫 0.2198 vs 0.0508（p=0.0022）；sn 图谱 10 例 vs 13 例方向一致（reference p=0.0058、adaptive p=0.0070）。
2. **把分析限制在 PT 细胞内部后，结论不变**（sc 12 例 vs 18 例）：reference 0.0922 vs 0.5224、cycling 0.0414 vs 0、repair index 0.365 vs −0.320、adaptive 0.4440 vs 0.2244（全部族内 FDR ≤0.0037）；PT 内 pseudobulk 的 reference 签名 3.00 vs 3.58（p=8×10⁻⁶）、cycling 0.756 vs −0.395（p=2.1×10⁻⁵）。
3. **独立队列 GSE210622（8 AKI vs 6 对照）复制 injury 与 repair 成分**：PT 内 pseudobulk injury 1.341 vs 0.854、repair 0.953 vs 0.799（p=6.7×10⁻⁴，FDR=0.001332）；cycling 趋势（p=0.081），reference 无差异。

**B. 中等证据（方向一致但功效或平台受限）**

4. **CKD 对照显示"急性 vs 慢性"可分**：adaptive 扩张与 reference 丢失为 AKI 与 CKD 共有，而 **cycling 扩张为 AKI 特有**（PT 层 0.0414 vs 0.0062，p=0.0067；PT 内 pseudobulk 0.756 vs 0.041，p=0.0104，族内 FDR=0.042）。
5. **空间定位（16 例 Visium，两套独立解卷积参考）**：injury/repair 与免疫、PT、成纤维共定位，且深度校正后的邻域富集显著；compartment 比例对参考选择不敏感（免疫 rho=0.95/0.87、PT 0.93/0.91）。
6. **全库 pseudobulk（38 AKI vs 51 参考患者）**：cycling、injury、repair 三个签名升高（p<10⁻⁸）；reference 签名无差异——该口径受 PT 含量混杂，仅作一致性参考。

**B2. 新增三项分析（2026-11-06，证据强度：① 强阴性 / ② 探索性 / ③ 阴性）**

10. **状态内部差异（①）**：adaptive 状态内 AKI vs CKD 仅 3 个（年龄校正后 **1 个**）DE 基因，而同两组相对 Reference 各 1,564 / 1,390 ——**急慢差别在状态组成而非胞内程序**；残余差异集中在 reference 状态（57 → 年龄校正后 36，FDR<0.05），且不是年龄驱动。附带限定：**CKD vs Reference 的效应含年龄成分**（DE 1,562→719）。见 `reports/STATE_DE_REPORT.md`。
11. **尿液桥梁（②，探索性）**：同一套程序可在尿液脱落细胞中量化（GSE199321，72,063 细胞 / 30 患者）；reference 分值随 KDIGO 升高而下降（rho=−0.568，p=0.027，方向与组织一致，未过 FDR）；injury 比例呈反向趋势、机制未明。见 `reports/URINE_BRIDGE_REPORT.md`。
12. **细胞互作（③，阴性为主）**：10 对预设 PT→免疫配体-受体在 AKI vs CKD / vs Ref 上均无差异；仅 ANXA1 与 MIF 轴与免疫浸润同步（n=42，p≈0.04，探索性）。见 `reports/CELLCOMM_REPORT.md`。

**C. 探索性（不作结论）**

7. **KDIGO 严重度梯度弱**：PT 内 pseudobulk injury rho=+0.558（p=0.059，n=12）；跨队列 meta（30 名 KPMP 患者 + 53 例 GSE67401）injury 合并 rho=0.217（p=0.053），无签名 p<0.05；空间 16 例趋势全部不显著。
8. **感染相关亚组**：尿液队列感染组 90 天死亡更多（p=0.014，族内 FDR=0.055），GSE122274 与 KPMP sn 方向不一致，仅作假设。
9. **sn 平台的两处限定**：① sn **PT 层**全部不显著（adaptive p=0.121、reference p=0.869、cycling p=0.575），且 PT 内 cycling 方向与 sc 相反（0.72% vs 1.00%）——按「功效/平台受限」处理；② 但 sn **组织层**在族内 FDR 口径下显著（adaptive-epi 与 reference 均 FDR=0.021；全局口径 0.107 仅作敏感性），不应写成「sn 不过 FDR」。

**定位**：可作为一篇以"人 AKI 肾小管适应性/修复状态扩张（含 CKD 对照与空间验证）"为核心的四区论文。KDIGO 严重度只能作为探索性次要结果。

---

## 2. 队列与样本（`results/FINAL_cohort_accounting.csv`）

| 队列 | 规模 | 用途 |
|---|---|---|
| KPMP sc（AKI enrollment） | 42 个表达矩阵 / 38 名参与者；其中 12 名拥有细胞注释 | 主发现、PT 层分析 |
| KPMP sc_ref（Reference enrollment） | 19 / 18 | AKI 的对照 |
| KPMP sc_ckd（CKD enrollment） | 20 / 15（DKD 12 + H-CKD 3） | 急性 vs 慢性对照 |
| KPMP sn（GSE183277 样本） | 43 / 29 | 独立平台复现、RCTD 参考 |
| KPMP AKI 清单（全策略） | 138 / 70（sc 42 · sn 56 · Multiome 40） | 仅 sc 那 42 行进入分析 |
| KPMP Visium | 16 例（Stage 1×5、2×5、3×6；11,301 spot） | 空间定位 |
| GSE210622 | 8 AKI vs 6 对照（PT 29,534 细胞） | 独立 sn 队列 |
| GSE139061 | 39 AKI vs 9 参考 bulk | 组织层签名验证 |
| GSE67401 | 133 样本 = 111 SIRS（53 AKI + 58 非 AKI）+ 22 HD | 血液特异性 + 严重度 meta |
| 尿液队列 | 32 例（6 例有纵向数据） | 临床轨迹 |

基线（sc，`reviewer_sc_baseline_table.csv`）：AKI 12 例（9M/3F，年龄中位 54.5，eGFR 76.2）、CKD 15 例（5M/10F，64.5，44.8）、Ref 18 例（7M/11F，44.5，**eGFR 缺失**）。**AKI vs Ref 年龄无差异（p=0.194）**；CKD 的 eGFR 显著更低（p=0.0043）。

---

## 3. 方法要点

- 统计单位为**患者**（同一患者多文库取中位数）；报告**中位数**；FDR 采用预定义特征族内 BH 校正（`fdr_family`），全局校正仅作敏感性。
- PT 层分析取 `subclass.l1 == "PT"`，计算状态比例与复合 repair index（adaptive + cycling − reference，去一法敏感性见 `reviewer_*_PT_repair_index_sensitivity.csv`）。
- PT 内 pseudobulk：逐文库取 PT 细胞原始 counts 求和 → log2 CPM → 文库内基因 z 标准化后对签名取均值 → 患者内按 PT 细胞数加权。
- 独立签名交叉验证：aPT 标志物（VCAM1、SPP1、LTF、MMP7、HAVCR1、CD24、PROM1、SOX9、KRT7、KRT19）与缺氧模块（14 基因）。
- 空间：Moran's I（6 近邻）、spot 水平共定位、深度校正邻域富集（UMI 分层置换 500 次）、RCTD 双参考解卷积（GSE210622 与 KPMP sn）。
- 校正模型：秩变换 + OLS + HC3（性别的全样本可得；年龄+性别用于 AKI vs Ref；eGFR 仅 AKI vs CKD，属过度校正）。
- 环境：Python 3.9（pandas/scipy/statsmodels/matplotlib/umap）；R 4.5（spacexr、Matrix）。

---

## 4. 结果

### 4.1 组织层 AKI vs Reference（患者水平，`sc_tissue` / `sn_tissue`）

| 特征 | sc AKI (n=12) | sc Ref (n=18) | p | 族内 FDR | sn AKI (n=10) | sn Ref (n=13) | p | 族内 FDR |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| adaptive-epi 比例 | **0.155** | **0.047** | 5.3×10⁻⁶ | 3.2×10⁻⁵ | 0.201 | 0.064 | 0.0070 | 0.021 |
| cycling 比例 | 0.0129 | 0 | 5.7×10⁻⁵ | 1.7×10⁻⁴ | 0.0059 | 0.0029 | 0.051 | 0.102 |
| reference 比例 | 0.545 | 0.680 | 0.0019 | 0.0037 | 0.561 | 0.781 | 0.0058 | 0.021 |
| 免疫比例 | 0.220 | 0.051 | 0.0022 | 0.011 | 0.059 | 0.036 | 0.032 | 0.121 |
| aEpi 评分 | 0.744 | 0.599 | 0.0012 | 0.0096 | 0.803 | 0.749 | 0.278 | 0.370 |

**性别+年龄校正后（sc，n=30）主结论全部保持**：adaptive-epi p<10⁻⁴、reference p=1.1×10⁻⁴、cycling p<10⁻⁴、免疫 p=0.0144（`sc_adjusted`；见 `reviewer_sc_adjusted_contrasts.csv`）。

### 4.2 PT 层（患者水平，`sc_PT` / `sn_PT`）

| 特征 | sc AKI (12) | sc CKD (15) | sc Ref (18) | AKI vs Ref（p / FDR） | AKI vs CKD（p / FDR） | CKD vs Ref（p / FDR） |
|---|---:|---:|---:|---|---|---|
| adaptive 比例 | 0.444 | 0.451 | 0.224 | 0.0025 / 0.0037 | 0.94 / 1.0 | 0.018 / 0.027 |
| reference 比例 | 0.092 | 0.169 | 0.522 | 1.7×10⁻⁵ / 5.1×10⁻⁵ | 0.11 / 0.25 | 5.5×10⁻⁴ / 0.0022 |
| cycling 比例 | 0.0414 | 0.0062 | 0 | 1.6×10⁻⁵ / 5.1×10⁻⁵ | **0.0067 / 0.040** | 0.0020 / 0.0040 |
| repair index | 0.365 | 0.374 | −0.320 | 2.5×10⁻⁵ / 5.1×10⁻⁵ | 0.79 / 1.0 | 7.2×10⁻⁴ / 0.0022 |

sn PT 层（10 vs 12）：adaptive p=0.121、reference p=0.869、cycling p=0.575（方向与 sc 相反，见 §1-C9）。

### 4.3 PT 内 pseudobulk 三队列（`sc_PT_pseudobulk` / `sn_PT_pseudobulk` / `GSE210622_PT_pseudobulk`）

| 签名 | sc AKI (12) | sc Ref (18) | p / FDR | sn KPMP (4) | sn Ref (12) | GSE210622 AKI (8) | 对照 (6) | p / FDR |
|---|---:|---:|---|---:|---:|---:|---:|---|
| injury/stress | 1.978 | 1.854 | 0.019 / 0.019 | 1.181 | 1.031 | 1.341 | 0.854 | 6.7×10⁻⁴ / 0.0013 |
| repair-progenitor | 1.237 | 1.043 | 0.0056 / 0.0064 | 0.919 | 0.948 | 0.953 | 0.799 | 6.7×10⁻⁴ / 0.0013 |
| cycling | 0.756 | −0.395 | 2.1×10⁻⁵ / 5.6×10⁻⁵ | −0.055 | −0.332 | −0.462 | −0.517 | 0.081 / 0.108 |
| reference-state | 2.999 | 3.580 | 8×10⁻⁶ / 5.6×10⁻⁵ | 2.034 | 1.859 | 2.074 | 2.130 | 0.41 / 0.41 |
| 独立 aPT 标志物 | 2.493 | 1.806 | 1.5×10⁻⁴ / 2.0×10⁻⁴ | 1.707 | 1.522 | — | — | （p=0.058，不显著） |

- sc 队列中 status 分数与注释状态比例自洽（reference 签名 vs reference 状态比例 rho=+0.81）。
- 独立 aPT 标志物与 Klocke 签名高度一致（injury rho=+0.87、repair +0.69、cycling +0.54），**支持签名非循环论证**；缺氧模块不复制该方向（如实记录）。
- KPMP sn 队列 AKI 仅 4 例（6 例中 2 例的仓库矩阵与注释文库不一致），方向一致但功效不足，只作方向性证据。

### 4.4 全库 pseudobulk（`whole_library_pseudobulk_*`）

| 签名 | 患者级 AKI (38) | Ref (51) | p（患者级） | 文库级 p (42 vs 66) |
|---|---:|---:|---:|---:|
| injury/stress | 6.556 | 5.118 | <10⁻⁸ | <10⁻⁸ |
| repair-progenitor | 4.783 | 3.796 | <10⁻⁸ | <10⁻⁸ |
| cycling | 2.610 | 0.707 | <10⁻⁸ | <10⁻⁸ |
| reference PT | 6.929 | 6.553 | 0.172 | 0.049 |

**reference PT 的反向结果已定位为组成假象**：全库 reference-PT 分数与注释 PT 比例高度相关（rho=+0.85，p=2×10⁻¹⁰）；文库级 p=0.049 在患者级消失（p=0.172），而在 PT 细胞内部方向反转为预期方向（§4.3）。详见 `reviewer_pseudobulk_library_vs_patient.csv`、`reviewer_wholelibrary_annotated_tests.csv`。
（注：57 名参考患者中 6 名所在文库的 feature 文件缺基因符号，无法评分，故患者级 n=51。）

### 4.5 KDIGO 严重度（探索性，`KDIGO_trend*` / `severity_meta`）

| 分析 | 特征 | rho | p | n |
|---|---|---:|---:|---:|
| sc 组织层 | cycling 分值 | +0.594 | 0.042 | 42 文库/30 患者层级见下 |
| sc 组织层 | cycling 比例 | +0.570 | 0.053 | 同上 |
| sc PT 内 pseudobulk | injury/stress | +0.558 | 0.059 | 12 |
| sn 组织层 | —（方向不一致） | — | ≥0.33 | 10 |
| 空间（16 例，GSE210622 参考） | 内皮比例 | −0.633 | 0.0085（族内 0.072） | 16 |
| 空间（16 例，KPMP sn 参考） | 内皮比例 | −0.577 | 0.019（族内 0.155） | 16 |
| 跨队列 meta（30 患者 + 53 血液） | injury/stress | +0.217 | 0.053 | 83 |

严重度的层级口径：42 个 AKI 文库 → 34 个有 KDIGO 分期 → 33 个兼有 cycling 分值 → 患者级 30 名。**无任何签名在 meta 中达到 p<0.05，严重度保持探索性。**

### 4.6 空间（16 例 Visium；`SPATIAL_PILOT_REPORT.md`、`RCTD_REFERENCE_COMPARISON.md`）

- Moran's I：injury 0.19–0.71、repair 0.27–0.77、reference 0.26–0.81、cycling −0.01–0.12。
- spot 水平共定位（16 例中位 rho）：injury 与成纤维 0.340、免疫 0.321、PT 0.282；repair 与 PT/TAL 0.322、成纤维 0.299、免疫 0.281；reference 与 PT 0.660。
- 深度校正邻域富集：injury+immune z=+1.22（P=0.006）、injury+fibroblast z=+1.24、repair+immune z=+0.86（P=0.006），而 reference+immune z=+0.32（不显著）——"损伤—修复—炎症"空间单元成立。
- RCTD 双参考一致性：样本级免疫 rho=0.95、PT 0.93、TAL 0.85、内皮 0.83；spot 级 PT 0.91、免疫 0.87。分期趋势两套参考方向一致（内皮 −0.63/−0.58）。
- 16 例分期趋势（签名层）均不显著（injury rho=−0.147，p=0.59）。

### 4.7 其它队列（`GSE139061_bulk` / `GSE67401_blood` / `urine_recovery` / `infection_*`）

- **GSE139061 bulk 肾组织**：reference-PT 评分在 AKI 中更低（AUC(AKI>Ref)=0.282，等价 AUC(Ref>AKI)=0.718；p=0.0447，族内 FDR=0.134）；repair（p=0.41）、injury（p=0.53）无差异。
- **GSE67401 血液**：injury（p=0.110）、reference（p=0.199）均无关联，支持肾脏组织特异性。
- **尿液队列**：KDIGO 分期与肌酐对数恢复斜率无相关（rho=−0.207，p=0.694，n=6）。
- **感染相关（探索性）**：尿液队列感染组 90 天死亡更多（p=0.0138，族内 FDR=0.055），KDIGO 分期相似（p=0.709）；KPMP sn 中 COVID-AKI 的成纤维比例更低（0.013 vs 0.109，p=0.0095，FDR=0.019）、matrisome 评分更低（p=0.038）；GSE122274 方向不一致。三个来源不一致，仅作假设。

---

## 5. 解释

- 最稳健的发现是**上皮状态重塑（adaptive/repair/cycling 扩张、reference 收缩）与免疫浸润**，在 sc 图谱、PT 细胞内部、独立 sn 队列与空间层面一致。
- **急性 vs 慢性可分**：adaptive 扩张与 reference 丢失在 CKD 中同样存在，只有 cycling 扩张对 AKI 相对特异——这提升了论文立意，也限定了措辞（不能声称所有变化均为 AKI 特异）。
- reference PT 在"全库 pseudobulk"中的反向结果已定量归因于细胞组成（PT 含量），PT 内部方向符合生理预期。
- 严重度的所有证据都是名义/趋势级别，且分期样本不均衡（Stage 3 居多）、无配对活检，因此保持探索性。

## 6. 局限

1. 横断面再分析，无同一患者治疗前后配对；状态注释沿用原图谱作者。
2. **AKI vs Reference 无法校正 eGFR**（18 名参考供肾者在开放临床表与仓库索引中均无 eGFR）；年龄与性别已校正且结论不变。
3. 有分期的 AKI 患者少（sc 12、sn 6）；严重度无显著结果。
4. sn 平台两处限定：**PT 层**全部不显著（族内 FDR≥0.73）且 PT 内 cycling 方向与 sc 相反；**组织层则显著**（族内 FDR=0.021，全局口径 0.107）。
5. 空间每例 spot 非独立、病理类型混合（ATI/AIN），分期趋势不显著；RCTD 绝对比例受参考平台影响（按相对值解释）。
6. 全库 pseudobulk 受 PT 含量混杂（已定量说明）；KPMP sn PT 队列 AKI 仅 4 例。
7. 无实验验证。

## 7. 产出索引

- **权威数字源**：`results/FINAL_manuscript_numbers.csv`（29 层 / 770 行，含 state_DE 双模型、尿液桥梁、配体-受体层）+ `reports/FINAL_NUMBERS.md`（口径说明）
- 主结果：`results/KPMP_sc_sample_composition_scores.csv`、`KPMP_sc_feature_tests.csv`、`KPMP_sc_PT_state_table.csv`、`KPMP_sc_PT_state_tests.csv`，以及 sn 的同名四份（`KPMP_sn_*`）
- PT pseudobulk：`results/KPMP_sc_PT_pseudobulk*.csv`、`KPMP_sn_PT_pseudobulk*.csv`、`GSE210622_PT_pseudobulk*.csv`
- 审稿响应：`results/reviewer_*.csv`（28 个）+ `reports/REVIEWER_RESPONSE_DRYLAB_2026-11-04.md`
- 空间：`results/spatial_*.csv` + `reports/{SPATIAL_PILOT_REPORT,RCTD_RESULTS,RCTD_REFERENCE_COMPARISON}.md`
- 其它队列：`results/GSE139061_*.csv`、`GSE67401_*.csv`、`urine_*.csv`、`infection_AKI_*.csv`
- 图：`figures/`（含 `Fig_PT_pseudobulk_two_cohorts`、`Fig_PT_three_group`、`Fig_UMAP_PT_states`、`Fig_spatial_pilot_signatures`、`Fig_severity_meta_forest` 等 20 张 PNG+PDF）
- 校验和：`reports/file_checksums.sha256`
