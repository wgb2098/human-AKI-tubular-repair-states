# 感染相关 AKI vs 非感染 AKI 报告

最后更新：2026-11-05

分析目录：`/media/desk16/iy16128/comorbidity_analysis/aki_repair`  
定位：路线 A 探索性分析，用于评估“感染相关 AKI 是否具有更强的损伤/修复程序”，不等同于严格共病研究。

## 1. 数据来源

| 来源 | 分组 | 说明 |
|---|---|---|
| KPMP snRNA-seq（GSE183277） | Reference 21、非 COVID AKI 6、COVID-AKI 4 个样本 | 肾组织单核转录组，细胞状态和评分 |
| 尿液单细胞队列（Klocke 2022） | 感染相关 15 例（肺炎/COVID）、非感染 17 例（心脏手术/肾前性） | 只做临床表型、KDIGO、RRT、90 天结局和纵向轨迹 |
| GSE122274（Hato 等） | 脓毒症 5 例、非脓毒症 10 例肾活检 | 全部为 ATN/AIN/Mixed；疾病类别在两组间基本均衡 |

## 2. 结果

### 2.1 KPMP 单核数据：COVID-AKI vs 非 COVID AKI

- adaptive epithelial、cycling、reference epithelial、免疫比例、aEpi、degenerative 评分均无显著差异（P>0.11）。
- COVID-AKI 的 fibroblasts 比例更低（0.013 vs 0.109，P=0.0095，**族内 FDR=0.019**，`FINAL_manuscript_numbers.csv` 的 infection_sn 层），matrisome 评分更低（P=0.038，族内 FDR=0.152）。
  （此前的 FDR=0.095/0.19 来自"该表全部 10 个特征"的全局校正口径；现按冻结口径改为族内 FDR，两口径在 `FINAL_NUMBERS.md` 的"口径说明"中有约定。）
- 样本量仅 4 vs 6，结论为探索性；不支持“感染相关 AKI 修复反应更强”。

### 2.2 尿液队列：感染相关 vs 非感染 AKI

| 指标 | 感染相关（n=15） | 非感染（n=17） | P |
|---|---:|---:|---:|
| 中位 KDIGO 分期 | 3 | 2 | 0.71 |
| 年龄中位数 | 62 | 70 | 0.070 |
| RRT（CVVHD） | 7 | 2 | 0.072 |
| 90 天结局 | 死亡 5、进展 CKD 2、基线 8 | 死亡 0、进展 CKD 8、基线 9 | 0.014 |

- 感染相关 AKI 的 KDIGO 分期和 RRT 比例相似或略高，但 90 天死亡明显更多、进展 CKD 更少。
- 纵向肌酐/尿量轨迹显示感染组存在峰值更高、恢复更慢的个体，但总样本量仅 6 例有纵向数据。

### 2.3 GSE122274：脓毒症 vs 非脓毒症肾活检

| 签名 | 脓毒症均值 | 非脓毒症均值 | Mann–Whitney P | 校正疾病+年龄 P |
|---|---:|---:|---:|---:|
| cycling | 0.943 | -0.127 | 0.019 | 0.053 |
| repair/progenitor | 0.682 | -0.006 | 0.075 | 0.027 |
| injury/stress | 0.663 | 0.016 | 0.165 | 0.090 |
| reference PT | 0.517 | 0.050 | 0.206 | 0.284 |

- 脓毒症肾活检中 cycling 和 repair/progenitor 签名升高，但多重校正后仅名义显著；样本量 5 vs 10。
- 差异表达基因中仅 `ANKRD62P1-PARP4P3` 通过 FDR<0.05，`AADAC` FDR=0.055，其余不显著。
- 该数据集的“sepsis vs non-sepsis”不是严格 `SA-AKI vs Sepsis non-AKI`，只能作为感染背景的肾组织支持证据。

## 3. 综合判断

1. 三个数据源没有给出一致、稳健的“感染相关 AKI 修复更强”结论：KPMP sn 为阴性，尿液队列主要是临床结局差异，GSE122274 只有名义的 cycling/repair 升高。
2. 目前可以谨慎表述为：**感染相关 AKI 可能具有更强的肾小管 cycling/修复倾向，并伴随更差的短期结局，但现有公共数据样本量小、定义不一致，证据不足以定为共病特异机制。**
3. 该结果适合作为主图谱论文的次要分析，或作为未来真正 SA-AKI 共病队列的预设假设，不能单独支撑“共病机制”论文。

## 4. 产物

- 脚本：`scripts/12_infection_AKI.py`、`scripts/13_GSE122274_sepsis.py`
- 结果表：`results/infection_AKI_sn_*.csv`、`results/infection_AKI_urine_*.csv`、`results/GSE122274_sepsis_*.csv`
- 图：`figures/Fig_infection_AKI_sn.*`、`Fig_infection_AKI_urine_clinical.*`、`Fig_infection_AKI_urine_trajectories.*`、`Fig_GSE122274_sepsis_signatures.*`
